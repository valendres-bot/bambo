/* =========================================================
   state.js — estado global, modelo de notas y etiquetas, y
   lectura del texto de la nota (títulos, casillas, enlaces).

   nota:     { id, title, body, links:[link], labels:[labelId],
               pinned, archived, trashed, collapsed:[titulo],
               doneAt:{clave de casilla: fecha en que se tildó},
               doneAt:{clave de casilla: fecha en que se tildó},
               order, createdAt, updatedAt }
   etiqueta: { id, name, order, color, pinned, archived, links:[link], createdAt, kind }
             (kind: "area"; "materia" solo aparece en datos viejos, hasta que se convierten en objetivos)
   objetivo: { id, name, description, category, archived, startDate, deadline, color, projects:[], resources:[], ... }
             ver goals.js. Un pendiente puede tener goalId y projectId.
   franja:   { id, date ('AAAA-MM-DD'), title, start, end (minutos; 1440 = fin del día), color }
             franja horaria de un día en Hoy. Un pendiente puede tener blockId; su fecha es la de la franja.
   pinned: en notas y etiquetas significa lo mismo: aparece en "Fijadas" de la barra lateral.
   link:     { id, title, url }                 → afuera (pestaña nueva)
             { id, title, target:{kind,id} }    → nota o etiqueta de la web

   body = texto libre con marcas:
     ## Subtítulo                     (se pliega hasta el siguiente)
     - texto de viñeta (las casillas no se tildan en notas: los pendientes van en Pendientes)
     [texto](https://...)             enlace en una palabra
     [[Nombre]]                       nota o etiqueta de la web
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const ls = (k, d) => { try { return localStorage.getItem(k) || d; } catch { return d; } };

  K.VERSION = '1.26.7';
  /* Las etiquetas son todas iguales (las materias pasaron a ser Objetivos, ver storage.js). */
  K.labelIcon = () => 'tag';
  /* Uso en este dispositivo: contadores locales, nunca salen del navegador */
  K.usageBump = field => {
    try {
      const u = K.usageStats();
      const d = new Date(), key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      u.days = [...new Set([...(u.days || []), key])].slice(-400);
      if (field) u[field] = (u[field] || 0) + 1;
      localStorage.setItem(K.PREF.usage, JSON.stringify(u));
    } catch { /* sin storage */ }
  };
  K.usageStats = () => { try { return JSON.parse(localStorage.getItem(K.PREF.usage) || '{}') || {}; } catch { return {}; } };
  K.PREF = { capBlock: 'mi-keep:v4:capblock', sort: 'mi-keep:v4:sort', side: 'mi-keep:v4:side', pomo: 'mi-keep:v4:pomo', theme: 'mi-keep:v4:theme', exported: 'mi-keep:v4:exported', wake: 'mi-keep:v4:wake', backupSnooze: 'mi-keep:v4:backupSnooze', usage: 'mi-keep:v4:usage', noteView: 'mi-keep:v4:noteview', capNoLabel: 'mi-keep:v4:capnolabel' };

  K.state = {
    notes: [], labels: [], blocks: [], events: [], sessions: [], versions: [], tasks: [], goals: [], slots: [],
    hoySel: null,                         // día que se ve en Hoy ('AAAA-MM-DD'); null = hoy
    route: { name: 'today' },             // inicio: Hoy
    schedDay: null,                       // día que se ve en celular (0 = lunes)
    query: '',
    sort: ls(K.PREF.sort, 'updated'),     // updated (recientes) | name (A–Z). Fijadas: orden propio, arrastrable
    editor: null,                         // editor flotante abierto (o null)
    newLabel: false,                      // se está creando una etiqueta (campo en Notas)
    renaming: null,                       // id de etiqueta que se está renombrando
  };

  /* Colores para etiquetas, bloques de la rutina y eventos (las notas siguen en grises) */
  K.COLORS = [
    { id: 'rojo', hex: '#e5484d', ink: '#ffffff' },
    { id: 'naranja', hex: '#f76b15', ink: '#ffffff' },
    { id: 'amarillo', hex: '#e8b431', ink: '#1a1a1a' },
    { id: 'verde', hex: '#30a46c', ink: '#ffffff' },
    { id: 'celeste', hex: '#0ea5c2', ink: '#ffffff' },
    { id: 'azul', hex: '#3e63dd', ink: '#ffffff' },
    { id: 'violeta', hex: '#8e4ec6', ink: '#ffffff' },
    { id: 'rosa', hex: '#d6409f', ink: '#ffffff' },
  ];
  K.colorOf = id => K.COLORS.find(c => c.id === id) || null;

  /* ---------- Modelos ---------- */
  K.makeNote = (over = {}) => {
    const t = Date.now();
    return {
      id: K.uid(), title: '', body: '', links: [], labels: [],
      pinned: false, archived: false, trashed: false, collapsed: [],
      order: 0, doneAt: {}, createdAt: t, updatedAt: t, rev: 0, ...over,
    };
  };
  K.makeLabel = (name, order = 0) =>
    ({ id: K.uid(), name: name.trim(), order, color: null, kind: 'area', pinned: false, archived: false, links: [], createdAt: Date.now(), updatedAt: Date.now(), rev: 0 });

  /* Completa los campos que puede no traer un registro guardado (no migra formatos viejos:
     solo garantiza que el resto de la app encuentre siempre los mismos campos). Es idempotente. */
  K.noteDefaults = n => ({
    ...n,
    id: n.id || K.uid(),
    title: typeof n.title === 'string' ? n.title : '',
    body: typeof n.body === 'string' ? n.body : '',
    links: Array.isArray(n.links) ? n.links : [],
    labels: Array.isArray(n.labels) ? n.labels : [],
    collapsed: Array.isArray(n.collapsed) ? n.collapsed : [],
    doneAt: n.doneAt && typeof n.doneAt === 'object' && !Array.isArray(n.doneAt) ? n.doneAt : {},
    pinned: !!n.pinned, archived: !!n.archived, trashed: !!n.trashed,
    trashedAt: Number.isFinite(n.trashedAt) ? n.trashedAt : null,
    order: typeof n.order === 'number' ? n.order : 0,
    createdAt: n.createdAt || Date.now(),
    updatedAt: n.updatedAt || Date.now(),
    rev: Number.isFinite(n.rev) ? n.rev : 0,
  });
  /* Etiquetas: el fijado se llama "pinned" igual que en las notas. Las etiquetas guardadas antes
     con "anchored" se leen como pinned (es el mismo dato con otro nombre, no una migración). */
  K.normalizeLabel = l => {
    const { anchored, ...rest } = l;
    return {
      ...rest,
      id: l.id || K.uid(),
      name: typeof l.name === 'string' && l.name.trim() ? l.name : 'Sin nombre',
      order: typeof l.order === 'number' ? l.order : 0,
      color: typeof l.color === 'string' ? l.color : null,
      kind: l.kind === 'materia' ? 'materia' : 'area',      // materia (cursada) o área de vida
      pinned: !!(l.pinned ?? anchored),
      archived: !!l.archived,
      links: Array.isArray(l.links) ? l.links : [],
      createdAt: l.createdAt || 0,
      rev: Number.isFinite(l.rev) ? l.rev : 0,
    };
  };

  /* ---------- Consultas ---------- */
  K.noteById = id => K.state.notes.find(n => n.id === id) || null;
  K.labelById = id => K.state.labels.find(l => l.id === id) || null;
  K.labelsOf = n => n.labels.map(K.labelById).filter(Boolean);
  /* ¿Tiene alguna etiqueta que se vea (no archivada)? Las notas con solo etiquetas archivadas cuentan como "sin etiqueta" */
  K.hasActiveLabel = n => n.labels.some(id => { const l = K.labelById(id); return !!l && !l.archived; });
  K.activeLabels = () => K.state.labels.filter(l => !l.archived).sort((a, b) => a.order - b.order);
  K.isLive = n => !n.trashed && !n.archived;
  K.isEmpty = n => !n.title.trim() && !n.body.trim() && !n.links.length;
  K.clean = n => { n.body = n.body.replace(/\s+$/, ''); };
  K.noteText = n => [n.title, n.body].join('\n');
  /* Cache por nota (WeakMap: se libera sola al borrar la nota). Se recalcula solo si cambió
     el título, el cuerpo o los nombres de sus etiquetas. */
  const textCache = new WeakMap();
  const cacheOf = n => {
    const labels = K.labelsOf(n).map(l => l.name).join('\n');
    let c = textCache.get(n);
    if (!c || c.title !== n.title || c.body !== n.body || c.labels !== labels) {
      c = { title: n.title, body: n.body, labels, norm: null, vnorm: null, snip: null };
      textCache.set(n, c);
    }
    return c;
  };
  /* Texto normalizado (sin acentos ni mayúsculas) de todo lo que busca el buscador */
  K.searchNorm = n => { const c = cacheOf(n); if (c.norm === null) c.norm = K.norm(K.noteText(n) + '\n' + c.labels); return c.norm; };
  /* Texto que busca el filtro de la vista: título y cuerpo, sin los nombres de las etiquetas (eso lo busca la paleta) */
  K.viewNorm = n => { const c = cacheOf(n); if (c.vnorm === null) c.vnorm = K.norm(K.noteText(n)); return c.vnorm; };
  /* Resumen de la lista: texto plano recortado, antes de resaltar las coincidencias */
  K.snippetOf = (n, max = 200) => { const c = cacheOf(n); if (c.snip === null) c.snip = K.plain(n.body).replace(/\s+/g, ' ').trim().slice(0, max); return c.snip; };
  K.byOrder = (a, b) => (a.order - b.order) || (b.createdAt - a.createdAt);   // orden propio (fijadas)
  K.topOrder = () => K.state.notes.reduce((m, n) => Math.min(m, n.order), 0) - 1;

  /* ---------- Identidad de las casillas ----------
     Cada casilla lleva al final de la línea un marcador " ^t" + 8 caracteres (p. ej. "- [ ] Entregar TP ^t3f9a1c2b").
     Lo crea la app al crear o tildar la casilla. Sobrevive a editar el texto y a mover la casilla.
     El editor lo oculta (lo guarda como atributo del bloque), así no se ve en pantalla. */
  const TASK_ID = /(?:^|\s)\^(t[0-9a-z]{6,12})(?=\s|$)/;
  K.taskIdOf = s => { const m = TASK_ID.exec(String(s || '')); return m ? m[1] : null; };
  K.stripTaskId = s => String(s || '').replace(TASK_ID, '');

  /* ---------- Lectura del texto ---------- */
  /* Clasifica una línea: h2 (##), task (- [ ]), bullet (- ), blank o text */
  K.lineKind = line => {
    const m = /^##\s+(.*)$/.exec(line);
    if (m) return { kind: 'h2', text: m[1] };
    const t = /^-\s\[( |x|X)\]\s?(.*)$/.exec(line);
    if (t) return { kind: 'task', done: t[1] !== ' ', text: K.stripTaskId(t[2]) };
    const b = /^-\s+(.*)$/.exec(line);
    if (b) return { kind: 'bullet', text: b[1] };
    if (!line.trim()) return { kind: 'blank', text: '' };
    return { kind: 'text', text: line };
  };
  /* Texto sin marcas, para filas y resúmenes */
  K.plain = body => body.split('\n').map(line => {
    const L = K.lineKind(line);
    const t = L.text
      .replace(/\[\[([^[\]\n]+)\]\]/g, '$1')
      .replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '$1')
      .replace(/\*\*\*(\S(?:[\s\S]*?\S)?)\*\*\*|\*\*(\S(?:[\s\S]*?\S)?)\*\*|==(\S(?:[\s\S]*?\S)?)==|(?<![\\*\w])\*([^\s*](?:[^*\n]*?[^\s*])?)\*(?![\w*])/g,
        (_, a, b, c, d) => a || b || c || d || '');
    return t.replace(/\\([\\*[\]=#-])/g, '$1');
  }).join(' ');

  /* ---------- Guardado ---------- */
  K.run = p => Promise.resolve(p).catch(e => { console.error(e); K.toast('No se pudo guardar el cambio'); });
  K.save = n => K.run(K.api.saveNote(n));                              // banderas: no cambia "modificada"
  K.persist = n => { n.updatedAt = Date.now(); return K.save(n); };    // contenido: sí la cambia
  K.saveLabel = l => K.run(K.api.saveLabel(l));
  K.persistTask = t => { t.updatedAt = Date.now(); return K.run(K.api.saveTask(t)); };   // pendiente: registro propio

  /* Garantiza órdenes únicos (necesario para reordenar arrastrando) */
  K.normalizeOrder = () => {
    const ns = K.state.notes.slice().sort(K.byOrder);
    const seen = new Set();
    let dup = false;
    ns.forEach(n => { if (typeof n.order !== 'number' || seen.has(n.order)) dup = true; seen.add(n.order); });
    if (!dup) return;
    ns.forEach((n, i) => { if (n.order !== i) { n.order = i; K.save(n); } });
  };

  /* Reordena: recibe los ids en su nuevo orden visual y reparte los mismos
     valores de `order` que ya ocupaban esos lugares (el resto no se toca). */
  K.commitOrder = ids => {
    const ns = ids.map(K.noteById).filter(Boolean);
    const slots = ns.map(n => n.order).sort((a, b) => a - b);
    ns.forEach((n, i) => { if (n.order !== slots[i]) { n.order = slots[i]; K.save(n); } });
  };

  /* Pasa los datos del almacenamiento al estado de la app. Conserva los objetos que ya existían
     (así los avisos con "Deshacer" y las notas abiertas siguen apuntando a lo mismo). */
  const keepRefs = (cur, incoming) => {
    const byId = new Map(cur.map(x => [x.id, x]));
    return incoming.map(item => {
      const old = byId.get(item.id);
      if (!old) return item;
      Object.keys(old).forEach(k => { if (!(k in item)) delete old[k]; });
      return Object.assign(old, item);
    });
  };
  K.applyData = d => {
    const st = K.state;
    st.notes = keepRefs(st.notes, (d.notes || []).map(n => K.noteDefaults(n)));
    st.labels = keepRefs(st.labels, (d.labels || []).map(l => K.normalizeLabel(l)));
    st.blocks = keepRefs(st.blocks, [...(d.blocks || []).map(K.unifyBlock), ...(d.slots || []).map(K.unifySlot)]);
    st.events = keepRefs(st.events, d.events || []);
    st.sessions = keepRefs(st.sessions, d.sessions || []);
    st.versions = keepRefs(st.versions, d.versions || []);
    st.tasks = keepRefs(st.tasks, d.tasks || []);
    st.goals = keepRefs(st.goals, (d.goals || []).map(g => K.normalizeGoal(g)));
    st.slots = [];                       // las franjas viven en blocks (repeat once)
  };
  /* Igual que arriba, pero para las etiquetas de la barra lateral */
  K.commitLabelOrder = ids => {
    const ls = ids.map(K.labelById).filter(Boolean);
    ls.forEach((l, i) => { if (l.order !== i) { l.order = i; K.saveLabel(l); } });
  };
})();
