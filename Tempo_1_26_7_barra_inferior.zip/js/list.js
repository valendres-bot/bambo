/* =========================================================
   list.js — la lista de notas en renglones.
   · Notas: tarjetas de etiquetas arriba y debajo las notas sin etiqueta.
     Al buscar, muestra todas las coincidencias.
   · Etiquetas: sus notas, con las cards de enlaces y sus bloques/eventos.
   · Fijadas arriba: se reordenan arrastrándolas (orden propio).
   · Resto: por recientes o nombre.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;

  const SORTS = {
    updated: (a, b) => b.updatedAt - a.updatedAt,
    name: (a, b) => (a.title || '').localeCompare(b.title || '', 'es', { sensitivity: 'base' }),
  };

  /* Notas de una vista, filtradas por la búsqueda (sin mayúsculas ni acentos) */
  K.listFor = r => {
    const st = K.state, q = st.query.trim(), tk = K.tokens(st.query);
    const hasLabel = K.hasActiveLabel;
    return st.notes.filter(n => {
      if (r.name === 'trash') { if (!n.trashed) return false; }
      else {
        if (n.trashed) return false;
        if (r.name === 'archive') { if (!n.archived) return false; } else if (n.archived) return false;
        if (r.name === 'label' && !n.labels.includes(r.id)) return false;
        if (r.name === 'all' && !q && hasLabel(n)) return false;     // con etiqueta: se ve dentro de su etiqueta
      }
      return K.matchNorm(K.viewNorm(n), tk);
    }).sort(SORTS[st.sort] || SORTS.updated);
  };

  const EMPTY = {
    all: ['Todavía no hay notas', 'Escribí la primera arriba, o apretá N.'],
    label: ['Esta etiqueta no tiene notas', 'Creá una nota desde acá o asignale esta etiqueta a una nota existente.'],
    none: ['Todas tus notas tienen etiqueta', 'Están agrupadas en las etiquetas de arriba.'],
    archive: ['El archivo está vacío', 'Archivá las notas que ya no uses pero quieras conservar.'],
    trash: ['La papelera está vacía', 'Las notas que borres pasan por acá antes de eliminarse.'],
    search: ['Sin resultados', 'Probá con otra palabra. La búsqueda ignora mayúsculas y acentos.'],
  };

  const labelNames = n => K.labelsOf(n).filter(l => !l.archived).map(l => l.name).join(' · ');

  /* ---------- Barra de acciones en lote (aparece al seleccionar) ---------- */
  K.batchBar = () => {
    const notes = K.state.notes.filter(n => K.isSel(n.id));
    const allPinned = notes.every(n => n.pinned);
    const labelItems = K.activeLabels().map(l => {
      const all = notes.every(n => n.labels.includes(l.id));
      return { label: l.name, icon: K.labelIcon(l), checked: all,
        run: () => K.batchChange(notes, n => { n.labels = all ? n.labels.filter(x => x !== l.id) : [...new Set([...n.labels, l.id])]; },
          all ? `Quitadas de “${l.name}”` : `Agregadas a “${l.name}”`) };
    });
    const btn = (ic, text, onclick) => h('button', { type: 'button', class: 'btn small', onclick }, h('span', { svg: icon(ic, 15) }), text);
    return h('div', { class: 'batch', role: 'toolbar', 'aria-label': 'Acciones para las notas seleccionadas' },
      h('span', { class: 'batch-n' }, `${notes.length} ${notes.length === 1 ? 'seleccionada' : 'seleccionadas'}`),
      btn('tag', 'Etiquetar', e => K.togglePop(e.currentTarget, () => K.menu(labelItems.length ? labelItems
        : [{ label: 'No hay etiquetas: creá una en Notas', icon: 'tag', run: () => {} }]))),
      btn('pin', allPinned ? 'Desfijar' : 'Fijar', () => K.batchChange(notes,
        n => { n.pinned = !allPinned; if (n.pinned) n.archived = false; }, allPinned ? 'Notas desfijadas' : 'Notas fijadas')),
      btn('archive', 'Archivar', () => K.batchChange(notes, n => { n.archived = true; n.pinned = false; }, 'Notas archivadas')),
      btn('trash', 'A la papelera', () => K.batchChange(notes,
        n => { n.trashed = true; n.trashedAt = Date.now(); n.pinned = false; }, 'Notas enviadas a la papelera')),
      btn('x', 'Cancelar', () => K.clearSel()));
  };

  /* ---------- Renglón ---------- */
  function rowEl(n, ctx, q) {
    const text = K.snippetOf(n);
    const el = h('div', { class: 'row' + (n.trashed ? ' in-trash' : '') + (K.isSel(n.id) ? ' sel' : ''), role: 'listitem', tabindex: '0', 'data-note-id': n.id },
      h('div', { class: 'r-main' },
        n.pinned ? K.pinMark() : null,
        h('span', { class: 'r-title' + (n.title ? '' : ' empty') }, n.title ? K.hl(n.title, q) : 'Sin título'),
        h('span', { class: 'r-snip' }, K.hl(text, q))),
      h('span', { class: 'r-labels' }, labelNames(n)),
      h('span', { class: 'r-date' }, K.ago(n.updatedAt)),
      h('div', { class: 'r-act' }, K.noteActions(n)));
    const openNote = () => { if (!K.dragSuppressed() && !n.trashed) K.openEditor(n); };
    el.addEventListener('click', e => {
      if (e.target.closest('button')) return;
      if (e.ctrlKey || e.metaKey || K.selIds().length) { K.toggleSel(n.id); return; }
      openNote();
    });
    el.addEventListener('keydown', e => { if (e.target === el && e.key === 'Enter') openNote(); });
    if (!n.trashed) K.attachDrag(el, n, ctx);
    return el;
  }

  /* Reordenar solo dentro del grupo de fijadas */
  function ctxFor(container, reorder) {
    return {
      container, reorder,
      onDrop: (n, key) => K.dropNote(n, key),
      commit: () => K.commitOrder([...container.children].map(el => el.dataset.noteId)),
    };
  }

  /* Etiquetas (vista Notas): viven acá. "Nueva etiqueta" las crea; ⋯ fija, renombra, cambia color, archiva o borra. */
  function labelTiles() {
    const st = K.state;
    const tiles = K.activeLabels().map(l => {
      if (st.renaming === l.id) {
        return K.nameInput({ value: l.name, placeholder: 'Nombre de la etiqueta',
          onSubmit: name => { st.renaming = null; K.renameLabel(l, name); },
          onCancel: () => { st.renaming = null; K.refreshAll(); } });
      }
      const c = st.notes.filter(n => K.isLive(n) && n.labels.includes(l.id)).length;
      const col = K.colorOf(l.color);
      return h('div', { class: 'ltile-wrap' },
        h('a', { class: 'ltile', href: K.hashFor({ name: 'label', id: l.id }), style: col ? `box-shadow: inset 3px 0 0 ${col.hex}` : null },
          h('span', { class: 'ltile-ico', style: col ? `color:${col.hex}` : null, svg: icon(K.labelIcon(l), 18) }),
          h('span', { class: 'ltile-name' }, l.pinned ? K.pinMark() : null, l.name),
          h('span', { class: 'ltile-n' }, c ? String(c) : '')),
        h('button', { type: 'button', class: 'ltile-more', title: 'Opciones', 'aria-label': 'Opciones de la etiqueta: ' + l.name,
          svg: icon('more', 15), onclick: e => { e.preventDefault(); K.togglePop(e.currentTarget, () => K.menu(K.labelMenu(l, e.currentTarget))); } }));
    });
    const add = st.newLabel
      ? K.nameInput({ placeholder: 'Nombre de la etiqueta',
          onSubmit: name => { st.newLabel = false; const l = K.createLabel(name); K.refreshAll(); if (l) K.toast(`Etiqueta “${l.name}” creada`); },
          onCancel: () => { st.newLabel = false; K.refreshAll(); } })
      : h('button', { type: 'button', class: 'ltile ltile-new only-mobile', onclick: () => K.startNewLabel() },
          h('span', { class: 'ltile-ico', svg: icon('plus', 18) }), h('span', { class: 'ltile-name' }, 'Nueva etiqueta'));
    return h('div', { class: 'ltiles' }, tiles, add);
  }

  /* ---------- Render principal de notas ---------- */  /* ---------- Render principal de notas ---------- */
  K.renderList = () => {
    const st = K.state, r = st.route;
    const root = K.$('#main');
    root.replaceChildren();
    if (!K.isNotesRoute(r)) { K.renderModule(root, r); return; }

    const info = K.routeInfo(r);
    K.resetSelIfRouteChanged();
    const list = K.listFor(r);
    const q = st.query.trim();
    const overview = r.name === 'all' && !q;                    // Notas sin búsqueda: etiquetas + sin etiqueta

    const banner = K.backupBanner && K.backupBanner();
    if (banner) root.append(banner);
    root.append(h('div', { class: 'page-head' },
      h('h1', { class: 'page-title' }, h('span', { class: 'page-ico', svg: icon(info.icon, 26) }), info.title),
      h('p', { class: 'page-sub' }, q ? `${list.length} resultado${list.length === 1 ? '' : 's'} para “${q}”` : `${list.length} ${list.length === 1 ? 'nota' : 'notas'}`)));

    if (K.selIds().length) root.append(K.batchBar());
    if (overview) root.append(labelTiles());

    /* En una etiqueta: sus enlaces (cards), y sus bloques de la rutina y eventos */
    if (r.name === 'label') {
      const lab = K.labelById(r.id);
      if (lab) root.append(h('div', { class: 'label-cards' }, K.linkCards(lab, () => K.saveLabel(lab), { addable: true })));
    }

    /* En el archivo: las etiquetas archivadas, para desarchivarlas */
    if (r.name === 'archive') {
      const archived = st.labels.filter(l => l.archived);
      if (archived.length) {
        root.append(h('div', { class: 'banner archived-labels' }, h('span', {}, 'Etiquetas archivadas:'),
          h('span', { class: 'ab-list' }, archived.map(l => h('span', { class: 'ab-chip' }, l.name,
            h('button', { type: 'button', onclick: () => K.unarchiveLabel(l) }, 'Desarchivar'))))));
      }
    }

    if (r.name === 'trash' && list.length) {
      root.append(h('div', { class: 'banner' }, 'Las notas de la papelera se eliminan solas a los 7 días de enviadas.',
        h('button', { class: 'btn', type: 'button', onclick: K.emptyTrash }, 'Vaciar papelera')));
    }

    if (!list.length) {
      let [title, text] = q ? EMPTY.search : (EMPTY[r.name] || EMPTY.all);
      if (overview && st.notes.some(K.isLive)) [title, text] = EMPTY.none;
      root.append(h('div', { class: 'empty' }, h('h2', {}, title), h('p', {}, text)));
      return;
    }

    /* Fijadas arriba (orden propio), el resto debajo */
    const split = !q && ['all', 'label'].includes(r.name);
    const pinned = split ? list.filter(n => n.pinned).sort(K.byOrder) : [];
    const rest = split ? list.filter(n => !n.pinned) : list;
    const restLabel = r.name === 'all' ? 'Sin etiqueta' : 'Otras';
    const groups = pinned.length
      ? [{ label: 'Fijadas', notes: pinned, pinnedGroup: true }, { label: restLabel, notes: rest }]
      : [{ label: overview ? 'Sin etiqueta' : null, notes: rest }];

    if (K.noteView() === 'rows') root.append(h('div', { class: 'rows-head' },
      h('span', {}, 'Nombre'), h('span', { class: 'col-labels' }, 'Etiquetas'), h('span', { class: 'col-date' }, 'Modificada'), h('span')));
    groups.forEach(g => {
      if (!g.notes.length) return;
      const sec = h('section', { class: 'group' }, g.label ? h('h2', { class: 'group-label' }, g.label) : null);
      const box = h('div', { class: 'rows' + (K.noteView() === 'cards' ? ' cards' : ''), role: 'list' });
      const ctx = ctxFor(box, !!g.pinnedGroup);
      g.notes.forEach(n => box.append(rowEl(n, ctx, q)));
      sec.append(box);
      root.append(sec);
    });
  };

  /* Al cambiar el tamaño de la ventana (o rotar el celular) se rehace la vista si cambió entre escritorio y celular:
     el calendario muestra una grilla completa o un día por vez. */
  let mobileLayout = K.isMobile();
  K.relayoutAll = () => {
    const m = K.isMobile();
    if (m === mobileLayout) return;
    mobileLayout = m;
  };
})();
