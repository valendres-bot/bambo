/* =========================================================
   richinput.js — teclado, pegado, copiado y clics del editor visual.
   K.richInput(api, { onLink, onRef, onUrlCard, onLinkKey, onSelect })
   Enter, Backspace y Delete se manejan acá para que los bloques
   (texto, subtítulo, viñeta, casilla) siempre queden bien armados.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  K.richInput = (api, o = {}) => {
    const root = api.root;
    const br = () => document.createElement('br');
    let composing = false;

    const fixEmpty = b => { if (!b.textContent && !b.querySelector('[contenteditable="false"]')) b.replaceChildren(br()); };
    const dropBr = b => b.querySelectorAll('br').forEach(x => x.remove());
    const idx = b => api.blocks().indexOf(b);
    const multi = r => api.blockOf(r.startContainer) !== api.blockOf(r.endContainer);
    const scrollCaret = () => {
      const r = api.getRange();
      if (!r) return;
      const b = api.blockOf(r.startContainer);
      if (b && b.scrollIntoView) b.scrollIntoView({ block: 'nearest' });
    };

    /* Borra la selección (dentro de un bloque o entre varios) y deja el cursor en el corte */
    function deleteSel() {
      const r = api.getRange();
      if (!r || r.collapsed) return;
      const s0 = api.saveSel();
      const a = api.blockOf(r.startContainer), f = api.blockOf(r.endContainer);
      r.deleteContents();
      if (a && f && a !== f && f.isConnected) {
        dropBr(a); dropBr(f);
        a.append(...f.childNodes); f.remove();
      }
      if (a) { fixEmpty(a); api.tidy(a); a.normalize(); }
      api.restoreSel({ a: s0.a, f: s0.a });
    }

    /* Enter: parte el bloque en dos */
    function splitBlock() {
      if (!api.getRange()) return;
      deleteSel();
      const r = api.getRange();
      const b = api.blockOf(r.startContainer);
      if (!b) return;
      const k = b.dataset.k;
      if ((k === 't' || k === 'b') && !b.textContent) {            // casilla o viñeta vacía: sale de la lista
        b.dataset.k = 'p'; delete b.dataset.done;
        api.applyFolds(); api.commit(false); return;
      }
      if (b.classList.contains('folded')) api.toggleFold(b);
      const tail = document.createRange();
      tail.setStart(r.startContainer, r.startOffset); tail.setEnd(b, b.childNodes.length);
      const frag = tail.extractContents();
      const nb = K.makeEb(k === 'h' ? 'p' : k, false, '');
      nb.replaceChildren(frag);
      fixEmpty(nb); fixEmpty(b);
      b.after(nb);
      api.applyFolds();
      api.caretTo(nb, false);
      api.commit(false);
      scrollCaret();
    }

    /* Une el bloque `b` con el que está justo antes */
    function mergeUp(b) {
      const prev = b.previousElementSibling;
      if (!prev) return;
      if (api.isHidden(prev)) api.unfoldFor(prev);
      dropBr(prev); dropBr(b);
      const pos = { b: idx(prev), o: prev.textContent.length };
      prev.append(...b.childNodes); b.remove();
      fixEmpty(prev); api.tidy(prev); prev.normalize();
      api.applyFolds();
      api.restoreSel({ a: pos, f: pos });
      api.commit(false);
    }
    function mergeDown(b) {
      const next = b.nextElementSibling;
      if (!next) return;
      if (b.classList.contains('folded')) api.toggleFold(b);
      dropBr(b); dropBr(next);
      const pos = { b: idx(b), o: b.textContent.length };
      b.append(...next.childNodes); next.remove();
      fixEmpty(b); api.tidy(b); b.normalize();
      api.applyFolds();
      api.restoreSel({ a: pos, f: pos });
      api.commit(false);
    }

    /* ---------- Antes de que el navegador cambie algo ---------- */
    root.addEventListener('beforeinput', e => {
      const r = api.getRange();
      const t = e.inputType;
      if (t === 'historyUndo') { e.preventDefault(); api.undo(); return; }
      if (t === 'historyRedo') { e.preventDefault(); api.redo(); return; }
      if (t === 'formatBold') { e.preventDefault(); api.toggleFormat('strong'); return; }
      if (t === 'formatItalic') { e.preventDefault(); api.toggleFormat('em'); return; }
      if (/^format/.test(t)) { e.preventDefault(); return; }
      if (t === 'insertParagraph' || t === 'insertLineBreak') { e.preventDefault(); splitBlock(); return; }
      if (t === 'insertFromPaste' || t === 'insertFromPasteAsQuotation') { e.preventDefault(); return; }
      if (!r) return;

      if (/^delete/.test(t)) {
        if (!r.collapsed) {
          if (multi(r)) { e.preventDefault(); deleteSel(); api.commit(false); }
          return;
        }
        const b = api.blockOf(r.startContainer);
        if (!b) return;
        const back = /Backward$/.test(t) || t === 'deleteContentBackward';
        if (back && api.atStart()) {
          e.preventDefault();
          if (b.dataset.k !== 'p') { b.dataset.k = 'p'; delete b.dataset.done; api.applyFolds(); api.commit(false); }
          else mergeUp(b);
        } else if (!back && api.atEnd()) {
          e.preventDefault(); mergeDown(b);
        }
        return;
      }
      if (t === 'insertText' && !r.collapsed && multi(r) && e.data) {
        e.preventDefault();
        deleteSel();
        const r2 = api.getRange();
        const tn = document.createTextNode(e.data);
        r2.insertNode(tn);
        const c = document.createRange(); c.setStart(tn, tn.length); c.collapse(true); api.setRange(c);
        afterInput({ inputType: 'insertText', data: e.data });
      }
    });

    /* ---------- Después de cada cambio ---------- */
    function shortcuts(b) {
      if (b.dataset.k !== 'p') return false;
      const m = /^(#{1,2}|[-*]|\[\s?\]|-\s\[\s?\])[\s\u00a0]$/.exec(b.textContent);
      if (!m) return false;
      const t = m[1];
      b.dataset.k = /^#/.test(t) ? 'h' : /\[/.test(t) ? 't' : 'b';
      if (b.dataset.k === 't') b.dataset.done = '0';
      b.replaceChildren(br());
      api.caretTo(b, false);
      api.applyFolds();
      return true;
    }
    function autolink(e) {
      if (e.inputType !== 'insertText' || !/^[\s\u00a0]$/.test(e.data || '')) return;
      const r = api.getRange();
      if (!r || !r.collapsed || r.startContainer.nodeType !== 3) return;
      const n = r.startContainer;
      if (n.parentNode.closest && n.parentNode.closest('a')) return;
      const v = n.nodeValue.slice(0, r.startOffset);
      const m = /(https?:\/\/[^\s\u00a0<>()[\]]*[^\s\u00a0<>()[\].,;:!?])[\s\u00a0]$/.exec(v);
      if (!m) return;
      const url = m[1], start = m.index, caret = r.startOffset - (start + url.length);
      const mid = n.splitText(start);
      const rest = mid.splitText(url.length);
      const a = K.inlineNodes(url)[0];
      mid.replaceWith(a);
      const c = document.createRange(); c.setStart(rest, caret); c.collapse(true); api.setRange(c);
    }
    function afterInput(e) {
      if (composing) return;
      api.sanitize();
      const r = api.getRange();
      const b = r && api.blockOf(r.startContainer);
      let structural = false;
      if (b) { structural = shortcuts(b); autolink(e); api.tidy(b); }
      api.commit(!structural);
    }
    root.addEventListener('input', afterInput);
    root.addEventListener('compositionstart', () => { composing = true; });
    root.addEventListener('compositionend', () => { composing = false; afterInput({ inputType: 'insertText', data: '' }); });

    /* ---------- Teclado ---------- */
    root.addEventListener('keydown', e => {
      const mod = e.ctrlKey || e.metaKey;
      if (!mod || e.altKey || composing) return;
      const k = e.key.toLowerCase();
      if (k === 'b') { e.preventDefault(); api.toggleFormat('strong'); }
      else if (k === 'i') { e.preventDefault(); api.toggleFormat('em'); }
      else if (k === 'k') { e.preventDefault(); o.onLinkKey && o.onLinkKey(); }
      else if (k === 'h' && e.shiftKey) { e.preventDefault(); api.toggleFormat('mark'); }
      else if (k === 'z') { e.preventDefault(); e.shiftKey ? api.redo() : api.undo(); }
      else if (k === 'y') { e.preventDefault(); api.redo(); }
    });

    /* ---------- Clics: casillas, plegado y enlaces ---------- */
    root.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('a');
      if (a && root.contains(a)) {
        e.preventDefault();
        if (a.dataset.ref != null) { o.onRef && o.onRef(a.dataset.ref, a); return; }
        if (e.ctrlKey || e.metaKey) { window.open(a.dataset.url, '_blank', 'noopener,noreferrer'); return; }
        o.onLink && o.onLink(a);
        return;
      }
      const b = e.target;
      if (!b.classList || !b.classList.contains('eb')) return;
      const rc = b.getBoundingClientRect();
      /* Las casillas no se tildan desde la nota: eso se hace solo en Pendientes (K.toggleTask) */
      if (b.dataset.k === 'h' && e.clientX < rc.left + 2 && e.clientX > rc.left - 36) {
        api.toggleFold(b);
        o.onFold && o.onFold();
      }
    });
    /* Las casillas y flechas no deben mover el cursor al tocarlas */
    root.addEventListener('mousedown', e => {
      const b = e.target;
      if (!b.classList || !b.classList.contains('eb')) return;
      const rc = b.getBoundingClientRect();
      if (b.dataset.k === 'h' && e.clientX < rc.left + 2) e.preventDefault();
    });

    /* ---------- Copiar, cortar y pegar ---------- */
    function selectionMarkup() {
      const r = api.getRange();
      if (!r || r.collapsed) return null;
      const tmp = document.createElement('div');
      tmp.append(r.cloneContents());
      const kids = [...tmp.children].filter(c => c.classList.contains('eb'));
      if (kids.length) return { markup: K.serBlocks(kids), plain: kids.map(x => x.textContent).join('\n') };
      return { markup: K.serInline(tmp), plain: tmp.textContent };
    }
    api.copyText = () => selectionMarkup();
    function setClip(e) {
      const c = selectionMarkup();
      if (!c) return false;
      e.preventDefault();
      e.clipboardData.setData('text/plain', c.plain);
      e.clipboardData.setData('application/x-mikeep', c.markup);
      return true;
    }
    root.addEventListener('copy', e => { setClip(e); });
    root.addEventListener('cut', e => { if (setClip(e)) { deleteSel(); api.commit(false); } });

    /* Inserta texto con marcas en el cursor (una o varias líneas) */
    api.insertMarkup = raw => {
      const lines = K.parseBody(raw);
      deleteSel();
      let r = api.getRange();
      if (!r) return;
      let b = api.blockOf(r.startContainer);
      const putInline = (text) => {
        const frag = document.createDocumentFragment();
        frag.append(...K.inlineNodes(text));
        const last = frag.lastChild;
        if (!last) return;
        const rr = api.getRange();
        rr.insertNode(frag);
        const c = document.createRange(); c.setStartAfter(last); c.collapse(true); api.setRange(c);
      };
      if (lines.length === 1) {
        if (!b.textContent && lines[0].k !== 'p') { b.dataset.k = lines[0].k; if (lines[0].k === 't') b.dataset.done = lines[0].done ? '1' : '0'; b.replaceChildren(); }
        putInline(lines[0].text);
      } else {
        const tail = document.createRange();
        tail.setStart(r.startContainer, r.startOffset); tail.setEnd(b, b.childNodes.length);
        const rest = tail.extractContents();
        if (!b.textContent && lines[0].k !== 'p') { b.dataset.k = lines[0].k; if (lines[0].k === 't') b.dataset.done = lines[0].done ? '1' : '0'; }
        b.querySelectorAll('br').forEach(x => x.remove());
        api.caretTo(b, true);
        putInline(lines[0].text);
        let prev = b;
        lines.slice(1).forEach(l => { const nb = K.makeEb(l.k, l.done, l.text, l.id); prev.after(nb); prev = nb; });
        dropBr(prev);
        const pos = { b: idx(prev), o: prev.textContent.length };
        prev.append(rest);
        fixEmpty(prev);
        api.restoreSel({ a: pos, f: pos });
      }
      api.sanitize();
      const rr = api.getRange();
      const cb = rr && api.blockOf(rr.startContainer);
      if (cb) api.tidy(cb);
      api.applyFolds();
      api.commit(false);
      scrollCaret();
    };

    root.addEventListener('paste', e => {
      e.preventDefault();
      const cd = e.clipboardData;
      if (!cd) return;
      const mk = cd.getData('application/x-mikeep');
      const txt = cd.getData('text/plain').replace(/\r\n?/g, '\n');
      if (mk) { api.insertMarkup(mk); return; }
      if (!txt) return;
      const one = txt.trim();
      if (/^https?:\/\/[^\s]+$/.test(one)) {
        const r = api.getRange();
        if (r && !r.collapsed && !multi(r)) { api.applyLink(r, one); return; }
        const b = r && api.blockOf(r.startContainer);
        if (b && b.dataset.k === 'p' && !b.textContent && o.onUrlCard && o.onUrlCard(one)) return;
      }
      api.insertMarkup(txt.replace(/\n{3,}/g, '\n\n'));
    });

    /* Arrastrar un enlace desde otra pestaña lo convierte en card */
    root.addEventListener('dragover', e => {
      if (e.dataTransfer && [...e.dataTransfer.types].includes('text/uri-list') && o.onUrlCard) e.preventDefault();
    });
    root.addEventListener('drop', e => {
      const u = e.dataTransfer && e.dataTransfer.getData('text/uri-list');
      const url = u && u.split('\n').find(x => /^https?:\/\//.test(x));
      if (url && o.onUrlCard) { e.preventDefault(); o.onUrlCard(url.trim()); }
    });

    /* ---------- Selección: avisa a las barras ---------- */
    let raf = 0;
    const onSel = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => { if (api.getRange() && o.onSelect) o.onSelect(); });
    };
    document.addEventListener('selectionchange', onSel);
    api.destroy = () => { document.removeEventListener('selectionchange', onSel); cancelAnimationFrame(raf); };
  };
})();
