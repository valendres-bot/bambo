/* =========================================================
   storage.js — CAPA DE DATOS
   Es el único archivo que cambiás para conectar una base de datos.
   Guarda en IndexedDB (base "tempo", versión 2): una tabla por colección
   (notes, labels, blocks, events, sessions, versions) con un registro por ítem.
   Si el navegador no la ofrece, usa localStorage como respaldo.

   Cómo funciona:
   · La copia de trabajo vive en memoria. Cada cambio se escribe una sola vez,
     agrupado (300 ms después del último cambio). Solo se escriben los registros
     que cambiaron: editar una nota no reescribe el historial ni las demás notas.
   · Las escrituras se hacen una por una (en cola), así nunca se pisan.
   · Al esconder la pestaña se pide escribir lo pendiente. Si aún queda algo sin
     guardar (K.hasPendingWrites()), el navegador pide confirmación antes de cerrar.
   · Cada registro lleva rev (número que sube en cada guardado) y updatedAt.
   · BORRADO LÓGICO (tombstones): borrar un registro no lo quita del disco; lo reemplaza
     por { id, deleted: true, rev, updatedAt }. K.api.load() nunca los devuelve a la app.
     Así, cuando haya sincronización, el borrado se propaga a los otros dispositivos.
     Los tombstones de más de TOMB_DAYS días se descartan del disco al arrancar.
   · Varias pestañas: al recibir aviso de otra pestaña se relee el disco y se fusiona
     por registro (lo que tocó esta pestaña y todavía no se escribió gana; lo demás
     viene del disco). Cada escritura avisa por BroadcastChannel y la app recibe
     'mikeep:external'.
   · Migración: si la base nueva está vacía, se copia lo que haya en la fila única
     de la versión anterior ('datos') o en localStorage, y recién después se borra el original.
   · Si la base queda bloqueada porque otra pestaña tiene una versión anterior abierta,
     se espera a que la cierre y se avisa con el estado 'error'.
   · Si lo guardado en localStorage está dañado (no es JSON válido), se deja una copia aparte
     en 'mi-keep:v4:corrupt' (localStorage, para que siempre se pueda descargar).
   · Colecciones: notes, labels, blocks, events, sessions, versions, tasks (pendientes), goals (objetivos)
     y slots (franjas horarias de un día, en Hoy).
   · Versión 4 de la base: se agregó la tabla goals. Al cargar, las materias de versiones anteriores se
     convierten en objetivos (K.convertMaterias; ver más abajo).
   · Versión 5 de la base: se agregó la tabla slots (franjas de Hoy). No cambia lo que ya había.
   · Estado del guardado: evento 'mikeep:save' con detail 'saving' | 'saved' | 'error'.
     Si falla, se reintenta solo y la app lo muestra.

   Para un backend propio reemplazá K.api (mismas firmas) así:

   const BASE = 'http://localhost:3000/api';
   const J = { 'Content-Type': 'application/json' };
   K.api = {
     load:        async () => (await fetch(`${BASE}/data`)).json(),   // -> { notes: [], labels: [] } (sin tombstones)
     saveNote:    n  => fetch(`${BASE}/notes/${n.id}`,   { method: 'PUT',    headers: J, body: JSON.stringify(n) }),
     deleteNote:  id => fetch(`${BASE}/notes/${id}`,     { method: 'DELETE' }),   // el servidor guarda el tombstone
     ...
     clearAll:    ()  => fetch(`${BASE}/data`, { method: 'DELETE' }),
   };
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  const KEY = 'mi-keep:v4';               // clave de localStorage (modo sin IndexedDB y migración)
  const DB_NAME = 'tempo', DB_VERSION = 5;
  const LEGACY = 'kv', LEGACY_ROW = 'datos';   // base de la versión anterior: una sola fila con todo
  const DELAY = 300;                      // ms de espera antes de escribir
  const RETRY = 5000;                     // ms entre reintentos si falla
  const TOMB_DAYS = 90;                   // un borrado se conserva este tiempo antes de descartarse

  const clone = x => JSON.parse(JSON.stringify(x));
  const COLLS = ['notes', 'labels', 'blocks', 'events', 'sessions', 'versions', 'tasks', 'goals', 'slots'];
  const NEWEST_FIRST = new Set(['notes', 'blocks', 'events']);   // en la copia en memoria, lo nuevo va arriba
  const CORRUPT_KEY = KEY + ':corrupt';
  K.CORRUPT_KEY = CORRUPT_KEY;
  K.storageRescued = false;

  /* ---------- Metadatos de sincronización ----------
     rev       → versión del registro: sube en cada guardado (se compara número, no fecha).
     updatedAt → última modificación. Los datos viejos pueden no traerlos. */

  /* Copia limpia para guardar. rev = el mayor entre el de la app y el guardado, + 1: nunca se repite.
     `old` es el registro que ya está en la copia en memoria (o undefined). */
  const stamp = (old, item) => {
    const c = clone(item);
    c.rev = Math.max(Number(item.rev) || 0, old ? Number(old.rev) || 0 : 0) + 1;
    if (!Number.isFinite(c.updatedAt)) c.updatedAt = Date.now();
    item.rev = c.rev;
    return c;
  };

  /* Al leer, los registros viejos reciben rev 0. */
  const withMeta = arr => (Array.isArray(arr) ? arr : [])
    .filter(x => x && typeof x === 'object' && x.id != null)
    .map(x => ({ ...x, rev: Number.isFinite(x.rev) ? x.rev : 0 }));

  /* ---------- Conflictos y fechas de modificación ----------
     stampOf: la fecha de modificación solo vale si es un número finito y no negativo; si no, es null (no comparable). */
  const stampOf = x => (x && Number.isFinite(x.updatedAt) && x.updatedAt >= 0 ? x.updatedAt : null);
  const okStamp = v => Number.isFinite(v) && v >= 0;
  /* Registros que llegaron sin fecha válida: no se les inventa una fecha para decidir conflictos */
  const unstamped = new Set();                       // claves "coleccion\u0000id"
  const keyOf = (c, id) => c + '\u0000' + id;
  const markRec = (c, x) => { if (stampOf(x) == null) unstamped.add(keyOf(c, x.id)); return normRec(c, x); };
  /* Igualdad de contenido, ignorando rev y updatedAt (el orden de las claves no cuenta) */
  const stableStr = v => JSON.stringify(v, (k, x) => (x && typeof x === 'object' && !Array.isArray(x)
    ? Object.fromEntries(Object.keys(x).sort().map(kk => [kk, x[kk]])) : x));
  const sameContent = (a, b) => {
    /* null y ausente son lo mismo (campos nuevos como dur o pos): no cuentan como cambio */
    const strip = x => { const r = { ...x }; delete r.rev; delete r.updatedAt; for (const k of Object.keys(r)) if (r[k] == null) delete r[k]; return r; };
    return stableStr(strip(a)) === stableStr(strip(b));
  };
  /* Qué hacer con un registro que llega, frente al que ya hay:
     'add' no existe · 'same' es igual · 'replace' el que llega es más reciente · 'kept' el local es más reciente ·
     'conflict' no se puede saber cuál es más reciente: se conserva el local. */
  const resolveRecord = (local, incoming, localStamp, incomingStamp) => {
    if (!local) return 'add';
    if (sameContent(local, incoming)) return 'same';
    if (!okStamp(localStamp) || !okStamp(incomingStamp)) return 'conflict';
    if (incomingStamp > localStamp) return 'replace';
    if (incomingStamp < localStamp) return 'kept';
    return 'conflict';
  };
  K.resolveRecord = resolveRecord;
  K.stampOf = stampOf;

  /* Los tombstones viejos ya no se conservan (ver TOMB_DAYS) */
  const cutoff = () => Date.now() - TOMB_DAYS * 864e5;
  const fresh = x => !x.deleted || (Number(x.updatedAt) || 0) >= cutoff();

  /* Normaliza un registro leído (campos por defecto y pin unificado). Los tombstones no cambian. */
  const normRec = (c, x) => {
    if (x.deleted) return x;
    if (c === 'labels') return K.normalizeLabel(x);
    if (c === 'notes') return K.noteDefaults(x);
    if (c === 'goals') return K.normalizeGoal(x);
    if (c === 'tasks') return { goalId: null, projectId: null, blockId: null, ...x };   // pendientes de versiones viejas: sin objetivo ni franja
    return x;
  };

  /* IndexedDB devuelve los registros ordenados por id (aleatorio). Se reordena por fecha de alta
     para que la copia en memoria quede como antes: lo nuevo arriba en notas, bloques y eventos. */
  const sortLoaded = (c, arr) => arr.sort((a, b) => {
    const d = (Number(a.createdAt) || 0) - (Number(b.createdAt) || 0);
    if (d) return NEWEST_FIRST.has(c) ? -d : d;
    /* Empate (misma fecha): desempate por id, así el orden no cambia entre una carga y otra */
    const x = String(a.id), y = String(b.id);
    return x < y ? -1 : x > y ? 1 : 0;
  });

  /* Forma vacía o normalizada: convierte lo leído (un array por colección) en la copia de trabajo */
  const EMPTY = () => Object.fromEntries(COLLS.map(c => [c, []]));
  /* Versiones viejas guardaban las capturas en una nota oculta con este id. Hoy no existe: se descarta al cargar. */
  const LEGACY_QUICK_NOTE = 'inbox-tasks';
  function normalizeCollections(src) {
    const out = EMPTY();
    COLLS.forEach(c => {
      out[c] = withMeta(src && src[c]).filter(fresh).filter(x => !(c === 'notes' && x && x.id === LEGACY_QUICK_NOTE)).map(x => markRec(c, x));
      sortLoaded(c, out[c]);
    });
    return out;
  }

  /* ---------- Materias → Objetivos (1.24.0) ----------
     Una materia era una etiqueta con kind 'materia'. Ahora es un objetivo de ámbito académico.
     La conversión es pura (K.convertMaterias) y deja la etiqueta como etiqueta común:
     · el objetivo nace con id determinístico "goal-<id de la etiqueta>": repetirla no duplica nada;
     · sus sesiones de foco pasan a apuntar al objetivo (el tiempo acumulado se conserva);
     · los pendientes que tenían esa materia quedan vinculados al objetivo, si no tenían otro;
     · la etiqueta sigue existiendo, con sus notas, color y orden.
     Se ejecuta al cargar: si no hay materias, no hace nada. */
  K.goalIdFor = labelId => 'goal-' + labelId;
  K.goalFromMateria = (l, now) => ({
    id: K.goalIdFor(l.id), name: String(l.name || 'Sin nombre'), description: '', category: 'academica',
    archived: false, startDate: null, deadline: null, color: typeof l.color === 'string' ? l.color : null,
    projects: [], resources: [], legacyLabelId: l.id,
    createdAt: l.createdAt || now, updatedAt: now, rev: 1,
  });
  K.convertMaterias = data => {
    const mats = (data.labels || []).filter(l => l && !l.deleted && l.kind === 'materia');
    if (!mats.length) return { ops: [], next: data };
    const now = Date.now();
    const matIds = new Set(mats.map(l => l.id));
    const goalOf = new Map(mats.map(l => [l.id, K.goalIdFor(l.id)]));
    const nameOf = new Map(mats.map(l => [l.id, l.name]));
    const have = new Set((data.goals || []).map(g => g.id));
    const ops = [];
    const bump = (o, extra) => ({ ...o, ...extra, rev: (Number(o.rev) || 0) + 1, updatedAt: now });

    const labels = data.labels.map(l => {
      if (!matIds.has(l.id)) return l;
      const rec = bump(l, { kind: 'area' }); ops.push({ c: 'labels', rec }); return rec;
    });
    const goals = [...(data.goals || [])];
    mats.forEach(l => {
      if (have.has(goalOf.get(l.id))) return;
      const rec = K.goalFromMateria(l, now); goals.push(rec); ops.push({ c: 'goals', rec });
    });
    const sessions = data.sessions.map(s => {
      if (!(s.target && s.target.kind === 'label' && matIds.has(s.target.id))) return s;
      const rec = bump(s, { target: { kind: 'goal', id: goalOf.get(s.target.id), name: nameOf.get(s.target.id) } });
      ops.push({ c: 'sessions', rec }); return rec;
    });
    const tasks = data.tasks.map(t => {
      const mine = (t.labels || []).find(id => matIds.has(id));
      if (!mine || t.goalId) return t;
      const rec = bump(t, { goalId: goalOf.get(mine), projectId: t.projectId || null });
      ops.push({ c: 'tasks', rec }); return rec;
    });
    return { ops, next: { ...data, labels, goals, sessions, tasks } };
  };

  /* Escribe la conversión (si hay algo que convertir) y devuelve los datos ya convertidos.
     Con IndexedDB, todo en una transacción; con localStorage, en un solo setItem. */
  async function convertStored(data) {
    const conv = K.convertMaterias(data);
    if (!conv.ops.length) return data;
    if (mode === 'ls') localStorage.setItem(KEY, JSON.stringify(conv.next));
    else await applyOps(conv.ops.map(o => ({ c: o.c, id: o.rec.id, rec: o.rec })));
    return conv.next;
  }

  /* ---------- Lectura/escritura en localStorage (modo sin IndexedDB y migración) ---------- */
  /* Lo guardado ilegible se aparta (una sola vez) para no perderlo cuando se vuelva a escribir */
  const rescue = raw => {
    K.storageRescued = true;
    try { if (localStorage.getItem(CORRUPT_KEY) == null) localStorage.setItem(CORRUPT_KEY, raw); } catch { /* sin espacio */ }
  };
  const readLs = () => {
    let raw;
    try { raw = localStorage.getItem(KEY); } catch { return null; }
    if (raw == null) return null;
    try { return JSON.parse(raw); } catch { rescue(raw); return null; }
  };

  /* ---------- Estado del guardado ---------- */
  const setStatus = s => {
    window.dispatchEvent(new CustomEvent('mikeep:save', { detail: s }));
  };

  /* ---------- IndexedDB ---------- */
  let dbP = null;
  let mode = 'idb';                       // 'ls' si no hay IndexedDB: se guarda en localStorage
  const getDb = () => dbP || (dbP = new Promise((res, rej) => {
    if (!window.indexedDB) { rej(new Error('sin IndexedDB')); return; }
    const r = indexedDB.open(DB_NAME, DB_VERSION);
    r.onupgradeneeded = () => {
      const db = r.result;
      COLLS.forEach(c => { if (!db.objectStoreNames.contains(c)) db.createObjectStore(c, { keyPath: 'id' }); });
      if (!db.objectStoreNames.contains(LEGACY)) db.createObjectStore(LEGACY);
    };
    r.onsuccess = () => {
      const db = r.result;
      // Otra pestaña necesita abrir la base con una versión nueva: soltamos la conexión
      db.onversionchange = () => { db.close(); dbP = null; };
      res(db);
    };
    r.onerror = () => { dbP = null; rej(r.error); };
    // Hay otra pestaña con la versión anterior abierta: esperamos a que la cierre
    r.onblocked = () => setStatus('error');
  }));

  const txDone = t => new Promise((res, rej) => {
    t.oncomplete = () => res();
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error || new Error('transacción cancelada'));
  });

  /* Lee todas las colecciones (y la fila de la versión anterior) en una sola transacción de lectura */
  async function readAll() {
    const t = (await getDb()).transaction([...COLLS, LEGACY], 'readonly');
    const reqs = COLLS.map(c => t.objectStore(c).getAll());
    const legacy = t.objectStore(LEGACY).get(LEGACY_ROW);
    const done = txDone(t);
    await done;
    const stores = {};
    COLLS.forEach((c, i) => { stores[c] = reqs[i].result || []; });
    return { stores, legacy: legacy.result };
  }

  /* Aplica cambios en una sola transacción (todo o nada).
     ops: [{ c, id, rec }]  → rec undefined = borrar ese registro.
     clear: vacía todas las colecciones antes. dropLegacy: borra la fila de la versión anterior. */
  async function applyOps(ops, { clear = false, dropLegacy = false } = {}) {
    const names = clear ? [...COLLS] : [...new Set(ops.map(o => o.c))];
    if (dropLegacy) names.push(LEGACY);
    if (!names.length) return;
    const t = (await getDb()).transaction(names, 'readwrite');
    const done = txDone(t);
    done.catch(() => {});                          // el error se trata abajo; evita un "rechazo no manejado"
    try {
      if (clear) COLLS.forEach(c => t.objectStore(c).clear());
      ops.forEach(o => {
        const s = t.objectStore(o.c);
        if (o.rec === undefined) s.delete(o.id); else s.put(o.rec);
      });
      if (dropLegacy) t.objectStore(LEGACY).delete(LEGACY_ROW);
    } catch (err) {
      // Si una escritura no se pudo preparar, se cancela TODO el lote. Sin esto, IndexedDB confirmaría lo anterior.
      try { t.abort(); } catch { /* la transacción ya había terminado */ }
      throw err;
    }
    await done;
  }

  /* Todos los registros de una copia como operaciones de escritura */
  const recordOps = data => COLLS.flatMap(c => data[c].map(rec => ({ c, id: rec.id, rec: clone(rec) })));

  /* Descarta de la base los borrados lógicos vencidos (sin bloquear la carga) */
  function pruneStale(stores) {
    const ops = COLLS.flatMap(c => stores[c].filter(x => x.deleted && !fresh(x)).map(x => ({ c, id: x.id })));
    if (ops.length) enqueue(() => applyOps(ops));
  }

  /* Copia que quedó en localStorage (sesión sin IndexedDB o versión anterior) cuando IndexedDB ya tiene datos.
     Se fusiona registro por registro con la misma regla de conflictos. Sus versiones de notas reemplazadas
     se conservan en el historial. Devuelve cuántos conflictos quedaron sin resolver. */
  async function mergeStranded(stores, left) {
    const byId = Object.fromEntries(COLLS.map(c => [c, new Map(stores[c].map(x => [x.id, x]))]));
    const ops = [];
    let conflicts = 0;
    COLLS.forEach(c => {
      withMeta(left[c]).forEach(rec => {
        const local = byId[c].get(rec.id);
        const action = resolveRecord(local, rec, stampOf(local), stampOf(rec));
        if (action === 'conflict') { conflicts++; return; }
        if (action !== 'add' && action !== 'replace') return;
        ops.push({ c, rec, old: local });
        byId[c].set(rec.id, rec);
      });
    });
    if (ops.length) {
      const recs = ops.map(o => ({ c: o.c, rec: stamp(o.old, o.rec) }));
      await applyOps(recs.map(({ c, rec }) => ({ c, id: rec.id, rec: clone(rec) })));   // todo o nada
      applyRecs(stores, recs);
    }
    return { conflicts, applied: ops.length };
  }

  /* Primer arranque: abre la base y, si está vacía, migra lo que haya en la versión anterior o en localStorage. */
  async function loadAllRaw() {
    if (!window.indexedDB) {                       // navegador sin IndexedDB: único caso de respaldo en localStorage
      mode = 'ls';
      if (K.toast) K.toast('Este navegador no tiene IndexedDB: tus datos se guardan en localStorage, con menos espacio.');
      return normalizeCollections(readLs());
    }
    mode = 'idb';
    // Si la base no abre o no se puede leer, el error sube a la app. No se cambia a localStorage en silencio.
    const { stores, legacy } = await readAll();
    const empty = COLLS.every(c => stores[c].length === 0);

    if (empty && legacy && Array.isArray(legacy.notes)) {       // migración desde la fila única
      const data = normalizeCollections(legacy);
      await applyOps(recordOps(data), { dropLegacy: true });
      return data;
    }
    const left = readLs();
    if (left && typeof left === 'object') {
      if (empty && Array.isArray(left.notes)) {                  // migración desde localStorage
        const data = normalizeCollections(left);
        await applyOps(recordOps(data));
        try { localStorage.removeItem(KEY); } catch { /* nada que liberar */ }
        return data;
      }
      const r = await mergeStranded(stores, left);
      if (r.conflicts === 0) { try { localStorage.removeItem(KEY); } catch { /* nada que liberar */ } }
      else if (K.toast) K.toast(`${r.conflicts} ${r.conflicts === 1 ? 'conflicto' : 'conflictos'} al recuperar datos de localStorage: se conservó la copia local y no se borró.`);
      if (r.applied && K.toast) K.toast('Se recuperaron cambios que habían quedado guardados en localStorage.');
    }
    pruneStale(stores);
    return normalizeCollections(stores);
  }

  /* ---------- Copia en memoria y escritura diferida ---------- */
  let cache = null;        // { notes, labels, blocks, events, sessions, versions } (incluye tombstones)
  let loading = null;      // promesa de la carga inicial
  let dirty = false;       // hay cambios sin escribir
  let writing = false;     // hay una escritura en curso
  let timer = 0;
  let replaceAll = false;  // "borrar todo": se escribe tal cual, sin fusionar con lo guardado
  let maps = {};           // coll -> Map(id -> registro): búsqueda por id sin recorrer las listas

  /* Qué registros tocó ESTA pestaña desde el último guardado: id → 'put' | 'del' */
  const newPending = () => Object.fromEntries(COLLS.map(c => [c, new Map()]));
  const newOps = newPending;
  let pending = newPending();
  const mark = (coll, id, op) => pending[coll].set(id, op);

  const mapOf = coll => maps[coll] || (maps[coll] = new Map(cache[coll].map(x => [x.id, x])));
  /* Reemplaza el contenido de un objeto conservando la referencia (la copia en memoria no se reordena) */
  const wipe = o => { Object.keys(o).forEach(k => delete o[k]); };

  /* Une lo que hay en disco con la copia de esta pestaña, conservando el orden de la copia.
     Lo que esta pestaña todavía no escribió (pendiente, o en curso en `inFlight`) gana; lo demás viene del disco. */
  function mergeCollection(c, mine, theirs, inFlight) {
    const touched = id => pending[c].has(id) || (inFlight && inFlight[c].has(id));
    const disk = new Map(theirs.map(x => [x.id, x]));
    const out = [], seen = new Set();
    mine.forEach(x => {
      seen.add(x.id);
      if (touched(x.id)) { if (fresh(x)) out.push(x); return; }
      const d = disk.get(x.id);
      if (d && fresh(d)) out.push(markRec(c, d));
    });
    theirs.forEach(x => { if (!seen.has(x.id) && fresh(x)) out.push(markRec(c, x)); });
    return out;
  }

  /* Modo localStorage: el disco es un solo objeto */
  async function mergeFromDisk(inFlight) {
    const disk = readLs();
    if (!disk || !Array.isArray(disk.notes) || !cache) return;
    COLLS.forEach(c => { cache[c] = mergeCollection(c, cache[c], withMeta(disk[c]), inFlight); });
    maps = {};
  }

  /* Modo IndexedDB: relee las colecciones y fusiona */
  async function reloadFromDisk() {
    const { stores } = await readAll();
    COLLS.forEach(c => { cache[c] = mergeCollection(c, cache[c], withMeta(stores[c]), null); });
    maps = {};
  }

  /* Cola: una operación a la vez (escrituras y relecturas de otras pestañas) */
  let chain = Promise.resolve();
  const enqueue = fn => { chain = chain.then(fn).catch(e => console.error(e)); return chain; };

  /* Registros tocados por esta pestaña, con su valor actual (o como borrado si ya no están en la copia) */
  const touchedOps = ops => COLLS.flatMap(c => [...ops[c].keys()].map(id => {
    const rec = mapOf(c).get(id);
    return rec ? { c, id, rec: clone(rec) } : { c, id };
  }));

  async function doFlush() {
    if (!dirty || !cache) return;
    writing = true;
    const ops = pending, replace = replaceAll;
    pending = newPending(); replaceAll = false; dirty = false;
    try {
      if (mode === 'ls') {
        if (!replace) await mergeFromDisk(ops);
        localStorage.setItem(KEY, JSON.stringify(cache));
      } else if (replace) {
        await applyOps(recordOps(cache), { clear: true });
      } else {
        await applyOps(touchedOps(ops));
      }
      announce();
      if (!dirty) setStatus('saved');
    } catch (err) {
      console.error(err);
      // Vuelve a quedar pendiente: lo anterior primero, lo nuevo encima
      COLLS.forEach(c => { const m = new Map(ops[c]); pending[c].forEach((op, id) => m.set(id, op)); pending[c] = m; });
      replaceAll = replaceAll || replace;
      dirty = true;
      setStatus('error');                  // sigue intentando; la copia en memoria no se pierde
      clearTimeout(timer); timer = setTimeout(flush, RETRY);
    } finally {
      writing = false;
    }
  }

  function flush() {
    clearTimeout(timer); timer = 0;
    return enqueue(doFlush);
  }

  function touch() {
    dirty = true;
    setStatus('saving');
    clearTimeout(timer);
    timer = setTimeout(flush, DELAY);
  }

  /* ---------- Varias pestañas ---------- */
  const channel = 'BroadcastChannel' in window ? new BroadcastChannel('tempo-datos') : null;
  const announce = () => { try { if (channel) channel.postMessage('guardado'); } catch { /* sin canal */ } };
  async function refreshFromOthers() {
    if (!cache) return;
    if (mode === 'ls') await mergeFromDisk(newOps());
    else await reloadFromDisk();
    window.dispatchEvent(new CustomEvent('mikeep:external'));
  }
  if (channel) channel.onmessage = () => enqueue(refreshFromOthers);
  /* Con localStorage (sin IndexedDB) las otras pestañas avisan por el evento 'storage' */
  window.addEventListener('storage', e => { if (mode === 'ls' && e.key === KEY && cache) enqueue(refreshFromOthers); });

  window.addEventListener('pagehide', () => { flush(); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });

  /* ¿Hay cambios que todavía no se escribieron (en espera, en curso o con error)? */
  K.hasPendingWrites = () => dirty || writing;

  /* Al cerrar la pestaña: pide escribir y, si algo no se guardó, el navegador pregunta antes de salir */
  window.addEventListener('beforeunload', e => {
    if (K.hasPendingWrites()) { flush(); e.preventDefault(); e.returnValue = ''; }
  });

  /* Carga única; las llamadas siguientes reciben la misma promesa */
  /* Migración al cargar (1.26.4): rutinas y franjas a una sola colección. Las escrituras van en la misma base. */
  const migrateLoaded = async data => {
    const m = K.migrateStored(data);
    if (m.ops.length && mode === 'idb') await applyOps(m.ops);
    return m.data;
  };
  const ensure = () => loading || (loading = loadAllRaw().then(migrateLoaded).then(convertStored).then(c => (cache = c), e => { loading = null; throw e; }));

  /* Lo que ve la app: todo menos los tombstones */
  const live = c => Object.fromEntries(COLLS.map(k => [k, c[k].filter(x => !x.deleted)]));

  /* Alta o cambio de un registro. Si existe, se actualiza en su lugar (búsqueda por id: O(1)). */
  async function put(coll, item, front) {
    const c = await ensure();
    const idx = mapOf(coll), old = idx.get(item.id);
    const rec = stamp(old, item);
    if (old) { wipe(old); Object.assign(old, rec); }
    else { if (front) c[coll].unshift(rec); else c[coll].push(rec); idx.set(rec.id, rec); }
    mark(coll, item.id, 'put');
    unstamped.delete(keyOf(coll, item.id));
    touch();
  }

  /* Borrado lógico de un registro: el tombstone reemplaza al registro (o se agrega si no existía) */
  async function kill(coll, id) {
    const c = await ensure();
    const idx = mapOf(coll), old = idx.get(id);
    const t = { id, deleted: true, rev: (old ? Number(old.rev) || 0 : 0) + 1, updatedAt: Date.now() };
    if (old) { wipe(old); Object.assign(old, t); }
    else { c[coll].push(t); idx.set(id, t); }
    mark(coll, id, 'del');
    unstamped.delete(keyOf(coll, id));
    touch();
  }

  /* Aplica registros ya sellados (con rev) sobre una colección, conservando las referencias existentes.
     skip(coleccion, id) → true deja ese registro como está (lo que el usuario tocó mientras escribíamos). */
  function applyRecs(target, recs, skip) {
    const idx = Object.fromEntries(COLLS.map(c => [c, new Map(target[c].map(x => [x.id, x]))]));
    recs.forEach(({ c, rec }) => {
      if (skip && skip(c, rec.id)) return;
      const old = idx[c].get(rec.id);
      unstamped.delete(keyOf(c, rec.id));
      if (old) { wipe(old); Object.assign(old, rec); }
      else {
        if (NEWEST_FIRST.has(c)) target[c].unshift(rec); else target[c].push(rec);
        idx[c].set(rec.id, rec);
      }
    });
  }

  /* Serializa una operación y devuelve su resultado o su error (a diferencia de enqueue, no lo traga) */
  const serial = fn => { const p = chain.then(fn); chain = p.catch(e => console.error(e)); return p; };

  /* Operación de varios registros (p. ej. una importación). plan(copia, marcaSinFecha) → { ops: [{c, rec}], result }.
     El plan se arma sobre una copia: si algo falla, lo guardado y lo que ve la app no cambian.
     Con IndexedDB, todos los registros se escriben en UNA transacción. Con localStorage, en un solo setItem.
     Garantía real: atómica dentro de cada almacén. Entre IndexedDB y localStorage no hay transacción común. */
  function transactOps(plan) {
    return serial(async () => {
      await ensure();
      if (dirty) {                                 // primero lo pendiente: el plan parte de lo que hay en disco
        await doFlush();
        if (dirty) throw new Error('hay cambios sin guardar: no se importó nada');
      }
      const isUnstamped = (c, id) => unstamped.has(keyOf(c, id));
      const { ops, result } = plan(clone(cache), isUnstamped);
      if (!ops.length) return result;
      const recs = ops.map(o => ({ c: o.c, rec: stamp(mapOf(o.c).get(o.rec.id), o.rec) }));
      // Escritura: si falla aquí, nada se confirmó (la transacción o el setItem no se aplicaron)
      if (mode === 'ls') {
        const next = clone(cache);
        applyRecs(next, recs);
        localStorage.setItem(KEY, JSON.stringify(next));      // si falla (cuota), nada cambió
      } else {
        await applyOps(recs.map(({ c, rec }) => ({ c, id: rec.id, rec: clone(rec) })));
      }
      // Desde aquí el cambio YA ESTÁ en el disco. Un error posterior se marca como `committed`:
      // quien llama debe distinguirlo de "no se cambió nada".
      try {
        if (mode === 'ls') applyRecs(cache, recs);            // en su lugar: las operaciones en curso ven el cambio
        else applyRecs(cache, recs, (c, id) => pending[c].has(id));   // lo tocado durante la escritura gana
        maps = {};
        announce();
      } catch (err) {
        err.committed = true; err.result = result;
        throw err;
      }
      return result;
    });
  }

  K.api = {
    /* Transacción de varios registros: ver transactOps */
    transact: plan => transactOps(plan),
    // Devuelve una copia sin tombstones: la app puede modificarla sin tocar la copia guardada
    async load() { return clone(live(await ensure())); },
    /* Reconstruye la caché desde el almacenamiento persistente.
       Conserva por id los cambios locales aún pendientes, para no pisar ediciones concurrentes. */
    async reload() {
      return serial(async () => {
        await ensure();
        // Vacía primero cualquier escritura pendiente; si falla, sus operaciones se conservan en pending.
        if (dirty) await doFlush();
        const fresh = mode === 'ls'
          ? normalizeCollections(readLs() || EMPTY())
          : normalizeCollections((await readAll()).stores);
        COLLS.forEach(c => {
          const current = new Map(cache[c].map(x => [x.id, x]));
          const byId = new Map(fresh[c].map(x => [x.id, x]));
          pending[c].forEach((_op, id) => {
            const local = current.get(id);
            if (local) byId.set(id, local);
            else byId.delete(id);
          });
          fresh[c] = [...byId.values()];
          sortLoaded(c, fresh[c]);
        });
        cache = fresh;
        maps = {};
        return clone(live(cache));
      });
    },
    async saveNote(n)      { return put('notes', n, true); },
    async deleteNote(id)   { return kill('notes', id); },
    async saveLabel(l)     { return put('labels', l, false); },
    async deleteLabel(id)  { return kill('labels', id); },
    async saveBlock(b)     { return put('blocks', b, true); },
    async deleteBlock(id)  { return kill('blocks', id); },
    async saveEvent(e)     { return put('events', e, true); },
    async deleteEvent(id)  { return kill('events', id); },
    async saveSession(s)   { return put('sessions', s, false); },
    async deleteSession(id){ return kill('sessions', id); },
    /* Pendientes: registros propios (no son líneas de las notas) */
    async saveTask(t)      { return put('tasks', { goalId: null, projectId: null, blockId: null, ...t }, false); },
    async deleteTask(id)   { return kill('tasks', id); },
    /* Objetivos: cada uno lleva sus proyectos y recursos dentro del mismo registro */
    async saveGoal(g)      { return put('goals', g, false); },
    async deleteGoal(id)   { return kill('goals', id); },
    /* Franjas horarias de un día (Hoy): registros propios */
    async saveSlot(s)      { return put('slots', s, false); },
    async deleteSlot(id)   { return kill('slots', id); },
    /* Borrar todo: cada registro queda como tombstone (así el borrado también llega a otros dispositivos) */
    async clearAll() {
      const c = await ensure();
      COLLS.forEach(k => { c[k] = c[k].map(x => ({ id: x.id, deleted: true, rev: (Number(x.rev) || 0) + 1, updatedAt: Date.now() })); });
      maps = {}; pending = newPending(); replaceAll = true; dirty = true;
      setStatus('saving');
      return flush();
    },
  };

  /* Tamaño aproximado de lo guardado (para Configuración) */
  K.storageBytes = async () => new Blob([JSON.stringify(await ensure())]).size;

  /* Reintento manual desde la interfaz */
  K.retrySave = () => { if (dirty) { setStatus('saving'); flush(); } };
  /* Escribe ya lo pendiente y devuelve cuando termina (lo usan las pruebas y la importación) */
  K.storageFlush = () => flush();
})();
