/* =========================================================
   richedit.js — núcleo del editor visual de notas.
   Un div editable con bloques (.eb): texto, subtítulo, viñeta, casilla.
   Este archivo: bloques, selección, formato, deshacer y plegado.
   Las teclas, el pegado y los clics están en richinput.js.

   K.richDoc(root, { onChange, onSelect, getCollapsed, setCollapsed }) → api
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  const TAGS = { strong: 'STRONG', em: 'EM', mark: 'MARK' };

  K.richDoc = (root, o = {}) => {
    const api = {};
    const sel = () => window.getSelection();
    const isChip = n => n.nodeType === 1 && n.getAttribute('contenteditable') === 'false';

    /* ---------- Bloques ---------- */
    const blocks = api.blocks = () => [...root.children].filter(c => c.classList && c.classList.contains('eb'));
    const blockOf = api.blockOf = node => {
      while (node && node !== root) { if (node.parentNode === root) return node.nodeType === 1 ? node : null; node = node.parentNode; }
      return null;
    };
    const emptyBlock = (k = 'p') => K.makeEb(k, false, '');
    api.emptyBlock = emptyBlock;

    /* ---------- Selección ---------- */
    const getRange = api.getRange = () => {
      const s = sel();
      if (!s || !s.rangeCount) return null;
      const r = s.getRangeAt(0);
      return root.contains(r.commonAncestorContainer) ? r : null;
    };
    api.setRange = r => { const s = sel(); s.removeAllRanges(); s.addRange(r); };

    const toPos = (node, off) => {
      let b;
      if (node === root) { const list = blocks(); b = list[Math.min(off, list.length - 1)]; off = off >= list.length ? Infinity : 0; }
      else b = blockOf(node);
      if (!b) return null;
      const i = blocks().indexOf(b);
      if (off === Infinity) return { b: i, o: b.textContent.length };
      const r = document.createRange();
      r.setStart(b, 0);
      try { r.setEnd(node, off); } catch { return { b: i, o: 0 }; }
      return { b: i, o: r.toString().length };
    };
    const toPoint = pos => {
      const list = blocks();
      const b = list[Math.max(0, Math.min(pos.b, list.length - 1))];
      let left = pos.o;
      const w = document.createTreeWalker(b, NodeFilter.SHOW_TEXT);
      let n, last = null;
      while ((n = w.nextNode())) {
        last = n;
        if (left <= n.length) {
          const chip = (() => { let p = n.parentNode; while (p && p !== b) { if (isChip(p)) return p; p = p.parentNode; } return null; })();
          if (chip) return { node: chip.parentNode, offset: [...chip.parentNode.childNodes].indexOf(chip) + (left > 0 ? 1 : 0) };
          return { node: n, offset: left };
        }
        left -= n.length;
      }
      return last ? { node: last, offset: last.length } : { node: b, offset: 0 };
    };
    const saveSel = api.saveSel = () => {
      const r = getRange();
      if (!r) return null;
      return { a: toPos(r.startContainer, r.startOffset), f: toPos(r.endContainer, r.endOffset) };
    };
    const restoreSel = api.restoreSel = s => {
      if (!s || !s.a || !s.f) return;
      const a = toPoint(s.a), f = toPoint(s.f);
      const r = document.createRange();
      r.setStart(a.node, a.offset); r.setEnd(f.node, f.offset);
      api.setRange(r);
    };
    api.caretTo = (b, atEnd) => {
      const r = document.createRange();
      r.selectNodeContents(b); r.collapse(!atEnd);
      api.setRange(r);
    };
    api.selectedBlocks = () => {
      const r = getRange();
      if (!r) return [];
      const a = blockOf(r.startContainer === root ? root.childNodes[r.startOffset] : r.startContainer);
      const f = blockOf(r.endContainer === root ? root.childNodes[Math.max(0, r.endOffset - 1)] : r.endContainer);
      const list = blocks();
      const i = list.indexOf(a), j = list.indexOf(f);
      if (i < 0 || j < 0) return a ? [a] : [];
      return list.slice(Math.min(i, j), Math.max(i, j) + 1);
    };
    api.atStart = () => {
      const r = getRange();
      if (!r || !r.collapsed) return false;
      const b = blockOf(r.startContainer);
      if (!b) return false;
      const t = document.createRange(); t.setStart(b, 0); t.setEnd(r.startContainer, r.startOffset);
      return t.toString().length === 0;
    };
    api.atEnd = () => {
      const r = getRange();
      if (!r || !r.collapsed) return false;
      const b = blockOf(r.startContainer);
      if (!b) return false;
      const t = document.createRange(); t.setStart(r.startContainer, r.startOffset); t.setEnd(b, b.childNodes.length);
      return t.toString().length === 0;
    };

    /* ---------- Contenido ---------- */
    const getBody = api.getBody = () => K.serBlocks(blocks());
    const setBody = api.setBody = body => {
      const list = K.parseBody(body).map(l => K.makeEb(l.k, l.done, l.text, l.id));
      root.replaceChildren(...(list.length ? list : [emptyBlock()]));
      applyFolds();
    };

    /* Arregla lo que el navegador deja torcido: bloques sueltos, estilos, <b>/<i>, saltos */
    api.sanitize = () => {
      let bad = false;
      const loose = [...root.childNodes].filter(c => !(c.nodeType === 1 && c.classList.contains('eb')));
      const selBefore = loose.length || root.querySelector('.eb span, .eb font, .eb div, .eb p, .eb b, .eb i, .eb u, .eb s, .eb [style]') ? saveSel() : null;
      loose.forEach(c => {
        bad = true;
        if (c.nodeType === 1 && /^(DIV|P)$/.test(c.tagName)) {
          const nb = emptyBlock(); nb.replaceChildren(...c.childNodes); c.replaceWith(nb);
        } else if (c.nodeType === 3 && !c.nodeValue.trim() && c.nextSibling) c.remove();
        else { const nb = emptyBlock(); nb.replaceChildren(); c.replaceWith(nb); nb.append(c); }
      });
      root.querySelectorAll('.eb span, .eb font, .eb div, .eb p, .eb u, .eb s').forEach(e => {
        if (e.closest('[contenteditable="false"]') && !isChip(e)) return;
        bad = true; e.replaceWith(...e.childNodes);
      });
      root.querySelectorAll('.eb b, .eb i').forEach(e => {
        bad = true;
        const n = document.createElement(e.tagName === 'B' ? 'strong' : 'em');
        n.append(...e.childNodes); e.replaceWith(n);
      });
      root.querySelectorAll('.eb [style]').forEach(e => { bad = true; e.removeAttribute('style'); });
      blocks().forEach(b => {
        const brs = [...b.querySelectorAll('br')];
        if (b.textContent.length && brs.length) { brs.forEach(x => x.remove()); bad = true; }
        if (!b.firstChild) b.append(document.createElement('br'));
      });
      if (!root.firstChild) root.append(emptyBlock());
      if (bad && selBefore) restoreSel(selBefore);
    };

    /* ---------- Subtítulos: no se pliegan ----------
       Las funciones quedan como no-op para que quien las llame siga funcionando. */
    api.foldKey = b => K.serInline(b).trim();
    const applyFolds = api.applyFolds = () => { blocks().forEach(b => b.classList.remove('folded', 'fold-hide')); };
    api.isHidden = () => false;
    api.toggleFold = () => {};
    api.unfoldFor = () => {};
    api.foldAll = () => {};
    api.hasHeadings = () => false;

    /* ---------- Deshacer / rehacer (propio: el del navegador no ve estos cambios) ---------- */
    const hist = { stack: [], i: -1, t: 0 };
    const snap = () => ({ body: getBody(), sel: saveSel() });
    const record = api.record = coalesce => {
      const s = snap();
      const top = hist.stack[hist.i];
      if (top && top.body === s.body) { top.sel = s.sel; return; }
      const now = Date.now();
      if (coalesce && hist.i > 0 && hist.i === hist.stack.length - 1 && now - hist.t < 800) hist.stack[hist.i] = s;
      else {
        hist.stack = hist.stack.slice(0, hist.i + 1); hist.stack.push(s);
        if (hist.stack.length > 200) hist.stack.shift();
        hist.i = hist.stack.length - 1;
      }
      hist.t = now;
    };
    api.resetHistory = () => { hist.stack = []; hist.i = -1; record(false); };
    const apply = s => { setBody(s.body); root.focus(); restoreSel(s.sel); o.onChange && o.onChange(true); o.onSelect && o.onSelect(); };
    api.undo = () => {
      if (hist.stack[hist.i] && hist.stack[hist.i].body !== getBody()) record(false);
      if (hist.i > 0) { hist.i--; apply(hist.stack[hist.i]); }
    };
    api.redo = () => { if (hist.i < hist.stack.length - 1) { hist.i++; apply(hist.stack[hist.i]); } };
    api.canUndo = () => hist.i > 0 || (hist.stack[0] && hist.stack[0].body !== getBody());
    api.canRedo = () => hist.i < hist.stack.length - 1;

    /* Avisa que cambió el contenido (coalesce = tecleo seguido) */
    api.commit = (coalesce, silent) => { record(!!coalesce); if (!silent && o.onChange) o.onChange(); };

    /* ---------- Formato en línea ---------- */
    const closestTag = (n, tag) => { for (let p = n.parentNode; p && p !== root; p = p.parentNode) if (p.tagName === tag) return p; return null; };

    const textNodes = range => {
      let sc = range.startContainer, so = range.startOffset, ec = range.endContainer, eo = range.endOffset;
      if (ec.nodeType === 3 && eo > 0 && eo < ec.length) ec.splitText(eo);
      if (sc.nodeType === 3 && so > 0 && so < sc.length) { const n = sc.splitText(so); if (sc === ec) { ec = n; eo = n.length; } sc = n; so = 0; }
      const r = document.createRange();
      r.setStart(sc, so); r.setEnd(ec, ec === sc && sc.nodeType === 3 && so === 0 && eo > sc.length ? sc.length : eo);
      const out = [];
      const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = w.nextNode())) {
        if (!n.nodeValue || !r.intersectsNode(n)) continue;
        if (n === ec && eo === 0) continue;
        if (n === sc && so === n.length) continue;
        let inChip = false;
        for (let p = n.parentNode; p && p !== root; p = p.parentNode) if (isChip(p)) { inChip = true; break; }
        if (!inChip) out.push(n);
      }
      return out;
    };
    const liftOut = (n, a) => {
      const after = document.createRange(); after.setStartAfter(n); after.setEnd(a, a.childNodes.length);
      const fa = after.extractContents();
      const before = document.createRange(); before.setStart(a, 0); before.setEndBefore(n);
      const fb = before.extractContents();
      if (fa.textContent) { const c = a.cloneNode(false); c.append(fa); a.after(c); }
      if (fb.textContent) { const c = a.cloneNode(false); c.append(fb); a.before(c); }
      a.replaceWith(...a.childNodes);
    };
    const mergeSame = b => {
      b.querySelectorAll('strong, em, mark').forEach(e => {
        if (!e.isConnected) return;
        while (e.nextSibling && e.nextSibling.nodeType === 1 && e.nextSibling.tagName === e.tagName) {
          const nx = e.nextSibling; e.append(...nx.childNodes); nx.remove();
        }
      });
      b.querySelectorAll('strong:empty, em:empty, mark:empty').forEach(e => e.remove());
      b.normalize();
    };

    api.tidy = mergeSame;

    /* Si no hay nada seleccionado, la palabra donde está el cursor */
    const wordAtCaret = r => {
      const n = r.startContainer;
      if (n.nodeType !== 3) return null;
      const v = n.nodeValue; let a = r.startOffset, b = a;
      while (a > 0 && /\S/.test(v[a - 1])) a--;
      while (b < v.length && /\S/.test(v[b])) b++;
      if (a === b) return null;
      const w = document.createRange(); w.setStart(n, a); w.setEnd(n, b);
      return w;
    };

    api.toggleFormat = name => {
      const tag = TAGS[name];
      let r = getRange();
      if (!r) return;
      const s0 = saveSel();
      if (r.collapsed) { r = wordAtCaret(r); if (!r) return; }
      const ns = textNodes(r);
      if (!ns.length) return;
      const touched = new Set(ns.map(n => blockOf(n)));
      const allIn = ns.every(n => closestTag(n, tag));
      if (allIn) ns.forEach(n => { const a = closestTag(n, tag); if (a) liftOut(n, a); });
      else ns.forEach(n => {
        if (closestTag(n, tag)) return;
        const w = document.createElement(name === 'mark' ? 'mark' : name);
        if (name === 'mark') w.className = 'hl';
        n.before(w); w.append(n);
      });
      touched.forEach(b => b && mergeSame(b));
      restoreSel(s0);
      api.commit(false);
      o.onSelect && o.onSelect();
    };

    /* Estado para la barra: qué formatos tiene el texto bajo el cursor */
    api.state = () => {
      const r = getRange();
      const st = { strong: false, em: false, mark: false, kind: 'p', link: null, any: !!r };
      if (!r) return st;
      let n = r.startContainer;
      if (n.nodeType === 1 && n.childNodes[r.startOffset] && !r.collapsed) n = n.childNodes[r.startOffset];
      const b = blockOf(n);
      if (b) st.kind = b.dataset.k;
      for (let p = n; p && p !== root; p = p.parentNode) {
        if (p.tagName === 'STRONG') st.strong = true;
        else if (p.tagName === 'EM') st.em = true;
        else if (p.tagName === 'MARK') st.mark = true;
        else if (p.tagName === 'A' && !st.link) st.link = p;
      }
      return st;
    };

    /* ---------- Tipo de bloque ---------- */
    api.setKind = k => {
      if (k === 't') k = 'b';                       // las casillas se crean solo en Pendientes
      const bs = api.selectedBlocks();
      if (!bs.length) return;
      const s0 = saveSel();
      const target = bs.every(b => b.dataset.k === k) ? 'p' : k;
      bs.forEach(b => {
        b.dataset.k = target;
        if (target === 't') b.dataset.done = b.dataset.done || '0'; else delete b.dataset.done;
      });
      applyFolds(); restoreSel(s0); api.commit(false); o.onSelect && o.onSelect();
    };

    /* ---------- Enlaces ---------- */
    /* Pone un enlace externo sobre `range` (o inserta la dirección si no hay texto) */
    api.applyLink = (range, url) => {
      if (!range) return;
      api.setRange(range);
      if (range.collapsed) {
        const a = K.inlineNodes(url)[0];
        range.insertNode(a);
        const r = document.createRange(); r.setStartAfter(a); r.collapse(true); api.setRange(r);
      } else {
        const ns = textNodes(range);
        const s0 = saveSel();
        ns.forEach(n => {
          const old = closestTag(n, 'A');
          if (old) { liftOut(n, old); }
        });
        const first = textNodes(getRange() || range);
        first.forEach(n => {
          const a = document.createElement('a');
          a.className = 'ln ext'; a.href = url; a.dataset.url = url;
          n.before(a); a.append(n);
        });
        blocks().forEach(b => b.normalize());
        restoreSel(s0);
      }
      api.commit(false);
    };
    api.removeLink = a => {
      const s0 = saveSel();
      if (a.dataset.ref != null) a.replaceWith(document.createTextNode(a.dataset.ref));
      else a.replaceWith(...a.childNodes);
      blocks().forEach(b => b.normalize());
      restoreSel(s0); api.commit(false);
    };
    /* Reemplaza `range` por una referencia a una nota o etiqueta */
    api.insertRef = (range, name) => {
      if (!range) return;
      api.setRange(range);
      range.deleteContents();
      const chip = K.inlineNodes(`[[${name}]]`)[0];
      range.insertNode(chip);
      const sp = document.createTextNode(' ');
      chip.after(sp);
      const r = document.createRange(); r.setStart(sp, 1); r.collapse(true); api.setRange(r);
      api.sanitize();
      api.commit(false);
    };

    api.root = root;
    api.focusEnd = () => { root.focus(); const l = blocks(); api.caretTo(l[l.length - 1], true); };
    return api;
  };
})();
