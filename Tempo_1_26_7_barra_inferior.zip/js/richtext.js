/* =========================================================
   richtext.js — convierte entre el texto guardado de la nota (body)
   y los bloques que se editan en pantalla. Sin esto el editor no sabe
   leer ni escribir el formato.

   Línea de bloque:   ## Subtítulo   - [ ] casilla   - viñeta   texto
   Dentro del texto:  **negrita**  *cursiva*  ==resaltado==
                      [texto](https://…)  [[Nota o etiqueta]]  https://…
   Escapes:           \* \[ \] \= \\  (para escribir esos signos tal cual)
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h } = K;

  const INLINE_RE = new RegExp([
    '\\\\([\\\\*\\[\\]=#-])',                                   // 1 escape
    '\\[\\[([^\\[\\]\\n]+)\\]\\]',                           // 2 [[ref]]
    '\\[([^\\]\\n]+)\\]\\((https?:\\/\\/[^\\s)]+)\\)',       // 3,4 [texto](url)
    '\\*\\*\\*(?=\\S)([\\s\\S]*?\\S)\\*\\*\\*',               // 5 negrita+cursiva
    '\\*\\*(?=\\S)([\\s\\S]*?\\S)\\*\\*',                     // 6 negrita
    '==(?=\\S)([\\s\\S]*?\\S)==',                              // 7 resaltado
    '(?<![\\w*])\\*(?=[^\\s*])([^*\\n]*?[^\\s*])\\*(?![\\w*])', // 8 cursiva
    '(https?:\\/\\/[^\\s<>()\\[\\]]*[^\\s<>()\\[\\].,;:!?])', // 9 URL suelta
  ].join('|'), 'g');

  K.domainOf = url => { try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return url; } };

  /* Texto visible → texto con escapes */
  K.esc = s => s.replace(/[\\*[\]]/g, '\\$&').replace(/={2,}/g, m => '\\='.repeat(m.length));

  /* ---------- Marcas → nodos ---------- */
  function mkLink(url, label, bare) {
    return h('a', { class: 'ln ext', href: url, 'data-url': url, 'data-bare': bare ? '1' : null }, label);
  }
  function mkRef(name) {
    const ref = K.resolveRef ? K.resolveRef(name) : null;
    return h('a', {
      class: 'ln int' + (ref ? '' : ' missing'), contenteditable: 'false', 'data-ref': name,
      title: ref ? '' : 'No hay ninguna nota ni etiqueta con ese nombre',
    }, name);
  }
  /* Convierte una cadena con marcas en una lista de nodos (recursivo) */
  K.inlineNodes = function inlineNodes(text) {
    const out = [];
    const re = new RegExp(INLINE_RE.source, 'g');
    let pos = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > pos) out.push(text.slice(pos, m.index));
      if (m[1] != null) out.push(m[1]);
      else if (m[2] != null) out.push(mkRef(m[2]));
      else if (m[3] != null) { const a = mkLink(m[4], '', false); a.append(...inlineNodes(m[3])); out.push(a); }
      else if (m[5] != null) out.push(h('strong', {}, h('em', {}, ...inlineNodes(m[5]))));
      else if (m[6] != null) out.push(h('strong', {}, ...inlineNodes(m[6])));
      else if (m[7] != null) out.push(h('mark', { class: 'hl' }, ...inlineNodes(m[7])));
      else if (m[8] != null) out.push(h('em', {}, ...inlineNodes(m[8])));
      else out.push(mkLink(m[9], m[9], true));
      pos = re.lastIndex;
    }
    if (pos < text.length) out.push(text.slice(pos));
    return out;
  };

  /* ---------- Nodos → marcas ---------- */
  const wrapMark = (mark, s) => {
    const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(s);
    return m[2] ? m[1] + mark + m[2] + mark + m[3] : s;
  };
  K.serInline = function serInline(node) {
    let out = '';
    node.childNodes.forEach(c => {
      if (c.nodeType === 3) { out += K.esc(c.nodeValue.replace(/\u200b/g, '').replace(/\u00a0/g, ' ')); return; }
      if (c.nodeType !== 1) return;
      const tag = c.tagName;
      if (tag === 'BR') return;
      if (tag === 'A') {
        if (c.dataset.ref != null) { out += `[[${c.dataset.ref}]]`; return; }
        const url = c.dataset.url || c.getAttribute('href') || '';
        const label = serInline(c);
        const plain = c.textContent;
        out += (c.dataset.bare === '1' && plain === url) ? url : (label ? `[${label}](${url})` : '');
        return;
      }
      const inner = serInline(c);
      if (tag === 'STRONG' || tag === 'B') out += wrapMark('**', inner);
      else if (tag === 'EM' || tag === 'I') out += wrapMark('*', inner);
      else if (tag === 'MARK') out += wrapMark('==', inner);
      else out += inner;
    });
    return out;
  };

  /* ---------- Bloques ---------- */
  /* Una línea del texto guardado → { k: p|h|t|b, done, text } */
  K.parseLine = line => {
    let m = /^##\s+(.*)$/.exec(line);
    if (m) return { k: 'h', done: false, text: m[1] };
    m = /^-\s\[( |x|X)\]\s?(.*)$/.exec(line);
    if (m) return { k: 't', done: m[1] !== ' ', text: K.stripTaskId(m[2]), id: K.taskIdOf(m[2]) };
    m = /^-\s+(.*)$/.exec(line);
    if (m) return { k: 'b', done: false, text: m[1] };
    return { k: 'p', done: false, text: line };
  };
  K.parseBody = body => String(body || '').replace(/\r\n?/g, '\n').split('\n').map(K.parseLine);

  K.makeEb = (k, done, text, id) => {
    const b = h('div', { class: 'eb', 'data-k': k });
    if (k === 't') b.dataset.done = done ? '1' : '0';
    if (k === 't' && id) b.dataset.id = id;
    b.append(...K.inlineNodes(text || ''));
    if (!b.firstChild) b.append(document.createElement('br'));
    return b;
  };

  K.serBlock = b => {
    const t = K.serInline(b);
    const k = b.dataset.k;
    if (k === 'h') return '## ' + t;
    if (k === 't') return `- [${b.dataset.done === '1' ? 'x' : ' '}] ` + t + (b.dataset.id ? ' ^' + b.dataset.id : '');
    if (k === 'b') return '- ' + t;
    /* Párrafo que empieza como encabezado o viñeta ("- x", "## x"): se escapa para no reinterpretarlo al reabrir */
    return /^(##|-)(\s|$)/.test(t) ? t.replace(/^[#-]/, '\\$&') : t;
  };
  K.serBlocks = blocks => [...blocks].map(K.serBlock).join('\n');
})();
