/* =========================================================
   app.js — arranque, atajos de teclado y eventos globales.
   Atajos (fuera de campos de texto):
     K  buscar notas, etiquetas y acciones     /  buscar en la vista actual
     N  nota nueva (en Hoy: escribir un pendiente)   Esc  cierra lo que esté abierto
     P  ir a Hoy                               F  ir a Foco
     Ctrl+\  muestra u oculta la barra lateral
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  /* Indicador del guardado: aparece mientras se guarda y, si falla, queda visible con reintentar/exportar */
  K.initSaveStatus = () => {
    const el = K.h('div', { class: 'save-status', role: 'status', hidden: true });
    document.body.append(el);
    let showT = 0, hideT = 0, hadError = false;
    const show = (cls, nodes) => { el.className = 'save-status ' + cls; el.replaceChildren(...nodes); el.hidden = false; };
    window.addEventListener('mikeep:save', e => {
      const s = e.detail;
      clearTimeout(showT); clearTimeout(hideT);
      if (s === 'saving') {
        showT = setTimeout(() => show('', [K.h('span', {}, 'Guardando…')]), 700);
      } else if (s === 'saved') {
        if (hadError) { hadError = false; show('', [K.h('span', {}, 'Guardado')]); hideT = setTimeout(() => { el.hidden = true; }, 1500); }
        else el.hidden = true;
      } else if (s === 'error') {
        hadError = true;
        show('error', [
          K.h('span', {}, 'No se pudo guardar. Tus cambios siguen en pantalla.'),
          K.h('button', { type: 'button', onclick: () => K.retrySave() }, 'Reintentar'),
          K.h('button', { type: 'button', onclick: () => K.exportData() }, 'Exportar copia')]);
      }
    });
  };

  K.syncFromStorage = async () => {
    try {
      K.applyData(await K.api.load());
      if (K.state.route.name === 'label' && !K.labelById(K.state.route.id)) { K.go({ name: 'all' }); return; }
      K.refreshAll();
    } catch (err) { console.error(err); }
  };

  K.boot = async () => {
    const st = K.state;
    try { if (localStorage.getItem(K.PREF.side) === 'closed') document.body.classList.add('side-closed'); } catch { /* sin storage */ }

    try { K.applyData(await K.api.load()); }
    catch (err) {
      /* No se siembran ejemplos ni se escribe nada: podría tapar datos que sí existen */
      console.error(err); K.storageFailed = true;
      K.toast('No se pudieron leer tus datos guardados. No se cambió nada: recargá la página para reintentar.');
    }
    /* Pide que el navegador no borre estos datos por falta de espacio (sin diálogo en la mayoría de los casos) */
    try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {}); } catch { /* sin soporte */ }
    if (!K.storageFailed) await K.firstRun();
    if (!K.storageFailed) K.purgeTrash();                     // papelera: vence a los 7 días
    K.linkLegacyHalves();                                    // bloques partidos de versiones viejas → groupId común
    K.normalizeOrder();
    K.pomoResume();
    K.usageBump('opens');
    K.initEdgeSwipe();                                       // celular: borde izquierdo abre la barra lateral
    K.initSaveStatus();
    if (K.storageRescued) K.toast('No pude leer tus datos guardados. Dejé una copia aparte: Configuración → Datos.');

    /* Otra pestaña o ventana guardó cambios */
    window.addEventListener('mikeep:external', () => {
      if (st.editor) { K.externalStale = true; return; }       // no tocar lo que se está escribiendo
      K.syncFromStorage();
    });

    /* Botón flotante (celular): nota nueva en la card */
    const fab = K.$('#fab');
    fab.innerHTML = K.icon('plus', 24);
    /* En Hoy, el (+) lleva el cursor al campo de captura (no abre otra ventana) */
    fab.addEventListener('click', () => (st.route.name === 'today' ? K.focusCapture() : K.quickAdd()));

    K.$('#scrim').addEventListener('click', () => document.body.classList.remove('nav-open'));
    K.$('#importMd').addEventListener('change', e => {
      const fs = [...e.target.files];
      if (fs.length) K.importMarkdown(fs);
      e.target.value = '';
    });
    K.$('#importFile').addEventListener('change', e => {
      const f = e.target.files[0];
      if (f) K.importData(f);
      e.target.value = '';
    });

    document.addEventListener('keydown', e => {
      const el = document.activeElement;
      const typing = el && (/INPUT|TEXTAREA|SELECT/.test(el.tagName) || el.isContentEditable);
      const mod = e.ctrlKey || e.metaKey;

      if (mod && e.key === '\\') { e.preventDefault(); K.toggleSidebar(); return; }
      if (e.key === 'Escape') {
        if (K.hasPop()) { K.closePop(); return; }
        if (st.editor) { st.editor.close(); return; }
        return;
      }
      if (typing || mod || e.altKey || st.editor || K.$('.palette') || K.$('[aria-modal="true"]')) return;

      const key = e.key.toLowerCase();
      if (key === 'k') { e.preventDefault(); K.openPalette(); }
      else if (key === 'n' && st.route.name === 'today') { e.preventDefault(); K.focusCapture(); }
      else if (key === 'n' && K.canCreate(st.route)) { e.preventDefault(); K.newNote(); }
      else if (key === 'p') { e.preventDefault(); K.go({ name: 'today' }); }
      else if (key === 'f') { e.preventDefault(); K.go({ name: 'focus' }); }
      else if (e.key === '/') { const s = K.$('#searchInput'); if (s) { e.preventDefault(); s.focus(); } }
    });

    /* Reacomoda las tarjetas al cambiar el tamaño o al cargar las fuentes */
    let raf = 0;
    window.addEventListener('resize', () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(K.relayoutAll); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(K.relayoutAll);

    window.addEventListener('hashchange', K.onRoute);
    K.onRoute();
  };

  /* Modo sin conexión: solo con http(s); en file:// el navegador no admite service workers y la app sigue igual */
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(err => console.warn('Sin modo offline:', err)));
  }

  K.boot();
})();
