/* =========================================================
   settings.js — Configuración, en cuatro grupos:
   · Preferencias: tema automático, claro u oscuro (se recuerda en este navegador).
   · Foco: duración de las etapas, avisos al terminar y pantalla encendida.
   · Datos: copia de seguridad (exportar e importar), lo guardado, papelera y borrados.
   · Acerca de: versión, uso en este dispositivo y privacidad.
   El tema inicial lo aplica un script chico en index.html para evitar un parpadeo.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;
  const st = K.state;

  /* ---------- Tema ---------- */
  const META = { dark: '#0f0f0f', light: '#f6f6f4' };
  const lightSystem = () => !!(window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches);

  K.getTheme = () => {
    try { const v = localStorage.getItem(K.PREF.theme); return v === 'light' || v === 'dark' ? v : 'auto'; }
    catch { return 'auto'; }
  };
  K.applyTheme = () => {
    const t = K.getTheme(), root = document.documentElement;
    if (t === 'auto') delete root.dataset.theme; else root.dataset.theme = t;
    const light = t === 'light' || (t === 'auto' && lightSystem());
    const m = document.querySelector('meta[name="theme-color"]');
    if (m) m.content = light ? META.light : META.dark;
  };
  K.setTheme = v => {
    try { if (v === 'auto') localStorage.removeItem(K.PREF.theme); else localStorage.setItem(K.PREF.theme, v); }
    catch { /* sin storage: el tema dura lo que la pestaña */ }
    K.applyTheme();
    if (st.route.name === 'settings') K.refreshAll();
  };
  K.applyTheme();
  /* Si el tema es automático, sigue al sistema cuando cambia */
  if (window.matchMedia) {
    const mq = matchMedia('(prefers-color-scheme: light)');
    const again = () => { if (K.getTheme() === 'auto') K.applyTheme(); };
    mq.addEventListener ? mq.addEventListener('change', again) : mq.addListener(again);
  }

  /* ---------- Helpers de la pantalla ---------- */
  const bytes = n => n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1).replace('.', ',')} KB` : `${(n / 1048576).toFixed(1).replace('.', ',')} MB`;
  const dateText = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleDateString('es', { day: 'numeric', month: 'long', year: 'numeric' }); };
  const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

  /* Grupo de primer nivel: título, texto y una o más tarjetas (subsec) */
  function group(title, sub, ...kids) {
    return h('section', { class: 'set-sec' },
      h('h2', { class: 'set-h' }, title),
      sub ? h('p', { class: 'set-sub' }, sub) : null,
      ...kids);
  }
  /* Tarjeta de un grupo, con un título chico opcional por encima */
  function subsec(title, ...kids) {
    return h('div', { class: 'set-subsec' },
      title ? h('h3', { class: 'set-h3' }, title) : null,
      h('div', { class: 'set-card' }, ...kids));
  }
  /* Grupo de una sola tarjeta */
  function section(title, sub, ...kids) {
    return group(title, sub, subsec(null, ...kids));
  }
  function line(title, desc, control, extra) {
    return h('div', { class: 'set-row' + (extra ? ' ' + extra : '') },
      h('div', { class: 'set-txt' },
        h('span', { class: 'set-t' }, title),
        desc ? h('span', { class: 'set-d' }, desc) : null),
      control ? h('div', { class: 'set-ctl' }, control) : null);
  }

  /* Miniatura de un tema: colores fijos, no dependen del tema actual */
  const PAL = {
    light: { bg: '#f6f6f4', panel: '#ffffff', ink: '#171717', mute: '#a1a1a1' },
    dark: { bg: '#0f0f0f', panel: '#202020', ink: '#ededed', mute: '#6b6b6b' },
  };
  const face = (p, cls) => h('span', { class: 'tp-face ' + cls, style: `--tp-bg:${p.bg};--tp-panel:${p.panel};--tp-ink:${p.ink};--tp-mute:${p.mute}` },
    h('span', { class: 'tp-in' }, h('i', {}), h('i', {}), h('i', {})));
  const THEMES = [
    { k: 'auto', label: 'Automático', faces: [face(PAL.light, 'l'), face(PAL.dark, 'r')] },
    { k: 'light', label: 'Claro', faces: [face(PAL.light, 'full')] },
    { k: 'dark', label: 'Oscuro', faces: [face(PAL.dark, 'full')] },
  ];
  const themeCard = t => h('button', {
    type: 'button', class: 'theme-card', 'aria-pressed': String(K.getTheme() === t.k),
    onclick: () => K.setTheme(t.k),
  }, h('span', { class: 'tp' }, ...t.faces), h('span', { class: 'theme-name' }, t.label));

  /* Confirmación en una hoja (reemplaza a confirm()). Resuelve true si se confirma; false si se cancela o se cierra.
     typed: el texto que hay que escribir para habilitar el botón. */
  K.ask = ({ title, text, ok, typed, danger }) => new Promise(resolve => {
    let answered = false;
    const answer = v => { if (!answered) { answered = true; resolve(v); } };
    const made = K.modal(close => {
      const input = typed ? h('input', { class: 'fld-in', placeholder: typed, 'aria-label': 'Escribí ' + typed, autocomplete: 'off', spellcheck: 'false' }) : null;
      const go = h('button', { type: 'button', class: 'btn' + (danger ? ' danger' : ''), disabled: typed ? '' : null,
        onclick: () => { answer(true); close(); } }, ok);
      if (input) input.addEventListener('input', () => { go.disabled = input.value.trim() !== typed; });
      return h('div', { class: 'ask' },
        h('div', { class: 'sheet-head' }, h('h2', {}, title)),
        h('div', { class: 'ask-body' }, h('p', { class: 'ask-text' }, text), input),
        h('div', { class: 'sheet-foot' },
          h('button', { type: 'button', class: 'btn quiet', onclick: () => { answer(false); close(); } }, 'Cancelar'),
          go));
    }, () => answer(false));
    if (!made) answer(false);          // ya había otra hoja o nota abierta: no se pregunta
  });
  /* Atajo para los botones de Configuración: ejecuta onOk solo si se confirma */
  function ask({ onOk, ...opts }) { K.ask(opts).then(ok => { if (ok) onOk(); }); }

  /* Borra notas, etiquetas, eventos, bloques, sesiones e historial. Las preferencias (tema, barra lateral) se mantienen. */
  K.wipeAll = () => {
    st.notes = []; st.labels = []; st.blocks = []; st.events = []; st.sessions = []; st.versions = []; st.tasks = []; st.goals = []; st.slots = [];
    try { localStorage.removeItem(K.PREF.pomo); } catch { /* sin storage */ }
    K.pomoReset(true);
    K.run(K.api.clearAll());
    history.replaceState(null, '', '#/');
    K.onRoute();
    K.toast('Se borraron todos los datos de este navegador');
  };
  const wipeSessions = () => {
    const old = st.sessions;
    st.sessions = [];
    old.forEach(s => K.run(K.api.deleteSession(s.id)));
    K.refreshAll();
    K.toast('Se borraron las sesiones de foco');
  };

  /* ---------- Foco ---------- */
  /* Mismas combinaciones que la pantalla de Foco; cambiarlas en cualquiera de las dos da lo mismo */
  const PRESETS = [[25, 5, 15], [50, 10, 20], [15, 3, 10]];
  function presetLine() {
    const cur = [K.POMO.focus, K.POMO.short, K.POMO.long].map(x => Math.round(x / 60000));
    const running = K.pomoIsRunning();
    return line('Duración de las etapas', running ? 'Pausá el temporizador para cambiarla.' : 'Enfoque · pausa corta · pausa larga, en minutos.',
      h('span', { class: 'set-pair', role: 'group', 'aria-label': 'Combinaciones de duración' }, PRESETS.map(p => h('button', {
        type: 'button', class: 'btn', disabled: running ? '' : null,
        'aria-pressed': String(p.every((v, i) => v === cur[i])),
        onclick: () => { K.setPreset(...p); K.refreshAll(); },
      }, `${p[0]} · ${p[1]} · ${p[2]}`))));
  }
  /* Avisos al terminar: el navegador pide permiso solo cuando la persona toca el botón */
  function notifLine() {
    if (!('Notification' in window)) return null;
    const p = Notification.permission;
    const text = p === 'granted'
      ? 'Activados: te avisamos cuando termina un enfoque o una pausa, aunque estés en otra pantalla.'
      : p === 'denied'
        ? 'Bloqueados en el navegador. Podés permitirlos desde el ícono de candado de la barra de direcciones.'
        : 'Te avisamos cuando termina un enfoque o una pausa, aunque estés en otra pantalla. El navegador pide permiso al tocar el botón.';
    return line('Avisos al terminar', text, p === 'default'
      ? h('button', { class: 'btn', type: 'button', onclick: async () => {
        try { await Notification.requestPermission(); } catch { /* sin soporte */ }
        K.refreshAll();
      } }, 'Permitir avisos')
      : null);
  }
  function capLine() {
    return line('Captura de notas', 'Por defecto, una nota nueva hereda la etiqueta de la vista donde la creás. Activado, se crea sin etiqueta.',
      h('label', { class: 'set-check' },
        h('input', { type: 'checkbox', checked: K.capNoLabel(), onchange: e => { K.setCapNoLabel(e.target.checked); K.refreshAll(); } }),
        h('span', {}, 'Sin la etiqueta de la vista')));
  }
  function wakeLine() {
    if (!K.wakeSupported()) return null;
    return line('Pantalla encendida', 'Mientras corre un enfoque, la pantalla no se apaga. En el celular, si igual se apaga, el temporizador puede frenarse.',
      h('label', { class: 'set-check' },
        h('input', { type: 'checkbox', checked: K.wakeOn(), onchange: e => { K.setWake(e.target.checked); K.refreshAll(); } }),
        h('span', {}, 'Mantener encendida')));
  }

  /* ---------- Página ---------- */
  K.renderSettings = root => {
    const exported = (() => { try { return localStorage.getItem(K.PREF.exported) || ''; } catch { return ''; } })();
    const count = {
      notes: st.notes.length, labels: st.labels.length, events: st.events.length,
      blocks: st.blocks.length, sessions: st.sessions.length, goals: st.goals.length, trash: st.notes.filter(n => n.trashed).length,
    };
    const sizeText = h('span', {}, 'Calculando…');
    K.storageBytes().then(n => { sizeText.textContent = `Aproximadamente ${bytes(n)} en este navegador.`; })
      .catch(() => { sizeText.textContent = 'No se pudo calcular.'; });

    /* 1. Preferencias */
    const prefs = section('Preferencias', 'Automático sigue el modo claro u oscuro de tu sistema.',
      h('div', {}, h('div', { class: 'theme-grid', role: 'group', 'aria-label': 'Tema' }, THEMES.map(themeCard)), capLine()));

    /* 2. Foco */
    const focus = section('Foco', 'Cómo funciona el temporizador. La pantalla de Foco usa lo mismo.',
      presetLine(), notifLine(), wakeLine());

    /* 3. Datos: copia de seguridad (exportar e importar), lo guardado y lo que borra */
    let rescued = null;
    try { rescued = localStorage.getItem(K.CORRUPT_KEY); } catch { /* sin storage */ }

    const data = group('Datos', 'Tus datos viven solo en este navegador. Una copia sirve para llevarlos a otro dispositivo o para no perderlos.',
      subsec('Copia de seguridad',
        line('Exportar copia', exported ? `Última copia: ${dateText(exported)}.` : 'Guarda tus datos principales en un archivo .json.',
          h('button', { class: 'btn', type: 'button', onclick: () => { K.exportData(); K.refreshAll(); } },
            h('span', { svg: icon('download', 16) }), 'Exportar')),
        line('Importar copia', 'Suma lo que tenga el archivo .json. No borra lo que ya tenés; si una nota está en las dos partes, queda la más reciente.',
          h('button', { class: 'btn', type: 'button', onclick: () => K.$('#importFile').click() },
            h('span', { svg: icon('upload', 16) }), 'Importar')),
        line('Importar Markdown', 'Crea una nota por cada archivo .md o .txt. Un # al inicio pasa a ser el título.',
          h('button', { class: 'btn', type: 'button', onclick: () => K.$('#importMd').click() },
            h('span', { svg: icon('upload', 16) }), 'Importar .md'))),

      subsec('Lo guardado',
        rescued ? line('Datos que no se pudieron leer', `Se guardó aparte una copia de ${bytes(rescued.length)} que estaba dañada. Descargala por si hay algo para rescatar.`,
          h('span', { class: 'set-pair' },
            h('button', { class: 'btn', type: 'button', onclick: () => K.downloadText('tempo-datos-danados.txt', rescued, 'text/plain;charset=utf-8') },
              h('span', { svg: icon('download', 16) }), 'Descargar'),
            h('button', { class: 'btn quiet', type: 'button', onclick: () => ask({ title: '¿Borrar la copia dañada?', text: 'Si no la descargaste, se pierde para siempre.', ok: 'Borrar copia', danger: true,
              onOk: () => { try { localStorage.removeItem(K.CORRUPT_KEY); } catch { /* sin storage */ } K.refreshAll(); } }) }, 'Borrar')), 'set-row-danger') : null,
        line('Qué guardás aquí', `${plural(count.notes, 'nota', 'notas')} · ${plural(count.labels, 'etiqueta', 'etiquetas')} · ${plural(count.events, 'evento', 'eventos')} · ${plural(count.blocks, 'bloque', 'bloques')} · ${plural(count.sessions, 'sesión de foco', 'sesiones de foco')} · ${plural(count.goals, 'objetivo', 'objetivos')}`,
          null),
        line('Espacio usado', sizeText, null),
        line('Papelera', count.trash ? `${plural(count.trash, 'nota', 'notas')} esperan para eliminarse.` : 'La papelera está vacía.',
          h('button', { class: 'btn', type: 'button', disabled: count.trash ? null : '', onclick: K.emptyTrash }, 'Vaciar papelera'))),

      subsec('Borrar',
        line('Sesiones de foco', 'Quita el registro de tiempo de Foco. Tus notas no cambian.',
          h('button', { class: 'btn', type: 'button', disabled: count.sessions ? null : '',
            onclick: () => ask({ title: '¿Borrar las sesiones de foco?', text: 'Se pierde el registro de tiempo de Foco. No se puede deshacer.', ok: 'Borrar sesiones', danger: true, onOk: wipeSessions }) },
            'Borrar sesiones')),
        line('Borrar todo', 'Borra notas, etiquetas, eventos, bloques, pendientes, objetivos y sesiones de este navegador. Antes, exportá una copia.',
          h('button', { class: 'btn danger', type: 'button', onclick: () => ask({
            title: '¿Borrar todo?', typed: 'BORRAR', ok: 'Borrar todo', danger: true,
            text: 'Esto no se puede deshacer. Si querés conservar tus datos, exportá una copia primero. Para confirmar, escribí BORRAR.',
            onOk: K.wipeAll }) }, 'Borrar todo'), 'set-row-danger')));

    /* 4. Acerca de */
    const usage = (() => {
      const u = K.usageStats(), days = (u.days || []).length;
      return `${days} ${days === 1 ? 'día' : 'días'} con Tempo abierto · ${u.opens || 0} aperturas · ${u.focus || 0} enfoques · ${u.tasks || 0} pendientes creados. Solo se guarda en este navegador.`;
    })();
    const about = section('Acerca de', null,
      line('Versión', `Tempo ${K.VERSION}`, null),
      line('Uso en este dispositivo', usage, null),
      line('Privacidad', 'Tus datos se guardan solo en este navegador. Tempo no envía nada a ningún servidor.', null));

    root.append(h('div', { class: 'set-wrap' }, prefs, focus, data, about));
  };
})();
