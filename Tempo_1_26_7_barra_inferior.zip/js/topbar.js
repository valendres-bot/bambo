/* =========================================================
   topbar.js — barra superior: menú, título, "Crear una nota…",
   filtro de la vista actual (resalta coincidencias), orden
   (recientes o nombre) y "Nueva etiqueta". La búsqueda global es la paleta (K).
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon, iconBtn } = K;

  K.renderTopbar = () => {
    const st = K.state, r = st.route;
    const bar = K.$('#topbar');
    bar.replaceChildren();

    const info = K.routeInfo(r);
    /* En celular la navegación está abajo ("Más" abre la barra lateral): este botón solo queda en escritorio */
    const sideBtn = iconBtn('sidebar', 'Mostrar u ocultar la barra lateral', K.toggleSidebar);
    sideBtn.classList.add('only-desktop');
    const crumbs = h('div', { class: 'crumbs' },
      sideBtn,
      h('span', { class: 'crumb-current' }, h('span', { class: 'crumb-ico', svg: icon(info.icon, 17) }), info.title));
    bar.append(crumbs);

    if (!K.isNotesRoute(r)) return;   // módulos: sin buscador ni acciones de notas

    /* "Crear una nota…" (como Keep). Abre la misma card que el botón +. */
    const composer = K.canCreate(r) ? h('div', { class: 'composer-pill only-desktop' },
      h('button', { class: 'composer-ph', type: 'button', onclick: () => K.newNote() },
        h('span', { svg: icon('plus', 16) }), 'Crear una nota…')) : null;

    /* Buscador de la vista actual */
    const search = h('input', { id: 'searchInput', type: 'search', placeholder: 'Filtrar esta vista', 'aria-label': 'Filtrar esta vista', autocomplete: 'off' });
    search.value = st.query;
    /* Filtra con una pausa de 120 ms: cada tecla no vuelve a dibujar toda la lista */
    let timer = 0;
    search.addEventListener('input', () => { st.query = search.value; clearTimeout(timer); timer = setTimeout(K.renderList, 120); });
    search.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); clearTimeout(timer); search.value = ''; st.query = ''; K.renderList(); search.blur(); } });

    const sortBtn = iconBtn('sort', 'Ordenar', () => K.togglePop(sortBtn, () => K.menu([
      { label: 'Recientes', icon: 'sort', checked: st.sort === 'updated', run: () => K.setSort('updated') },
      { label: 'Nombre (A–Z)', icon: 'sort', checked: st.sort === 'name', run: () => K.setSort('name') },
    ])));
    sortBtn.classList.add('only-desktop');

    const newLabel = h('button', { class: 'btn only-desktop', type: 'button', onclick: () => K.startNewLabel() },
      h('span', { svg: icon('tag', 16) }), 'Nueva etiqueta');

    const cards = K.noteView() === 'cards';
    const viewBtn = iconBtn(cards ? 'rows' : 'grid', cards ? 'Ver como renglones' : 'Ver como cuadros', () => K.setNoteView(cards ? 'rows' : 'cards'));

    bar.append(
      ...[composer].filter(Boolean),
      h('div', { class: 'bar-actions' },
        h('label', { class: 'searchbox' }, h('span', { svg: icon('search', 15) }), search),
        viewBtn, sortBtn, newLabel));
  };
})();
