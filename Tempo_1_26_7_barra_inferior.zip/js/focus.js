/* =========================================================
   focus.js — Foco: temporizador Pomodoro y registro de sesiones.
   · El temporizador sigue corriendo al cambiar de pantalla y se
     retoma al recargar. Si terminó con la app cerrada, la sesión
     se acredita igual.
   · Cada enfoque completo se guarda como sesión: { id, start, end,
     ms, target } (target = en qué trabajabas). Es la base de Métricas.
   · "Terminar y guardar" registra lo trabajado si cortás un enfoque antes de
     tiempo (desde K.POMO_MIN_SAVE). Saltar un enfoque con ese avance también lo guarda.
   · Varias pestañas: solo una es la "dueña" del reloj (Web Locks, nombre
     'tempo-focus-owner'). Las demás muestran el estado que escribe la dueña (evento
     'storage'), así no se duplican sesiones ni se pisa el temporizador.
   · Aviso al terminar: sonido, vibración y notificación (por el service worker, que es
     lo que admiten los celulares). Mientras corre, la pantalla puede quedar encendida
     (Wake Lock) para que el celular no congele el temporizador.
   La pantalla está en focusui.js.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const st = K.state;

  const MIN = 60 * 1000;
  K.POMO = { focus: 25 * MIN, short: 5 * MIN, long: 15 * MIN, every: 4 };
  K.POMO_LABEL = { focus: 'Enfoque', short: 'Pausa corta', long: 'Pausa larga' };
  K.POMO_MIN_SAVE = 5 * MIN;     // avance mínimo para guardar un enfoque cortado
  const LABEL = K.POMO_LABEL;

  /* Estado del temporizador (vive fuera de la pantalla, así no se reinicia al navegar) */
  const P = (K.pomo = {
    mode: 'focus', left: K.POMO.focus, endAt: 0, running: false,
    cycle: 0,                 // enfoques completos desde la última pausa larga
    target: null,             // en qué se trabaja: { kind: note|label|event|block|text|task|goal|project, id?, text?, name }
  });
  let tick = 0;
  let owner = false;        // esta pestaña es la dueña del reloj (ver "Varias pestañas")

  /* ---------- Sonido ---------- */
  let actx = null;
  const audio = () => {
    try {
      if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === 'suspended') actx.resume();
      return actx;
    } catch { return null; }
  };
  K.beep = () => {
    const c = audio();
    if (!c) return;
    [0, 0.4, 0.8].forEach(t => {
      const o = c.createOscillator(), g = c.createGain();
      o.type = 'sine'; o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, c.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.3, c.currentTime + t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + t + 0.3);
      o.connect(g).connect(c.destination);
      o.start(c.currentTime + t); o.stop(c.currentTime + t + 0.32);
    });
  };

  /* ---------- Aviso al terminar ---------- */
  /* En el celular `new Notification()` no existe: hay que pedirle la notificación al service worker */
  const notify = msg => {
    try { if (navigator.vibrate) navigator.vibrate([200, 100, 200]); } catch { /* sin vibración */ }
    try {
      if (!('Notification' in window) || Notification.permission !== 'granted') return;
      const opts = { body: msg, tag: 'tempo-foco', icon: 'icon.svg', badge: 'icon.svg' };
      const plain = () => { try { new Notification('Tempo', opts); } catch { /* sin notificaciones */ } };
      if (navigator.serviceWorker && navigator.serviceWorker.getRegistration) {
        navigator.serviceWorker.getRegistration()
          .then(r => (r && r.showNotification ? r.showNotification('Tempo', opts) : plain()))
          .catch(plain);
      } else plain();
    } catch { /* sin notificaciones */ }
  };

  /* ---------- Pantalla encendida mientras corre ---------- */
  let wake = null, wakeBusy = false;
  K.wakeOn = () => { try { return localStorage.getItem(K.PREF.wake) !== '0'; } catch { return true; } };
  K.wakeSupported = () => 'wakeLock' in navigator;
  K.setWake = on => { try { localStorage.setItem(K.PREF.wake, on ? '1' : '0'); } catch { /* sin storage */ } wakeSync(); };
  async function wakeSync() {
    if (wakeBusy || !K.wakeSupported()) return;
    wakeBusy = true;
    try {
      const want = owner && P.running && K.wakeOn() && document.visibilityState === 'visible';
      if (want && !wake) {
        wake = await navigator.wakeLock.request('screen');
        wake.addEventListener('release', () => { wake = null; });
      } else if (!want && wake) {
        const w = wake; wake = null; await w.release();
      }
    } catch { wake = null; /* sin permiso o sin batería: el temporizador sigue igual */ }
    wakeBusy = false;
  }

  const persist = () => {
    try {
      localStorage.setItem(K.PREF.pomo, JSON.stringify({
        mode: P.mode, left: P.left, endAt: P.endAt, running: P.running, cycle: P.cycle, target: P.target,
        dur: { focus: K.POMO.focus, short: K.POMO.short, long: K.POMO.long },
      }));
    } catch { /* sin storage: el temporizador igual funciona en esta pestaña */ }
  };

  const remaining = K.pomoRemaining = () => (P.running ? Math.max(0, P.endAt - Date.now()) : P.left);
  const fmt = K.pomoFmt = ms => {
    const s = Math.ceil(ms / 1000);
    const hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60;
    const two = n => String(n).padStart(2, '0');
    return hh ? `${hh}:${two(mm)}:${two(ss)}` : `${two(mm)}:${two(ss)}`;
  };
  /* Texto corto de una duración: "25 min", "1 h 50 min", "45 s" */
  K.durText = ms => {
    const t = Math.round(ms / 1000), hh = Math.floor(t / 3600), mm = Math.floor((t % 3600) / 60), ss = t % 60;
    if (hh) return `${hh} h${mm ? ' ' + mm + ' min' : ''}`;
    if (mm) return `${mm} min${ss ? ' ' + ss + ' s' : ''}`;
    return `${ss} s`;
  };
  /* Señal para otras herramientas (por ejemplo, la extensión que bloquea sitios): en <html>,
     data-tempo-bridge="1" (marca que la página es Tempo), data-focus="on|off" y data-focus-end
     (hora en ms en que termina el enfoque). También un evento "tempo:focus" con { active, mode, endAt }.
     Solo avisa cuando cambia. */
  let focusOn = null;
  try { document.documentElement.dataset.tempoBridge = '1'; } catch { /* sin DOM */ }
  const signalFocus = () => {
    const on = !!P.running && P.mode === 'focus';
    if (on === focusOn) return;
    focusOn = on;
    try {
      document.documentElement.dataset.focus = on ? 'on' : 'off';
      document.documentElement.dataset.focusEnd = on ? String(P.endAt) : '';
    } catch { /* sin DOM */ }
    try { window.dispatchEvent(new CustomEvent('tempo:focus', { detail: { active: on, mode: P.mode, endAt: on ? P.endAt : 0, target: P.target ? P.target.name : null } })); } catch { /* sin eventos */ }
  };
  const paint = () => {
    if (K.focusPaint) K.focusPaint();
    document.title = P.running ? `${fmt(remaining())} · ${LABEL[P.mode]} · Tempo` : 'Tempo';
    signalFocus();
  };
  const side = () => { if (K.focusSide) K.focusSide(); };

  /* ---------- Sesiones ---------- */
  K.targetName = t => {
    if (!t) return '';
    let n;
    if (t.kind === 'note') { const x = K.noteById(t.id); n = x && x.title; }
    else if (t.kind === 'label') { const x = K.labelById(t.id); n = x && x.name; }
    else if (t.kind === 'event') { const x = st.events.find(e => e.id === t.id); n = x && x.title; }
    else if (t.kind === 'block') { const x = st.blocks.find(b => b.id === t.id); n = x && x.title; }
    else if (t.kind === 'goal') { const x = K.goalById(t.id); n = x && x.name; }
    else if (t.kind === 'project') { const f = K.findProject(t.id); n = f && f.project.name; }
    else n = t.text;
    return n || t.name || t.text || 'Sin título';
  };

  /* El id sale de la hora de fin: si dos pestañas acreditan el mismo enfoque, queda una sola sesión */
  function logSession(endTs, ms = K.POMO.focus) {
    const id = 'focus-' + endTs;
    if (st.sessions.some(x => x.id === id)) return null;
    const s = { id, start: endTs - ms, end: endTs, ms, target: P.target ? { ...P.target, name: K.targetName(P.target) } : null, updatedAt: endTs, rev: 0 };
    st.sessions.push(s);
    K.usageBump('focus');
    K.run(K.api.saveSession(s));
    return s;
  }
  K.removeSession = s => {
    st.sessions = st.sessions.filter(x => x.id !== s.id);
    K.run(K.api.deleteSession(s.id));
    side();
    K.toast('Sesión quitada', () => { st.sessions.push(s); K.run(K.api.saveSession(s)); side(); });
  };

  /* Pasa a la etapa siguiente. `endTs`: cuándo terminó realmente (puede ser antes de abrir la app). */
  /* Cómo fue el enfoque: se pregunta al terminar (no bloquea). Si se ignora, la sesión queda sin calificar. */
  const RATINGS = [['bien', 'Bien'], ['medias', 'A medias'], ['distraje', 'Me distraje']];
  function askRating(s) {
    const h = K.h;   // este módulo no trae su propio h()
    document.querySelectorAll('.rate-card').forEach(x => x.remove());
    const card = h('div', { class: 'rate-card', role: 'group', 'aria-label': '¿Cómo fue el enfoque?' },
      h('span', { class: 'rate-q' }, '¿Cómo fue ese enfoque?'),
      h('div', { class: 'rate-btns' }, RATINGS.map(([v, label]) => h('button', {
        type: 'button', class: 'chip',
        onclick: () => { s.q = v; s.updatedAt = Date.now(); K.run(K.api.saveSession(s)); side(); card.remove(); },
      }, label))),
      h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Cerrar', svg: K.icon('x', 14), onclick: () => card.remove() }));
    document.body.append(card);
    setTimeout(() => card.remove(), 20000);
  }

  function complete(endTs, quiet) {
    const done = P.mode;
    const s = done === 'focus' ? logSession(endTs) : null;
    if (done === 'focus') P.cycle++;
    const next = done === 'focus' ? (P.cycle % K.POMO.every === 0 ? 'long' : 'short') : 'focus';
    if (done === 'long') P.cycle = 0;
    P.mode = next; P.left = K.POMO[next]; P.running = false; P.endAt = 0;
    stopTick(); persist(); paint(); side(); wakeSync();
    const msg = done === 'focus' ? `Enfoque terminado. Toca ${LABEL[next].toLowerCase()}.` : 'Pausa terminada. Vuelve el enfoque.';
    if (!quiet) { K.beep(); K.toast(msg); notify(msg); if (s) askRating(s); }
    return done;
  }

  function ensureTick() {
    if (tick) return;
    tick = setInterval(() => {
      if (!P.running) { stopTick(); paint(); return; }
      if (remaining() <= 0 && owner) complete(P.endAt || Date.now());   // solo la dueña cierra la etapa
      paint();
    }, 250);
  }
  function stopTick() { clearInterval(tick); tick = 0; }

  /* ---------- Varias pestañas ----------
     El estado vive en localStorage y todas las pestañas lo leen. Solo la dueña avanza el reloj,
     cierra etapas, guarda sesiones y maneja la pantalla encendida. La dueña es la pestaña que
     tiene el lock 'tempo-focus-owner': la primera que lo pide; si se cierra, la siguiente lo toma.
     Sin Web Locks, cada pestaña se comporta como dueña (como antes). */
  const OWNER_LOCK = 'tempo-focus-owner';

  /* Lee el estado guardado por cualquier pestaña. false si no hay nada o está dañado. */
  function readPomo() {
    let d = null;
    try { d = JSON.parse(localStorage.getItem(K.PREF.pomo)); } catch { return false; }
    if (!d || typeof d !== 'object') return false;
    ['focus', 'short', 'long'].forEach(m => { const v = d.dur && d.dur[m]; if (v >= 1000 && v <= 10799 * 1000) K.POMO[m] = v; });
    Object.assign(P, {
      mode: d.mode in LABEL ? d.mode : 'focus', left: Number(d.left) || K.POMO.focus, endAt: Number(d.endAt) || 0,
      running: !!d.running, cycle: d.cycle || 0, target: d.target && d.target.kind ? d.target : null,
    });
    return true;
  }

  /* Esta pestaña pasa a ser (o deja de ser) la dueña. Al ganar, retoma lo que venció sin nadie. */
  function setOwner(v) {
    if (owner === v) return;
    owner = v;
    if (!owner) { stopTick(); wakeSync(); return; }
    readPomo();
    if (P.running && remaining() <= 0) {
      const done = complete(P.endAt || Date.now(), true);   // se acredita con la hora real en que terminó
      K.toast(done === 'focus' ? 'Tu enfoque terminó mientras no estabas: ya quedó registrado.' : 'Tu pausa terminó mientras no estabas.');
    }
    if (P.running) ensureTick();
    paint(); side(); wakeSync();
  }

  /* Pide el lock. La promesa nunca se resuelve: el lock se conserva mientras la pestaña esté abierta. */
  function claimOwner() {
    if (!(navigator.locks && navigator.locks.request)) { setOwner(true); return; }
    navigator.locks.request(OWNER_LOCK, () => { setOwner(true); return new Promise(() => {}); })
      .catch(() => setOwner(true));
  }

  /* Otra pestaña cambió el temporizador: se toma tal cual quedó guardado */
  window.addEventListener('storage', e => {
    if (e.key !== K.PREF.pomo || !readPomo()) return;
    if (P.running) ensureTick(); else stopTick();
    paint(); side(); wakeSync();
  });

  /* ---------- Controles ---------- */
  /* Cuánto lleva de enfoque la etapa actual (0 si no es un enfoque) */
  K.pomoElapsed = () => (P.mode === 'focus' ? Math.max(0, K.POMO.focus - remaining()) : 0);
  /* ¿Hay avance suficiente para guardarlo, y todavía falta para terminar? */
  K.pomoCanFinish = () => P.mode === 'focus' && K.pomoElapsed() >= Math.min(K.POMO_MIN_SAVE, K.POMO.focus) && remaining() > 1000 && K.pomoElapsed() >= 60000;
  const wholeSecs = ms => Math.round(ms / 1000) * 1000;

  K.pomoSetMode = async mode => {
    if (K.pomoCanFinish()) {
      if (!(await K.ask({ title: 'Descartar el enfoque', danger: true, ok: 'Descartar',
        text: `Llevás ${K.durText(wholeSecs(K.pomoElapsed()))} de enfoque sin guardar. Si cambiás de etapa se pierden (podés usar “Terminar y guardar”).` }))) return;
    } else if (P.running && !(await K.ask({ title: 'Cambiar de etapa', danger: true, ok: 'Descartar',
      text: 'Hay un temporizador en marcha. Si cambiás de etapa, se descarta.' }))) return;
    P.mode = mode; P.left = K.POMO[mode]; P.running = false; P.endAt = 0;
    stopTick(); persist(); paint(); wakeSync();
  };
  K.pomoIsRunning = () => P.running;
  K.pomoToggle = () => {
    if (P.running) { P.left = remaining(); P.running = false; P.endAt = 0; stopTick(); }
    else {
      if (P.left <= 0) P.left = K.POMO[P.mode];
      P.endAt = Date.now() + P.left; P.running = true;
      ensureTick(); audio();
    }
    persist(); paint(); wakeSync();
  };
  /* force: sin preguntar (lo usa "Borrar todo") */
  K.pomoReset = async force => {
    if (force !== true && K.pomoCanFinish()
      && !(await K.ask({ title: 'Reiniciar el enfoque', danger: true, ok: 'Reiniciar',
        text: `Llevás ${K.durText(wholeSecs(K.pomoElapsed()))} de enfoque sin guardar. Reiniciar los descarta.` }))) return;
    P.left = K.POMO[P.mode]; P.running = false; P.endAt = 0; stopTick(); persist(); paint(); wakeSync();
  };

  /* Corta el enfoque ahora y guarda lo trabajado; sigue la pausa corta (no suma al ciclo de 4) */
  K.pomoFinishEarly = () => {
    if (!K.pomoCanFinish()) return false;
    const ms = wholeSecs(K.pomoElapsed());
    logSession(Date.now(), ms);
    P.mode = 'short'; P.left = K.POMO.short; P.running = false; P.endAt = 0;
    stopTick(); persist(); paint(); side(); wakeSync();
    K.toast(`Guardé ${K.durText(ms)} de enfoque. Toca pausa corta.`);
    return true;
  };
  /* Saltar: un enfoque con avance se guarda (no se tira); lo demás cambia de etapa como siempre */
  K.pomoSkip = () => { if (!K.pomoFinishEarly()) K.pomoSetMode(P.mode === 'focus' ? 'short' : 'focus'); };

  K.setPreset = (f, s, l) => {
    if (P.running) return;
    K.POMO.focus = f * MIN; K.POMO.short = s * MIN; K.POMO.long = l * MIN;
    P.left = K.POMO[P.mode];
    persist(); paint();
  };
  /* Ajuste rápido de la duración de una etapa (de a 1 min, mínimo 1 min). No cambia mientras el reloj corre.
     Devuelve false si no hizo nada (corriendo, o ya en el límite). */
  K.adjustDuration = (mode, deltaSec) => {
    if (P.running) return false;
    const cur = Math.round(K.POMO[mode] / 1000);
    const next = Math.min(10799, Math.max(60, cur + deltaSec));
    if (next === cur) return false;
    K.POMO[mode] = next * 1000;
    if (P.mode === mode) P.left = K.POMO[mode];
    persist(); paint();
    return true;
  };
  /* Escribir la duración en minutos (como la alarma del celular). Entre 1 y 179 min. No cambia mientras corre.
     Devuelve false si el valor no es válido, si corre el reloj o si no cambia nada. */
  K.setDurationMin = (mode, minutes) => {
    const m = Math.round(Number(minutes));
    if (P.running || !Number.isFinite(m) || m < 1 || m > 179) return false;
    if (m * 60000 === K.POMO[mode]) return false;
    K.POMO[mode] = m * 60000;
    if (P.mode === mode) P.left = K.POMO[mode];
    persist(); paint();
    return true;
  };
  K.setTarget = t => { P.target = t ? { ...t, name: K.targetName(t) } : null; persist(); if (K.focusPaint) K.focusPaint(true); };

  /* Al cargar: retoma el temporizador guardado */
  /* Al cargar: toma el estado guardado y pide ser la dueña. Si ya había una dueña, esta pestaña solo lo muestra.
     Lo que venció mientras no había app se acredita cuando la dueña lo toma (setOwner). */
  K.pomoResume = () => {
    readPomo();
    if (P.running) ensureTick();
    claimOwner();
    paint();
  };

  /* ---------- Estadísticas (también las usará Métricas) ---------- */
  const dayStart = ts => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };
  K.focusStats = () => {
    const t0 = dayStart(Date.now());
    const d = new Date(t0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    const w0 = d.getTime();
    const week = [0, 0, 0, 0, 0, 0, 0];
    const today = [];
    st.sessions.forEach(s => {
      if (s.end >= w0) { const i = Math.min(6, Math.floor((dayStart(s.end) - w0) / 86400000)); if (i >= 0) week[i] += s.ms / MIN; }
      if (s.end >= t0) today.push(s);
    });
    today.sort((a, b) => b.end - a.end);
    return {
      todayMin: Math.round(today.reduce((n, s) => n + s.ms / MIN, 0)),
      todayCount: today.length, today,
      weekMin: Math.round(week.reduce((n, m) => n + m, 0)), week,
      todayIdx: (new Date().getDay() + 6) % 7,
    };
  };

  /* Al volver a la pestaña: si el tiempo se cumplió mientras estaba dormida, se acredita ya (con su hora real) */
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && owner && P.running && remaining() <= 0) complete(P.endAt || Date.now());
    wakeSync();
  });

  /* Barra espaciadora: iniciar / pausar (solo en la pantalla Foco) */
  document.addEventListener('keydown', e => {
    if (e.code !== 'Space' || st.route.name !== 'focus' || st.editor || K.$('.palette') || K.hasPop()) return;
    const el = document.activeElement;
    if (el && (/INPUT|TEXTAREA|SELECT|BUTTON|A/.test(el.tagName) || el.isContentEditable)) return;
    e.preventDefault(); K.pomoToggle();
  });
})();
