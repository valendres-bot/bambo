/* =========================================================
   drag.js — arrastrar notas y etiquetas.
   - Mouse: se arrastra al mover unos píxeles.
   - Táctil: mantener apretado ~0,4 s (así el scroll sigue funcionando).
   - Al arrastrar sobre otro elemento del mismo grupo, se intercambian de lugar.
   - Al soltar sobre un destino ([data-drop]) se llama ctx.onDrop(item, key).

   ctx = {
     container,            // contenedor donde se reordena
     reorder: bool,        // si se puede reordenar
     item: selector,       // qué elementos hermanos se intercambian (default: [data-note-id])
     skip: selector,       // qué no inicia el arrastre (default: botones, links, campos)
     accept(key) → bool,   // qué destinos [data-drop] aceptan este elemento
     onDrop(item, key),    // se llama al soltar sobre un destino
     relayout?: fn,        // para tarjetas (masonry)
     commit: fn,           // se llama al terminar de reordenar
   }
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  const MOVE_PX = 6, HOLD_MS = 380, TOUCH_CANCEL_PX = 10;
  const DEFAULT_SKIP = 'button, a, input, textarea, select';
  let g = null;               // gesto en curso
  let suppressUntil = 0;      // evita que el "click" posterior a un arrastre abra la nota

  K.dragSuppressed = () => Date.now() < suppressUntil;
  K.hit = (x, y) => (document.elementFromPoint ? document.elementFromPoint(x, y) : null);

  /* Los links y las notas no deben disparar el arrastre nativo del navegador (cancela nuestro arrastre) */
  document.addEventListener('dragstart', e => { if (e.target.closest && e.target.closest('a, [data-note-id], [data-label-id]')) e.preventDefault(); });

  /* Una vez que el arrastre táctil empezó, el navegador no debe hacer scroll */
  document.addEventListener('touchmove', e => { if (g && g.active) e.preventDefault(); }, { passive: false });

  K.attachDrag = (el, item, ctx) => {
    el.addEventListener('pointerdown', e => {
      if (g || (e.button != null && e.button > 0)) return;
      if (e.target.closest(ctx.skip || DEFAULT_SKIP)) return;
      g = {
        el, item, ctx, id: e.pointerId, type: e.pointerType,
        sx: e.clientX, sy: e.clientY, x: e.clientX, y: e.clientY,
        active: false, timer: 0, raf: 0, last: null, dropEl: null, ghost: null, dx: 0, dy: 0, moved: false,
      };
      if (g.type === 'touch') g.timer = setTimeout(() => { if (g && !g.active) begin(); }, HOLD_MS);
      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
      window.addEventListener('pointercancel', onCancel);
    });
  };

  function begin() {
    clearTimeout(g.timer);
    K.closePop();
    g.active = true;
    const r = g.el.getBoundingClientRect();
    g.dx = g.x - r.left; g.dy = g.y - r.top;
    g.ghost = g.el.cloneNode(true);
    g.ghost.classList.add('drag-ghost');
    Object.assign(g.ghost.style, {
      position: 'fixed', left: '0', top: '0', margin: '0', width: r.width + 'px',
      pointerEvents: 'none', zIndex: '90', transition: 'none',
      transform: `translate(${r.left}px, ${r.top}px)`,
    });
    document.body.append(g.ghost);
    g.el.classList.add('drag-src');
    document.body.classList.add('dragging');
    if (navigator.vibrate) { try { navigator.vibrate(8); } catch { /* sin vibración */ } }
    loop();
    update();
  }

  function setDrop(el) {
    if (g.dropEl === el) return;
    if (g.dropEl) g.dropEl.classList.remove('drop-hover');
    g.dropEl = el;
    if (el) el.classList.add('drop-hover');
  }

  function update() {
    g.ghost.style.transform = `translate(${g.x - g.dx}px, ${g.y - g.dy}px)`;
    const under = K.hit(g.x, g.y);
    /* Primero el reordenamiento entre hermanos: así una lista con destinos [data-drop] se puede ordenar */
    const sel = g.ctx.item || '[data-note-id]';
    const other = g.ctx.reorder && under && under.closest ? under.closest(sel) : null;
    const cont = g.ctx.container;
    if (other && other !== g.el && other.parentNode === cont) {
      setDrop(null);
      if (other !== g.last) {
        g.last = other;
        g.moved = true;
        const kids = [...cont.children];
        if (kids.indexOf(g.el) < kids.indexOf(other)) other.after(g.el); else other.before(g.el);
        if (g.ctx.relayout) g.ctx.relayout();
      }
      return;
    }
    const found = under && under.closest ? under.closest('[data-drop]') : null;
    const accepted = found && (!g.ctx.accept || g.ctx.accept(found.dataset.drop)) ? found : null;
    setDrop(accepted);
  }

  /* Scroll automático cerca de los bordes mientras se arrastra */
  function loop() {
    if (!g || !g.active) return;
    const top = 56 + 70, bottom = innerHeight - 70;
    let dy = 0;
    if (g.y < top) dy = -Math.ceil((top - g.y) / 6);
    else if (g.y > bottom) dy = Math.ceil((g.y - bottom) / 6);
    if (dy) { window.scrollBy(0, dy); update(); }
    g.raf = requestAnimationFrame(loop);
  }

  function onMove(e) {
    if (!g || e.pointerId !== g.id) return;
    g.x = e.clientX; g.y = e.clientY;
    if (!g.active) {
      const d = Math.hypot(g.x - g.sx, g.y - g.sy);
      if (g.type === 'touch') { if (d > TOUCH_CANCEL_PX) end(); }   // era un scroll
      else if (d > MOVE_PX) begin();
      return;
    }
    e.preventDefault();
    update();
  }

  function visualsOff() {
    if (g.ghost) g.ghost.remove();
    g.el.classList.remove('drag-src');
    setDrop(null);
    document.body.classList.remove('dragging');
  }
  function end() {
    if (!g) return;
    clearTimeout(g.timer);
    cancelAnimationFrame(g.raf);
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    window.removeEventListener('pointercancel', onCancel);
    g = null;
  }

  function onUp(e) {
    if (!g || e.pointerId !== g.id) return;
    if (!g.active) { end(); return; }             // fue un click normal
    const { item, ctx, x, y, moved } = g;
    let key = g.dropEl && g.dropEl.dataset.drop;
    /* Si se reordenó entre hermanos y solo quedó sobre el fondo de la misma lista, eso es reordenar, no soltar */
    if (moved && ctx.reorder && key === 'none') key = null;
    visualsOff();
    end();
    suppressUntil = Date.now() + 80;
    if (key && ctx.onDrop) ctx.onDrop(item, key, x, y);
    else if (ctx.reorder && ctx.commit && moved) ctx.commit();
  }

  function onCancel(e) {
    if (!g || e.pointerId !== g.id) return;
    const was = g.active;
    if (was) visualsOff();
    end();
    if (was) { suppressUntil = Date.now() + 80; K.refresh(); }   // restaura el orden real
  }
})();
