/* =========================================================
   goalsui.js — pantallas de Objetivos (goals.js tiene el modelo y las acciones).
   · #/goals      lista: crear un objetivo (basta un nombre), activos y archivados.
   · #/goal/ID    detalle: datos del objetivo, avance, el plan (bloque General y proyectos
                  desplegables, cada uno con sus pendientes y recursos).
   Los pendientes son los mismos de Pendientes: se tildan y se quitan desde acá. Al agregar,
   cada línea del texto es un pendiente (igual que en Pendientes).
   Un bloque de proyecto se puede renombrar (doble clic en el nombre o el lápiz), subir o bajar,
   duplicar, quitar y plegar. Abierto o plegado se recuerda solo mientras la pantalla está abierta.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;

  /* Estado de edición de esta pantalla (sobrevive a los re-renders, no se guarda) */
  const GENERAL = '__general';
  const ui = {
    renaming: null,          // id del proyecto que se está renombrando en línea
    addingProject: false,
    open: new Map(),         // bloque (id de proyecto o GENERAL) → abierto (true) o plegado (false) a mano
  };

  const pct = (done, total) => (total ? Math.round((done / total) * 100) : 0);
  const shortDate = ds => K.dayLabel(ds);

  /* ---------- Lista ---------- */
  function goalCard(g) {
    const pr = K.goalProgress(g);
    const next = K.goalNextDue(g);
    const meta = [];
    meta.push(pr.total ? `${pr.done} de ${pr.total} pendientes hechas` : 'Sin pendientes todavía');
    if (g.projects.length) meta.push(g.projects.length === 1 ? '1 proyecto' : `${g.projects.length} proyectos`);
    if (next) meta.push(`próximo: ${shortDate(next.due).toLowerCase()}`);
    else if (g.deadline) meta.push(`fecha límite: ${shortDate(g.deadline).toLowerCase()}`);
    return h('a', { class: 'goal-card' + (g.archived ? ' archived' : ''), href: K.hashFor({ name: 'goal', id: g.id }) },
      h('span', { class: 'goal-card-top' },
        h('span', { class: 'goal-cat' }, K.goalCat(g.category)),
        g.archived ? h('span', { class: 'goal-status' }, 'Archivado') : null),
      h('span', { class: 'goal-card-name' }, g.name),
      h('span', { class: 'goal-bar', 'aria-hidden': 'true' }, h('span', { class: 'goal-bar-fill', style: `width:${pct(pr.done, pr.total)}%` })),
      h('span', { class: 'goal-card-meta' }, meta.join(' · ')));
  }

  K.renderGoals = root => {
    root.append(h('div', { class: 'page-head' },
      h('h1', { class: 'page-title' }, h('span', { class: 'page-ico', svg: icon('target', 26) }), 'Objetivos'),
      h('p', { class: 'page-sub' }, 'Lo que querés lograr. Cada objetivo se organiza en proyectos, pendientes y recursos.')));

    root.append(h('form', {
      class: 'goal-new', onsubmit: e => {
        e.preventDefault();
        const name = e.currentTarget.elements.name.value.trim();
        if (!name) { e.currentTarget.elements.name.focus(); return; }
        const g = K.createGoal({ name, category: e.currentTarget.elements.category.value });
        K.toast('Objetivo creado');
        K.go({ name: 'goal', id: g.id });
      },
    },
    h('input', { name: 'name', class: 'goal-new-in', maxlength: '120', autocomplete: 'off', placeholder: 'Ej.: Aprobar Matemática, Correr 10 km, Lanzar un negocio',
      'aria-label': 'Nombre del objetivo' }),
    h('select', { name: 'category', class: 'goal-sel', 'aria-label': 'Ámbito' },
      K.GOAL_CATS.map(([id, label]) => h('option', { value: id }, label))),
    h('button', { type: 'submit', class: 'btn primary' }, 'Crear objetivo')));

    const all = K.state.goals.slice().sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
    if (!all.length) {
      root.append(h('p', { class: 'fx-empty goal-empty' }, 'Todavía no tenés objetivos. Alcanza con un nombre: después podés sumar proyectos, pendientes y recursos.'));
      return;
    }
    const open = all.filter(g => !g.archived);
    const archived = all.filter(g => g.archived);
    if (open.length) root.append(h('div', { class: 'goal-list' }, open.map(goalCard)));
    else root.append(h('p', { class: 'goal-muted goal-empty' }, 'Todos los objetivos están archivados.'));
    if (archived.length) root.append(h('h2', { class: 'goal-sub-title' }, 'Archivados'), h('div', { class: 'goal-list' }, archived.map(goalCard)));
  };

  /* ---------- Recursos ---------- */
  function resourceRow(g, r) {
    const note = r.kind === 'note' ? K.noteById(r.noteId) : null;
    const missing = r.kind === 'note' && (!note || !K.isLive(note));
    const label = r.kind === 'note' ? (missing ? 'Nota no disponible' : (note.title || 'Sin título')) : r.title;
    const body = r.kind === 'link'
      ? h('a', { class: 'goal-res-name', href: r.url, target: '_blank', rel: 'noopener noreferrer' }, label)
      : h('button', { type: 'button', class: 'goal-res-name' + (missing ? ' missing' : ''), disabled: missing ? '' : null,
          onclick: () => K.openNote(note) }, label);
    return h('li', { class: 'goal-res' },
      h('span', { class: 'goal-res-ico', svg: icon(r.kind === 'link' ? 'external' : 'file', 15) }),
      body,
      h('button', { type: 'button', class: 'task-del', title: 'Quitar del objetivo', 'aria-label': 'Quitar: ' + label,
        svg: icon('x', 14), onclick: () => K.removeResource(g, r.id) }));
  }

  function notePicker(g, pid, anchor) {
    const have = new Set(K.projectResources(g, pid).filter(r => r.kind === 'note').map(r => r.noteId));
    const notes = K.state.notes.filter(n => K.isLive(n) && !have.has(n.id))
      .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)).slice(0, 60);
    const items = notes.length
      ? notes.map(n => ({ label: n.title || 'Sin título', icon: 'file', run: () => K.addResourceNote(g, pid, n.id) }))
      : [{ label: 'No hay notas para agregar: creá una en Notas', icon: 'file', run: () => K.go({ name: 'all' }) }];
    K.togglePop(anchor, () => K.menu(items));
  }

  function resourcesOf(g, pid) {
    const list = K.projectResources(g, pid);
    return h('div', { class: 'goal-res-box' },
      list.length ? h('ul', { class: 'goal-res-list' }, list.map(r => resourceRow(g, r)))
        : h('p', { class: 'goal-muted' }, 'Sin recursos. Sumá notas o enlaces que necesites para esto.'),
      h('div', { class: 'goal-res-add' },
        h('button', { type: 'button', class: 'btn quiet', onclick: e => notePicker(g, pid, e.currentTarget) },
          h('span', { svg: icon('file', 15) }), ' Agregar nota'),
        h('details', { class: 'goal-link-add' },
          h('summary', {}, h('span', { svg: icon('link', 15) }), ' Agregar enlace'),
          h('form', {
            class: 'goal-link-form', onsubmit: e => {
              e.preventDefault();
              const f = e.currentTarget.elements;
              if (!K.addResourceLink(g, pid, f.title.value, f.url.value)) { K.toast('El enlace tiene que empezar con http:// o https://'); f.url.focus(); }
            },
          },
          h('input', { name: 'title', class: 'goal-in', placeholder: 'Título (opcional)', maxlength: '160', 'aria-label': 'Título del enlace' }),
          h('input', { name: 'url', class: 'goal-in', type: 'url', placeholder: 'https://…', maxlength: '2000', required: '', 'aria-label': 'Dirección del enlace' }),
          h('button', { type: 'submit', class: 'btn' }, 'Agregar')))));
  }

  /* ---------- Pendientes de un bloque ---------- */
  function tasksOf(g, pid) {
    const singles = K.projectTasks(g, pid).sort(K.byDue);
    const open = singles.filter(t => !t.done);
    const doneList = singles.filter(t => t.done);
    const routines = K.goalTasks(g).filter(t => K.routineBlock(t) && (t.projectId || null) === (pid || null)).length;
    return h('div', { class: 'goal-tasks-box' },
      open.length || doneList.length
        ? h('ul', { class: 'goal-tasks' }, [...open, ...doneList].map(t => K.taskItem(t)))
        : h('p', { class: 'goal-muted' }, 'Sin pendientes en este bloque todavía.'),
      routines ? h('p', { class: 'goal-muted goal-routines' }, routines === 1 ? '1 rutina vinculada: se tilda desde Hoy.' : `${routines} rutinas vinculadas: se tildan desde Hoy.`) : null,
      h('form', {
        class: 'goal-add', onsubmit: e => {
          e.preventDefault();
          const inp = e.currentTarget.elements.text;
          const items = K.parseCapture(inp.value);
          if (!items.length) { inp.focus(); return; }
          K.addTasks(items, { goalId: g.id, projectId: pid || null });
          K.toast(items.length === 1 ? 'Pendiente agregado' : `${items.length} pendientes agregados`);
          K.refreshAll();
        },
      },
      h('textarea', { name: 'text', class: 'goal-in goal-add-in', rows: '1', maxlength: '20000', 'aria-label': 'Agregar pendientes',
        placeholder: 'Agregar pendiente a este bloque… Una línea por pendiente. Ctrl/⌘+Enter agrega.',
        onkeydown: e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); e.currentTarget.form.requestSubmit(); } } }),
      h('button', { type: 'submit', class: 'btn quiet' }, h('span', { svg: icon('plus', 15) }), ' Agregar')));
  }

  /* ---------- Bloque plegable (General y proyectos) ---------- */
  const isOpen = (key, def) => (ui.open.has(key) ? ui.open.get(key) : def);
  function toggleBlock(sec, key) {
    const open = !sec.classList.contains('is-open');
    sec.classList.toggle('is-open', open);
    sec.querySelector('.gp-body').hidden = !open;
    sec.querySelector('.gp-chev').setAttribute('aria-expanded', String(open));
    ui.open.set(key, open);
  }
  function gpBlock({ key, def, general = false, label, name, count = null, extra = null, tools = null, body }) {
    const open = isOpen(key, def);
    const sec = h('section', { class: 'gp' + (general ? ' gp-general' : '') + (open ? ' is-open' : '') });
    const chev = h('button', { type: 'button', class: 'gp-chev', 'aria-expanded': String(open), 'aria-label': 'Mostrar u ocultar: ' + label,
      svg: icon('chevron', 14), onclick: () => toggleBlock(sec, key) });
    /* Un clic en cualquier parte de la cabecera plega o despliega (salvo en los botones y campos) */
    const head = h('div', { class: 'gp-head', onclick: e => { if (!e.target.closest('button, input, textarea, a')) toggleBlock(sec, key); } },
      chev, name, count, extra, tools);
    sec.append(head, h('div', { class: 'gp-body', hidden: open ? null : true }, body));
    return sec;
  }

  /* ---------- Proyecto ---------- */
  const startRename = p => { ui.renaming = p.id; K.refreshAll(); };

  /* Campo en línea para renombrar: Enter o salir guarda, Escape cancela */
  function renameInput(g, p) {
    const input = h('input', { class: 'gp-name-in', maxlength: '120', placeholder: 'Nombre del proyecto', 'aria-label': 'Nombre del proyecto' });
    input.value = p.name;
    let done = false;
    const finish = save => {
      if (done) return;
      done = true;
      const name = input.value.trim();
      ui.renaming = null;
      if (save && name) K.updateProject(g, p.id, { name }); else K.refreshAll();
    };
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
    setTimeout(() => { input.focus(); input.select(); }, 0);
    return input;
  }

  function projectMenu(g, p) {
    return [
      { label: 'Renombrar', icon: 'edit', run: () => startRename(p) },
      { label: 'Duplicar', icon: 'copy', run: () => { if (K.duplicateProject(g, p.id)) K.toast('Proyecto duplicado'); } },
      { label: 'Enfocar en este proyecto', icon: 'timer', run: () => K.focusOnProject(g, p) },
      '-',
      { label: 'Quitar proyecto', icon: 'trash', run: () => K.ask({
        title: '¿Quitar el proyecto “' + p.name + '”?',
        text: 'Sus pendientes y recursos no se borran: pasan al bloque General del objetivo.',
        ok: 'Quitar proyecto', danger: true,
        }).then(ok => { if (ok) K.removeProject(g, p.id); }) },
    ];
  }

  function projectTools(g, p, i, n) {
    return h('span', { class: 'gp-tools' },
      h('button', { type: 'button', class: 'gp-tool', title: 'Renombrar', 'aria-label': 'Renombrar: ' + p.name,
        svg: icon('edit', 15), onclick: () => startRename(p) }),
      h('button', { type: 'button', class: 'gp-tool', title: 'Subir', 'aria-label': 'Subir: ' + p.name,
        svg: icon('up', 15), disabled: i === 0 ? true : null, onclick: () => K.moveProject(g, p.id, -1) }),
      h('button', { type: 'button', class: 'gp-tool', title: 'Bajar', 'aria-label': 'Bajar: ' + p.name,
        svg: icon('down', 15), disabled: i === n - 1 ? true : null, onclick: () => K.moveProject(g, p.id, 1) }),
      h('button', { type: 'button', class: 'gp-tool', title: 'Más opciones', 'aria-label': 'Opciones del proyecto: ' + p.name,
        svg: icon('more', 16), onclick: e => K.togglePop(e.currentTarget, () => K.menu(projectMenu(g, p))) }));
  }

  function projectBlock(g, p, i, n) {
    const singles = K.projectTasks(g, p.id).filter(t => !K.routineBlock(t));
    const done = singles.filter(t => t.done).length;
    const renaming = ui.renaming === p.id;
    const days = p.deadline ? K.daysUntil(p.deadline) : null;
    const name = renaming
      ? renameInput(g, p)
      : h('span', { class: 'gp-name', title: 'Doble clic para renombrar', ondblclick: () => startRename(p) }, p.name);
    return gpBlock({
      key: p.id, def: true, label: p.name,
      name,
      count: renaming ? null : h('span', { class: 'gp-count' }, singles.length ? `${done} de ${singles.length}` : 'vacío'),
      extra: p.deadline ? h('span', { class: 'task-due' + (days < 0 ? ' overdue' : days <= 7 ? ' soon' : ''), title: p.deadline }, shortDate(p.deadline)) : null,
      tools: renaming ? null : projectTools(g, p, i, n),
      body: [
        h('label', { class: 'gp-date' }, h('span', {}, 'Fecha límite'),
          h('input', { type: 'date', value: p.deadline || '', 'aria-label': 'Fecha límite de ' + p.name,
            onchange: e => K.updateProject(g, p.id, { deadline: e.target.value || null }) })),
        tasksOf(g, p.id),
        h('h4', { class: 'gp-sub' }, 'Recursos'),
        resourcesOf(g, p.id),
      ],
    });
  }

  /* Bloque General: pendientes y recursos del objetivo sin proyecto */
  function generalBlock(g) {
    const hasAny = K.projectTasks(g, null).length || K.projectResources(g, null).length;
    return gpBlock({
      key: GENERAL, def: !!hasAny || !g.projects.length, general: true, label: 'General',
      name: h('span', { class: 'gp-name' }, 'General'),
      count: h('span', { class: 'gp-count' }, 'sin proyecto'),
      body: [
        h('p', { class: 'goal-muted' }, 'Lo que es del objetivo en general, sin un proyecto puntual.'),
        tasksOf(g, null),
        h('h4', { class: 'gp-sub' }, 'Recursos'),
        resourcesOf(g, null),
      ],
    });
  }

  /* ---------- Detalle ---------- */
  const setArchived = (g, archived) => {
    K.updateGoal(g, { archived });
    K.toast(archived ? 'Objetivo archivado' : 'Objetivo desarchivado', () => K.updateGoal(g, { archived: !archived }));
  };

  K.renderGoal = (root, r) => {
    const g = K.goalById(r.id);
    if (!g) { K.go({ name: 'goals' }); return; }
    const pr = K.goalProgress(g);
    const next = K.goalNextDue(g);

    root.append(h('div', { class: 'goal-top' },
      h('a', { class: 'goal-back', href: '#/goals' }, h('span', { svg: icon('chevron', 14) }), ' Objetivos'),
      h('span', { class: 'goal-cat' }, K.goalCat(g.category)),
      g.archived ? h('span', { class: 'goal-status' }, 'Archivado') : null));

    root.append(h('input', {
      class: 'goal-name-in', value: g.name, maxlength: '120', 'aria-label': 'Nombre del objetivo',
      onchange: e => { const v = e.target.value.trim(); if (v) K.updateGoal(g, { name: v }); else e.target.value = g.name; },
    }));

    root.append(h('div', { class: 'goal-actions' },
      h('button', { type: 'button', class: 'btn', onclick: () => K.focusOnGoal(g) }, h('span', { svg: icon('timer', 16) }), ' Enfocar en este objetivo'),
      h('button', { type: 'button', class: 'btn quiet', onclick: () => setArchived(g, !g.archived) },
        h('span', { svg: icon(g.archived ? 'unarchive' : 'archive', 16) }), g.archived ? ' Desarchivar' : ' Archivar'),
      h('button', { type: 'button', class: 'btn quiet danger-text', onclick: () => K.ask({
        title: '¿Eliminar el objetivo?', danger: true, ok: 'Eliminar',
        text: 'Sus proyectos y recursos se borran. Los pendientes siguen en Hoy, sin objetivo. Las notas de la app no se borran.',
      }).then(ok => { if (ok) { K.removeGoal(g); K.go({ name: 'goals' }); } }) },
      h('span', { svg: icon('trash', 16) }), ' Eliminar')));

    /* Datos del objetivo: sin cajas, campos con una línea abajo */
    const sel = (opts, value, label, onchange) => h('select', { class: 'goal-sel', 'aria-label': label, onchange },
      opts.map(([id, text]) => h('option', { value: id, selected: value === id ? '' : null }, text)));
    root.append(h('section', { class: 'goal-fields' },
      h('label', {}, h('span', {}, 'Ámbito'), sel(K.GOAL_CATS, g.category, 'Ámbito', e => K.updateGoal(g, { category: e.target.value }))),
      h('label', {}, h('span', {}, 'Inicio'), h('input', { type: 'date', class: 'goal-in', value: g.startDate || '', 'aria-label': 'Fecha de inicio',
        onchange: e => K.updateGoal(g, { startDate: e.target.value || null }) })),
      h('label', {}, h('span', {}, 'Fecha límite'), h('input', { type: 'date', class: 'goal-in', value: g.deadline || '', 'aria-label': 'Fecha límite del objetivo',
        onchange: e => K.updateGoal(g, { deadline: e.target.value || null }) })),
      h('label', { class: 'goal-wide' }, h('span', {}, 'Descripción'),
        h('textarea', { class: 'goal-in', rows: '2', maxlength: '2000', 'aria-label': 'Descripción del objetivo',
          onchange: e => K.updateGoal(g, { description: e.target.value.trim() }) }, g.description))));

    /* Avance */
    const nextText = next ? `Próximo: ${next.text} · ${shortDate(next.due).toLowerCase()}` : (g.deadline ? `Fecha límite: ${shortDate(g.deadline).toLowerCase()}` : '');
    root.append(h('section', { class: 'goal-progress' },
      h('div', { class: 'goal-progress-top' },
        h('b', {}, pr.total ? `${pr.done} de ${pr.total}` : '0'),
        h('span', {}, pr.total === 1 ? 'pendiente hecha' : 'pendientes hechas')),
      h('span', { class: 'goal-bar' }, h('span', { class: 'goal-bar-fill', style: `width:${pct(pr.done, pr.total)}%` })),
      nextText ? h('p', { class: 'goal-muted goal-next' }, nextText) : null));

    /* Plan: General + proyectos, en orden */
    root.append(h('div', { class: 'goal-plan-head' },
      h('h2', {}, 'Plan'),
      ui.addingProject
        ? K.nameInput({
          placeholder: 'Nombre del proyecto (ej.: Parcial 1, Semana 2, Etapa de diseño)',
          onSubmit: name => { ui.addingProject = false; K.addProject(g, name); },
          onCancel: () => { ui.addingProject = false; K.refreshAll(); },
        })
        : h('button', { type: 'button', class: 'btn quiet', onclick: () => { ui.addingProject = true; K.refreshAll(); } },
          h('span', { svg: icon('plus', 15) }), ' Proyecto')));

    const projects = K.goalProjects(g);
    root.append(h('div', { class: 'goal-flow' }, generalBlock(g), projects.map((p, i) => projectBlock(g, p, i, projects.length))));
    if (!g.projects.length) root.append(h('p', { class: 'goal-muted goal-hint' },
      'Dividí el objetivo en proyectos (por ejemplo, cuatrimestres, etapas o entregables). Podés dejar todo en General si no hace falta.'));
  };
})();
