/* =========================================================
   today.js — Hoy (1.26.0): el inicio de Tempo. Es la pantalla desde la que se trabaja.
   De arriba abajo:
   · Resumen en una línea: pendientes para hoy y minutos de foco del día (cada uno lleva a su pantalla).
   · Siguiente paso: la primera tarea de hoy (vencidas primero), con "Empezar enfoque"
     (arranca el temporizador con esa tarea) y "Hecha". Si no hay nada urgente, lo dice.
   · Días del mes: se elige un día tocándolo. Como en Calendario, en celular se desliza de costado
     para pasar de día en día.
   · Día elegido, de arriba abajo: vencidas (solo si es hoy), las franjas horarias del día ordenadas
     por hora (los bloques de la rutina y las franjas propias, con sus pendientes adentro), y los
     pendientes del día que no están en ninguna franja.
   · Captura: un solo campo. Enter agrega. "Vence" ofrece también el día que se está viendo.
   · Sin fecha · Hechas (plegadas).
   Los pendientes son registros propios (tasks.js), no líneas de las notas. Las franjas son registros
   propios (colección "slots"): { id, date, title, start, end, color }. Un pendiente en una franja tiene
   blockId y su fecha es la de la franja.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;

  const pad = n => String(n).padStart(2, '0');
  const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parseYmd = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = n => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + n); return ymd(d); };
  const shiftDay = (ds, n) => { const d = parseYmd(ds); d.setDate(d.getDate() + n); return ymd(d); };
  const idxOf = ds => (parseYmd(ds).getDay() + 6) % 7;          // 0 = lunes (como en los bloques)
  const DAY_LONG = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];
  const MONTH_LONG = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
  const longDate = ds => { const d = parseYmd(ds); return `${DAY_LONG[idxOf(ds)]} ${d.getDate()} de ${MONTH_LONG[d.getMonth()]}`; };

  /* Domingo de la semana actual (la semana va de lunes a domingo). Si hoy es domingo, es hoy. */
  K.weekEnd = () => addDays((7 - new Date().getDay()) % 7);

  /* Sueltas y abiertas con fecha que vencieron o vencen hasta el domingo (las rutinas van aparte) */
  K.todayTasks = () => K.allTasks().filter(t => !t.done && !K.routineBlock(t) && t.due && K.daysUntil(t.due) <= K.daysUntil(K.weekEnd()));
  /* Sin fecha: sueltas y abiertas sin @fecha */
  K.undatedTasks = () => K.allTasks().filter(t => !t.done && !K.routineBlock(t) && !t.due);
  /* Para el contador de la barra lateral: vencidas + las de hoy + las rutinas de hoy que faltan */
  K.todayCount = () => {
    const today = addDays(0);
    return K.todayTasks().filter(t => K.daysUntil(t.due) <= 0).length
      + K.routineOccurrences(today, today).filter(x => !K.isDone(x.t, today)).length;
  };

  /* ---------- Día elegido ---------- */
  /* Día que se ve en Hoy. En el estado se guarda null cuando es hoy, así cambia solo al pasar la medianoche. */
  K.hoySel = () => K.state.hoySel || addDays(0);
  /* Cambia el día que se ve. Si no es hoy, la captura ofrece \"Día elegido\" en Vence. */
  K.hoyGo = ds => {
    const today = addDays(0);
    K.state.hoySel = ds === today ? null : ds;
    K.renderList();
  };

  /* ---------- Franjas (colección \"slots\") ---------- */
  K.slotById = id => (id && K.state.blocks.find(s => s.id === id)) || null;
  /* Franjas de un día, en orden de hora */
  K.slotsOn = ds => K.occurrencesOn(K.state.blocks, ds);
  K.saveSlot = s => K.saveBlock(s);

  /* Borra una franja con deshacer. Sus pendientes siguen en el día, pero sin franja. */
  K.removeSlot = s => {
    const cur = K.slotById(s.id);
    if (!cur) { K.refreshAll(); return; }
    const snap = { ...cur };
    const ids = K.allTasks().filter(t => t.blockId === cur.id).map(t => t.id);
    K.state.blocks = K.state.blocks.filter(x => x.id !== cur.id);
    K.run(K.api.deleteBlock(cur.id));
    ids.forEach(id => { const t = K.taskById(id); if (t) { t.blockId = null; K.persistTask(t); } });
    K.refreshAll();
    K.toast('Franja eliminada', () => {
      K.state.blocks.push(snap); K.saveSlot(snap);
      ids.forEach(id => { const t = K.taskById(id); if (t) { t.blockId = snap.id; K.persistTask(t); } });
      K.refreshAll();
    });
  };

  /* Formulario de franja (nueva o editar). Una franja va dentro de un solo día. */
  const toMinutes = v => { if (!v) return null; const [a, b] = v.split(':').map(Number); return a * 60 + b; };
  function slotForm(s, isNew, close) {
    const weekly0 = K.isWeekly(s);
    /* Día de la franja: el suyo si es puntual, o el que se está viendo si es una rutina semanal */
    const dayOf = () => (s.repeat && s.repeat.date) || K.hoySel();
    let draftDays = weekly0 ? [...s.repeat.days] : [idxOf(s.repeat.date)];
    const draft = { ...s };
    const err = h('p', { class: 'form-err', role: 'alert' });
    const title = h('input', { class: 'fld-in', placeholder: 'Ej: Estudiar Física', value: draft.title || '', 'aria-label': 'Título', maxlength: '60' });
    const start = h('input', { class: 'fld-in', type: 'time', step: '600', value: K.hmIn(draft.start), 'aria-label': 'Hora de inicio' });
    const end = h('input', { class: 'fld-in', type: 'time', step: '600', value: K.hmIn(draft.end), 'aria-label': 'Hora de fin' });
    const colors = K.colorPicker(draft.color, id => { draft.color = id; });
    const fld = (label, control) => h('label', { class: 'fld' }, h('span', { class: 'fld-l' }, label), control);

    /* Se repite cada semana: se eligen los días. Si no, es solo el día de la franja. */
    const repeatBox = h('input', { type: 'checkbox', 'aria-label': 'Se repite cada semana' });
    repeatBox.checked = weekly0;
    const hint = h('p', { class: 'hint' });
    const days = K.dayToggles(draftDays, next => { draftDays = next; sync(); });
    const daysWrap = h('div', { class: 'fld' }, h('span', { class: 'fld-l' }, 'Días'), days);
    const sync = () => {
      daysWrap.hidden = !repeatBox.checked;
      hint.textContent = repeatBox.checked
        ? (draftDays.length ? `Se repite cada ${draftDays.map(i => DAY_LONG[i]).join(', ')}.` : 'Elegí los días en que se repite.')
        : `Solo el ${longDate(dayOf())}.`;
    };
    repeatBox.addEventListener('change', sync);
    sync();

    const save = () => {
      const a = toMinutes(start.value), b0 = toMinutes(end.value);
      if (a == null || b0 == null) { err.textContent = 'Completá el horario de inicio y de fin.'; return; }
      const b = b0 === 1439 ? 1440 : b0;                  // 23:59 cuenta como fin del día
      if (b <= a) { err.textContent = 'El fin tiene que ser posterior al inicio. Una franja no cruza la medianoche.'; return; }
      if (repeatBox.checked && !draftDays.length) { err.textContent = 'Elegí al menos un día.'; return; }
      const repeat = repeatBox.checked
        ? { type: 'weekly', days: [...draftDays].sort((x, y) => x - y) }
        : { type: 'once', date: dayOf() };
      Object.assign(s, { color: draft.color, title: title.value.trim().slice(0, 60) || 'Franja', start: a, end: b, repeat });
      if (isNew) K.state.blocks.push(s);
      K.saveSlot(s);
      close();
      K.refreshAll();
    };
    title.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });

    return [
      h('div', { class: 'sheet-head' }, h('h2', {}, isNew ? 'Nuevo bloque' : 'Editar bloque'),
        h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Cerrar', svg: icon('x', 18), onclick: close })),
      h('div', { class: 'form' },
        fld('Título', title),
        h('div', { class: 'row2' }, fld('Desde', start), fld('Hasta', end)),
        h('label', { class: 'fld-check' }, repeatBox, h('span', {}, ' Se repite cada semana')),
        daysWrap,
        hint,
        fld('Color', colors),
        err),
      h('div', { class: 'sheet-foot' },
        !isNew ? h('button', { type: 'button', class: 'btn quiet danger', onclick: () => { close(); K.removeSlot(s); } }, 'Eliminar') : h('span'),
        h('span', { class: 'grow' }),
        h('button', { type: 'button', class: 'btn', onclick: close }, 'Cancelar'),
        h('button', { type: 'button', class: 'btn primary', onclick: save }, 'Guardar')),
    ];
  }
  K.openSlot = s => K.modal(close => slotForm(s, false, close));
  /* Franja nueva en el día elegido: si es hoy, arranca en la próxima hora */
  K.newSlot = (ds, atMin) => {
    const nowM = new Date().getHours() * 60 + new Date().getMinutes();
    const start = atMin != null ? Math.min(1380, atMin) : ds === addDays(0) ? Math.min(1380, Math.ceil(nowM / 60) * 60) : 540;
    const s = { id: K.uid(), groupId: null, repeat: { type: 'once', date: ds }, title: '', start, end: Math.min(1440, start + 60),
      color: null, labels: [], notes: [], createdAt: Date.now(), updatedAt: Date.now(), rev: 0 };
    return K.modal(close => slotForm(s, true, close));
  };

  /* Empieza un enfoque con esta tarea. Si el temporizador está listo para Enfoque, arranca solo:
     un clic desde Hoy, sin pasar por la lista de objetivos. Si ya corre algo, solo cambia el objetivo. */
  K.startFocusOn = t => {
    K.setTarget({ kind: 'task', id: t.id, text: t.text, goalId: t.goalId || null });
    if (!K.pomoIsRunning() && K.pomo.mode === 'focus') K.pomoToggle();
    K.go({ name: 'focus' });
  };

  /* Los pendientes nuevos se asignan al día seleccionado en el encabezado. */
  const chipDue = () => K.hoySel();

  /* Celular o tablet táctil: Enter hace línea nueva (el teclado no tiene Shift) y se toca Agregar */
  const touchOnly = () => {
    try {
      return matchMedia('(pointer: coarse)').matches
        || (navigator.maxTouchPoints > 0 && matchMedia('(max-width: 860px)').matches);
    } catch { return false; }
  };

  function captureForm() {
    const touch = touchOnly();
    const input = h('textarea', {
      id: 'todayInput', class: 'cap-in', rows: '1', spellcheck: 'true',
      placeholder: '¿Qué tenés que hacer?',
      'aria-label': 'Pendientes, uno por línea', 'aria-describedby': 'todayInputHint', maxlength: '5000',
    });
    const hint = h('p', { id: 'todayInputHint', class: 'cap-hint' }, touch
      ? 'Una línea por pendiente. Tocá Agregar.'
      : ['Enter agrega · ', h('kbd', {}, 'Shift'), ' + Enter para varias líneas']);

    const itemsNow = () => K.parseCapture(input.value, chipDue());
    const preview = h('div', { class: 'cap-preview', 'aria-live': 'polite', hidden: true });

    const addBtn = h('button', { type: 'submit', class: 'btn primary cap-add' }, 'Agregar');

    /* Vista previa de varias líneas, para revisar antes de agregar */
    const showPreview = () => {
      const items = itemsNow();
      addBtn.textContent = items.length > 1 ? `Agregar ${Math.min(items.length, K.TASK_MAX)}` : 'Agregar';
      addBtn.disabled = !items.length;
      const show = items.length > 1;
      preview.hidden = !show;
      preview.replaceChildren();
      if (!show) return;
      const shown = items.slice(0, 8);
      preview.append(h('p', { class: 'cap-preview-h' },
        items.length === 1 ? 'Se va a crear 1 pendiente:' : `Se van a crear ${items.length} pendientes:`,
        items.length > K.TASK_MAX ? ` (se agregan los primeros ${K.TASK_MAX})` : ''));
      preview.append(h('ul', { class: 'cap-preview-list' }, shown.map(it => {
        const meta = [it.time || null, it.due ? K.dayLabel(it.due).toLowerCase() : 'sin fecha'].filter(Boolean).join(' · ');
        return h('li', {}, h('span', {}, it.text), h('small', {}, meta));
      })));
      if (items.length > shown.length) preview.append(h('p', { class: 'cap-preview-more' }, `y ${items.length - shown.length} más`));
    };

    /* El campo crece con el texto (hasta un tope) */
    const resize = () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 240) + 'px'; };
    input.addEventListener('input', () => { resize(); showPreview(); });

    const submit = () => {
      const items = itemsNow();
      if (!items.length) { input.focus(); return; }
      K.addTasks(items);
      K.toast(items.length === 1 ? 'Pendiente agregado' : `${Math.min(items.length, K.TASK_MAX)} pendientes agregados`);
      K.refreshAll();
      setTimeout(() => { const el = document.getElementById('todayInput'); if (el) el.focus(); }, 0);
    };
    input.addEventListener('keydown', e => {
      if (e.key !== 'Enter' || e.isComposing) return;
      /* Escritorio: Enter agrega; Shift+Enter, línea nueva. Táctil: Enter, línea nueva. Ctrl/⌘+Enter agrega siempre. */
      if (e.ctrlKey || e.metaKey || (!touch && !e.shiftKey)) { e.preventDefault(); submit(); }
    });
    showPreview();

    return h('form', { class: 'cap', onsubmit: e => { e.preventDefault(); submit(); } },
      h('div', { class: 'cap-main' }, input, addBtn),
      hint,
      preview);
  }

  /* La próxima tarea: vencidas o de hoy primero (por fecha, después por hora); si no hay, la rutina de hoy que falta */
  function nextUp() {
    const today = addDays(0);
    const due = K.todayTasks().filter(t => K.daysUntil(t.due) <= 0).sort(K.byDue)[0];
    if (due) return { t: due, ds: null, when: K.daysUntil(due.due) < 0 ? 'Vencida' : 'Para hoy' };
    const routine = K.routineOccurrences(today, today).find(x => !K.isDone(x.t, today));
    if (routine) return { t: routine.t, ds: today, when: 'Rutina de hoy' };
    return null;
  }

  function nextCard() {
    const n = nextUp();
    if (!n) {
      return h('section', { class: 'today-hero free' },
        h('div', { class: 'today-hero-body' },
          h('p', { class: 'today-hero-kicker' }, 'Hoy'),
          h('h2', { class: 'today-hero-title' }, 'Nada urgente para hoy'),
          h('p', { class: 'today-hero-sub' }, 'Anotá lo que sigue abajo, o empezá un enfoque libre.')),
        h('div', { class: 'today-hero-actions' },
          h('button', { class: 'btn', type: 'button', onclick: () => K.go({ name: 'focus' }) },
            h('span', { svg: icon('timer', 16) }), 'Ir a Foco')));
    }
    const { t, ds, when } = n;
    const goal = t.goalId ? K.goalById(t.goalId) : null;
    const b = K.routineBlock(t);
    const meta = [
      t.time ? t.time : null,
      goal ? goal.name : null,
      b ? K.blockLabel(b) : null,
    ].filter(Boolean);
    return h('section', { class: 'today-hero' },
      h('div', { class: 'today-hero-body' },
        h('p', { class: 'today-hero-kicker' }, 'Siguiente paso · ' + when),
        h('h2', { class: 'today-hero-title' }, t.text),
        meta.length ? h('p', { class: 'today-hero-sub' }, meta.join(' · ')) : null),
      h('div', { class: 'today-hero-actions' },
        h('button', { class: 'btn primary today-hero-go', type: 'button', onclick: () => K.startFocusOn(t) },
          h('span', { svg: icon('play', 16) }), 'Empezar enfoque'),
        h('button', { class: 'btn', type: 'button', onclick: () => K.toggleTask(t, ds) },
          h('span', { svg: icon('check', 16) }), 'Hecha')));
  }

  /* Una card. items: [{ t, ds }] (ds = día de la rutina, o null). opts.noDue oculta la fecha repetida dentro de la card del día. */
  function section(title, items, tone, opts = {}) {
    return h('section', { class: 'today-sec' + (tone ? ' ' + tone : '') },
      h('h2', { class: 'today-h' }, title, h('span', { class: 'today-n' }, String(items.length))),
      h('ul', { class: 'task-list' }, items.map(x => K.taskItem(x.t, { date: x.ds, noDue: !!opts.noDue }))));
  }

  /* Hechas: plegadas por defecto (no compiten con lo que falta). Restaurar, eliminar una, o vaciar todas */
  function doneSection(done) {
    return h('details', { class: 'today-done' },
      h('summary', {}, h('span', {}, 'Hechas'), h('span', { class: 'today-n' }, String(done.length))),
      h('div', { class: 'today-done-body' },
        h('ul', { class: 'task-list' }, done.sort((a, b) => (b.due || '').localeCompare(a.due || '')).map(t => K.taskItem(t))),
        h('button', { class: 'btn small', type: 'button', onclick: async () => {
          const n = K.allTasks().filter(t => t.done).length;
          if (!n) return;
          if (!(await K.ask({ title: '¿Eliminar las hechas?', danger: true, ok: 'Eliminar',
            text: `Se eliminan para siempre ${n === 1 ? 'una pendiente hecha' : n + ' pendientes hechos'}. No se puede deshacer.` }))) return;
          K.removeTasks(K.allTasks().filter(t => t.done));
        } }, 'Eliminar hechas')));
  }

  /* Dentro de un día: los pendientes sin hora primero, después por hora; a igual hora, por orden de alta */
  const byHourThen = (a, b) => (a.time || '').localeCompare(b.time || '') || (a.createdAt || 0) - (b.createdAt || 0);

  /* Lleva el cursor al campo de captura (N en Hoy, o el botón +) */
  K.focusCapture = () => {
    const el = document.getElementById('todayInput');
    if (!el) return;
    el.focus();
    el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  };

  /* Selector de fecha: se abre al tocar el nombre del día. */
  function chooseDay(D) {
    K.modal(close => {
      const date = h('input', { type: 'date', class: 'fld-in', value: D, 'aria-label': 'Elegir fecha' });
      const save = () => { if (date.value) K.hoyGo(date.value); close(); };
      date.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
      return [
        h('div', { class: 'sheet-head' }, h('h2', {}, 'Elegir día'),
          h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Cerrar', svg: icon('x', 18), onclick: close })),
        h('div', { class: 'form' }, h('label', { class: 'fld' }, h('span', { class: 'fld-l' }, 'Fecha'), date)),
        h('div', { class: 'sheet-foot' }, h('button', { type: 'button', class: 'btn', onclick: close }, 'Cancelar'),
          h('button', { type: 'button', class: 'btn primary', onclick: save }, 'Elegir')),
      ];
    });
  }

  /* Encabezado del día elegido: tocar la fecha para elegir otra; las flechas avanzan un día. */
  function dayBar(D) {
    const today = addDays(0);
    return h('div', { class: 'hoy-bar' },
      h('button', { type: 'button', class: 'hoy-mbtn', 'aria-label': 'Día anterior', onclick: () => K.hoyGo(shiftDay(D, -1)) }, '‹'),
      h('button', { type: 'button', class: 'hoy-bar-title hoy-date-trigger', 'aria-label': 'Elegir fecha', onclick: () => chooseDay(D) },
        h('h2', {}, D === today ? 'Hoy' : cap(K.dayLabel(D).split(' ')[0])),
        h('p', {}, cap(longDate(D)), h('span', { class: 'hoy-date-icon', svg: icon('calendar-days', 14) }))),
      h('button', { type: 'button', class: 'hoy-mbtn', 'aria-label': 'Día siguiente', onclick: () => K.hoyGo(shiftDay(D, 1)) }, '›'),
      D !== today ? h('button', { type: 'button', class: 'btn quiet small', onclick: () => K.hoyGo(today) }, 'Ir a hoy') : null,
      h('button', { type: 'button', class: 'btn small', onclick: () => K.newSlot(D) },
        h('span', { svg: icon('plus', 14) }), 'Bloque del día'));
  }

  /* ---------- Grilla del día: 24 horas, con una ventana de 8 h (4 antes y 4 después de ahora) ---------- */
  const HOUR_PX = 56;                 // alto de una hora en la grilla
  const WINDOW_H = 8;                 // horas visibles a la vez; el resto se ve deslizando

  /* Pendientes de un bloque en un día: los propios de ese día y los de rutina que le tocan */
  const blockTasks = (b, D) => K.allTasks()
    .filter(t => (t.blockId === b.id && t.due === D && !t.done)
      || (t.blockId === b.id && K.occursOn(t, D) && !K.isDone(t, D)))
    .sort(byHourThen);

  /* Pendientes con hora del día (los que van en la grilla) */
  const timedTasksOn = D => K.allTasks().filter(t => !t.done && t.due === D && t.time && !K.routineBlock(t));

  /* Pendientes sin hora del día, incluidos los de rutina que no están tildados ese día */
  const looseTasksOn = D => K.allTasks().filter(t => {
    if (K.routineBlock(t)) return K.occursOn(t, D) && !K.isDone(t, D);
    return !t.done && t.due === D && !t.time;
  }).sort((a, b) => (a.pos ?? 1e9) - (b.pos ?? 1e9) || byHourThen(a, b));

  /* Soltar un pendiente de la lista sobre la grilla: le asigna esa hora, redondeada a 15 minutos */
  function scheduleTaskAt(t, D, y) {
    const cur = K.taskById(t.id);
    const grid = document.querySelector('.tl');
    if (!cur || !grid) { K.refreshAll(); return; }
    const m = clampN(Math.round((y - grid.getBoundingClientRect().top) / HOUR_PX * 60 / 15) * 15, 0, 1425);
    if (K.routineBlock(cur)) { cur.blockId = null; cur.doneDays = {}; cur.done = false; cur.doneAt = null; }
    cur.due = D;
    cur.time = hhmm(m);
    cur.dur = cur.dur || 30;
    K.persistTask(cur);
    K.refreshAll();
  }

  /* Guarda el orden manual de una lista de pendientes (sus hijos, de arriba hacia abajo) */
  function saveOrder(cont) {
    [...cont.children].forEach((c, i) => {
      const t = c.dataset && c.dataset.taskId ? K.taskById(c.dataset.taskId) : null;
      if (t && t.pos !== i) { t.pos = i; K.persistTask(t); }
    });
  }

  /* Columnas para los elementos que se superponen, para que se vean todos */
  function laneLayout(items) {
    const sorted = [...items].sort((x, y) => x.start - y.start || y.end - x.end);
    const laneEnd = [];
    sorted.forEach(it => {
      let i = laneEnd.findIndex(end => it.start >= end);
      if (i < 0) { i = laneEnd.length; laneEnd.push(0); }
      laneEnd[i] = Math.max(it.end, it.start + 30);
      it.lane = i;
    });
    const n = Math.max(1, laneEnd.length);
    sorted.forEach(it => { it.lanes = n; });
    return sorted;
  }

  const clampN = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const hhmm = m => `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
  /* Tras mover o redimensionar, la grilla vuelve a dibujarse en el mismo lugar */
  let keepScrollTop = null;
  let justMoved = false;

  /* Mover (arrastrar el cuerpo; en celular, mantener apretado) o cambiar la duración (la agarradera de abajo).
     Paso de 15 minutos. Se guarda al soltar. */
  function attachGridGesture(el, it) {
    el.addEventListener('pointerdown', e => {
      if (e.button > 0) return;
      const grip = !!e.target.closest('.tl-grip');
      const touch = e.pointerType === 'touch';
      const startY = e.clientY;
      const s0 = it.start, e0 = it.end, len = e0 - s0;
      let moving = false, timer = 0, dm = 0;
      const apply = () => {
        if (grip) { it.start = s0; it.end = clampN(e0 + dm, s0 + 15, 1440); }
        else { it.start = clampN(s0 + dm, 0, 1440 - len); it.end = it.start + len; }
        el.style.top = it.start / 60 * HOUR_PX + 'px';
        el.style.height = Math.max(26, (it.end - it.start) / 60 * HOUR_PX - 2) + 'px';
      };
      const begin = () => { moving = true; el.classList.add('tl-moving'); };
      const onMove = ev => {
        if (!moving) {
          if (!grip && touch) { if (Math.abs(ev.clientY - startY) > 8) stop(); return; }   // en celular, el desplazamiento normal gana
          if (Math.abs(ev.clientY - startY) < 3) return;
          begin();
        }
        dm = Math.round((ev.clientY - startY) / (HOUR_PX / 60) / 15) * 15;
        apply();
      };
      const stop = () => {
        clearTimeout(timer);
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
        window.removeEventListener('pointercancel', stop);
      };
      const onUp = () => {
        stop();
        if (!moving) return;
        el.classList.remove('tl-moving');
        if (it.start === s0 && it.end === e0) return;             // no cambió nada: fue un toque normal
        justMoved = true; setTimeout(() => { justMoved = false; }, 0);
        keepScrollTop = el.closest('.tl-view') ? el.closest('.tl-view').scrollTop : null;
        if (it.kind === 'block') { const b = it.ref; b.start = it.start; b.end = it.end; K.saveBlock(b); }
        else { const t = K.taskById(it.ref.id); if (t) { t.time = hhmm(it.start); t.dur = it.end - it.start; K.persistTask(t); } }
        K.refreshAll();
      };
      if (touch && !grip) timer = setTimeout(begin, 350);
      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
      window.addEventListener('pointercancel', stop);
    });
  }

  /* Un elemento de la grilla: bloque (toca para editar, se mueve y se estira), pendiente con hora (toca para tildar,
     se mueve y se estira), evento (toca para editar) */
  function gridItem(it, D) {
    const top = it.start / 60 * HOUR_PX;
    const height = Math.max(26, (Math.max(it.end, it.start + 30) - it.start) / 60 * HOUR_PX - 2);
    const pos = `top:${top}px;height:${height}px;left:calc(${it.lane / it.lanes * 100}% + 2px);width:calc(${100 / it.lanes}% - 4px)`;
    const grip = h('span', { class: 'tl-grip', 'aria-hidden': 'true' });
    if (it.kind === 'block') {
      const b = it.ref;
      const hex = K.blockColor(b) ? K.blockColor(b).hex : null;
      const n = blockTasks(b, D).length;
      const el = h('button', { type: 'button', class: 'tl-item tl-block', style: pos + (hex ? `;--c:${hex}` : ''),
        'data-drop': 'block:' + b.id, onclick: e => { e.stopPropagation(); if (!justMoved) K.openSlot(b); } },
        h('b', {}, b.title || 'Bloque'),
        h('small', {}, `${K.hm(it.start)}–${K.hmIn(it.end)}${K.isWeekly(b) ? ' · semanal' : ''}${n ? ' · ' + n + ' pend.' : ''}`), grip);
      attachGridGesture(el, it);
      return el;
    }
    if (it.kind === 'task') {
      const t = it.ref;
      const el = h('button', { type: 'button', class: 'tl-item tl-task', style: pos,
        onclick: e => { e.stopPropagation(); if (!justMoved) K.toggleTask(t, D); } },
        h('b', {}, t.text || 'Pendiente'), h('small', {}, `${K.hm(it.start)}–${K.hmIn(it.end)}`), grip);
      attachGridGesture(el, it);
      return el;
    }
    const e = it.ref;
    return h('button', { type: 'button', class: 'tl-item tl-event', style: pos, onclick: ev => { ev.stopPropagation(); K.openEvent(e); } },
      h('b', {}, e.title || 'Evento'), h('small', {}, K.hm(e.time)));
  }

  /* Grilla de 24 horas del día D. Muestra una ventana de 8 h y se desliza para ver el resto */
  function timeline(D, blocks, tasks, events) {
    const today = addDays(0);
    const items = [
      ...blocks.map(b => ({ start: b.start, end: b.end, kind: 'block', ref: b })),
      ...tasks.map(t => { const m = toMinutes(t.time); return { start: m, end: m + (t.dur || 30), kind: 'task', ref: t }; }),
      ...events.map(e => ({ start: e.time, end: e.time + 30, kind: 'event', ref: e })),
    ];
    const lines = Array.from({ length: 24 }, (_, i) => h('div', { class: 'tl-line', style: `top:${i * HOUR_PX}px` },
      h('span', { class: 'tl-lbl' }, pad(i) + ':00')));
    const layer = h('div', { class: 'tl-layer' }, laneLayout(items).map(it => gridItem(it, D)));
    const nowM = new Date().getHours() * 60 + new Date().getMinutes();
    const nowLine = D === today ? h('div', { class: 'tl-now', style: `top:${nowM / 60 * HOUR_PX}px` }) : null;
    const grid = h('div', { class: 'tl', style: `height:${24 * HOUR_PX}px`, 'data-drop': 'grid' }, lines, layer, nowLine);
    /* Tocar un espacio libre crea un bloque en esa hora, redondeada a media hora */
    grid.addEventListener('click', e => {
      if (e.target.closest('.tl-item') || justMoved) return;
      const y = e.clientY - grid.getBoundingClientRect().top;
      const m = Math.min(1410, Math.max(0, Math.round(y / HOUR_PX * 60 / 30) * 30));
      K.newSlot(D, m);
    });
    const view = h('div', { class: 'tl-view', style: `height:${WINDOW_H * HOUR_PX}px` }, grid);
    /* Hoy: se abre 4 h antes de la hora actual. Otro día: desde las 7:00 */
    const startMin = D === today ? Math.max(0, nowM - 240) : 7 * 60;
    setTimeout(() => { view.scrollTop = keepScrollTop != null ? keepScrollTop : startMin / 60 * HOUR_PX; keepScrollTop = null; }, 0);
    return h('section', { class: 'tl-wrap', 'aria-label': 'Grilla del día' }, view);
  }

  /* El día elegido. En celular se desliza de costado para pasar al día siguiente o anterior. */
  let slideDir = 0;   // dirección del último deslizamiento (para la animación)
  function dayView(D) {
    const today = addDays(0);
    const dir = slideDir;
    slideDir = 0;
    const kids = [];
    if (D === today) {
      const overdue = K.allTasks().filter(t => !t.done && !K.routineBlock(t) && t.due && K.daysUntil(t.due) < 0).sort(K.byDue);
      if (overdue.length) kids.push(section('Vencidas', overdue.map(t => ({ t, ds: null })), 'overdue'));
    }
    const allDay = K.state.events.filter(e => e.date === D && e.time == null);
    if (allDay.length) {
      const items = allDay.map(e => h('button', { type: 'button', class: 'tl-item tl-event tl-allday-item', onclick: () => K.openEvent(e) },
        h('b', {}, e.title || 'Evento'), h('small', {}, 'Todo el día')));
      kids.push(h('section', { class: 'tl-allday' }, items));
    }
    kids.push(timeline(D, K.occurrencesOn(K.state.blocks, D), timedTasksOn(D),
      K.state.events.filter(e => e.date === D && e.time != null)));
    const loose = looseTasksOn(D);
    if (loose.length) {
      const looseCard = section('Pendientes del día', loose.map(t => ({ t, ds: K.routineBlock(t) ? D : null })), '', { noDue: true });
      looseCard.dataset.drop = 'none';
      kids.push(looseCard);
    }

    const wrap = h('div', { class: 'hoy-day wk-swipe' + (dir > 0 ? ' in-r' : dir < 0 ? ' in-l' : ''), 'data-drop': 'none' }, kids);
    if (K.isMobile()) {
      const go = d => { slideDir = d; K.hoyGo(shiftDay(D, d)); };
      K.swipe(wrap, {
        onMove: dx => {
          wrap.classList.remove('in-r', 'in-l');
          wrap.style.transition = 'none';
          wrap.style.transform = `translateX(${dx}px)`;
        },
        onEnd: (dx, vx) => {
          const commit = Math.abs(dx) > 70 || Math.abs(vx) > 0.45;
          if (commit && dx !== 0) return go(dx < 0 ? 1 : -1);      // dedo a la izquierda: día siguiente
          wrap.style.transition = 'transform .18s ease';
          wrap.style.transform = 'translateX(0)';
        },
      });
    }
    return wrap;
  }

  K.renderToday = root => {
    const D = K.hoySel();
    const undated = K.undatedTasks().sort(K.byDue);
    const done = K.allTasks().filter(t => t.done);

    root.append(nextCard(), dayBar(D), captureForm(), dayView(D));
    if (undated.length) root.append(section('Sin fecha', undated.map(t => ({ t, ds: null })), ''));
    if (done.length) root.append(doneSection(done));

    /* Arrastrar pendientes entre Sin franja y los bloques horarios. */
    root.querySelectorAll('.task-item[data-task-id]').forEach(el => {
      const t = K.taskById(el.dataset.taskId);
      if (!t || t.done || (!t.due && !K.routineBlock(t))) return;
      const cont = el.parentElement;
      K.attachDrag(el, t, {
        container: cont, reorder: true, item: '.task-item[data-task-id]', skip: 'button, a, input, textarea, select',
        accept: key => key === 'none' || key === 'grid' || key.startsWith('block:'),
        onDrop: (item, key, x, y) => (key === 'grid' ? scheduleTaskAt(item, D, y) : K.moveTaskInAgenda(item, key, D)),
        commit: () => saveOrder(cont),
      });
    });

    /* La tira de días muestra el día elegido sin mover la página */
    requestAnimationFrame(() => {
      const track = root.querySelector('.hoy-days');
      const sel = root.querySelector('.hoy-d[aria-pressed="true"]');
      if (track && sel) track.scrollLeft += sel.getBoundingClientRect().left - track.getBoundingClientRect().left - track.clientWidth / 2 + sel.offsetWidth / 2;
    });
  };
})();
