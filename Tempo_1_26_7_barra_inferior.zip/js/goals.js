/* =========================================================
   goals.js — Objetivos: el resultado que la persona quiere alcanzar (reemplaza a las materias).
   Un objetivo es un registro propio (colección "goals"). Sus proyectos, notas y recursos viven dentro de él:

     objetivo { id, name, description, category, archived, startDate, deadline, color,
                projects: [{ id, name, order, deadline }],
                resources: [{ id, projectId|null, kind:'note', noteId } | { id, projectId|null, kind:'link', title, url }],
                createdAt, updatedAt, rev }

   · category: academica | profesional | personal | otro (solo cambia el texto y el ícono; no impone campos).
   · archived: true oculta el objetivo de la lista principal (queda en "Archivados") y de las sugerencias de Foco.
     Hasta 1.24.0 existía un estado (activo, pausado, completado): se eliminó. Al leerlo, "completado" pasa a
     archivado y los demás quedan activos.
   · Pendientes: una tarea tiene goalId y projectId (null si es del objetivo en general). Sigue siendo un
     único registro: verla acá o en Pendientes es la misma tarea.
   · Recursos: notas o enlaces incorporados a mano. Nunca se vinculan solos ni cambian las etiquetas.
   · Un proyecto que se borra no borra nada: sus pendientes y recursos pasan al objetivo en general.
   · Duplicar un proyecto copia nombre, fecha, recursos y pendientes (sin fecha y sin tildar).
   · Un objetivo que se borra deja sus pendientes sin objetivo (y se puede deshacer).

   La pantalla está en goalsui.js.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  K.GOAL_CATS = [['academica', 'Académico'], ['profesional', 'Profesional'], ['personal', 'Personal'], ['otro', 'Otro']];
  const CAT_IDS = K.GOAL_CATS.map(x => x[0]);
  const NAME_MAX = 120;

  /* AAAA-MM-DD real (rechaza 2026-02-31) */
  K.isYmd = v => {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
    const [y, m, d] = v.split('-').map(Number);
    const dt = new Date(y, m - 1, d);
    return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
  };
  const ymdOrNull = v => (K.isYmd(v) ? v : null);

  const str = (v, max = 200) => (typeof v === 'string' ? v.slice(0, max) : '');
  const projectIdOf = v => (typeof v === 'string' && v ? v : null);
  const cleanResource = r => {
    if (!r || typeof r !== 'object' || typeof r.id !== 'string' || !r.id) return null;
    const projectId = projectIdOf(r.projectId);
    if (r.kind === 'note') return typeof r.noteId === 'string' && r.noteId ? { id: r.id, projectId, kind: 'note', noteId: r.noteId } : null;
    if (r.kind === 'link') {
      const url = K.safeUrl(r.url);
      return url ? { id: r.id, projectId, kind: 'link', title: str(r.title, 160) || url, url } : null;
    }
    return null;
  };
  /* Completa y limpia un objetivo (lo guardado o lo importado). Es idempotente. */
  K.normalizeGoal = g => {
    const projects = (Array.isArray(g.projects) ? g.projects : [])
      .filter(p => p && typeof p.id === 'string' && p.id)
      .map((p, i) => ({
        id: p.id, name: str(p.name, NAME_MAX).trim() || 'Proyecto',
        order: Number.isFinite(p.order) ? p.order : i,
        deadline: ymdOrNull(p.deadline),
      }));
    const ids = new Set(projects.map(p => p.id));
    /* Un bloque de un proyecto que ya no existe pasa al objetivo en general */
    const inBlock = r => (r.projectId && !ids.has(r.projectId) ? { ...r, projectId: null } : r);
    const resources = (Array.isArray(g.resources) ? g.resources : []).map(cleanResource).filter(Boolean).map(inBlock);
    /* Migración: el estado se reemplazó por "archivado" (completado → archivado; activo y pausado → activos) */
    const archived = typeof g.archived === 'boolean' ? g.archived : g.status === 'completado';
    const out = {
      ...g,
      id: typeof g.id === 'string' && g.id ? g.id : K.uid(),
      name: str(g.name, NAME_MAX).trim() || 'Sin nombre',
      description: str(g.description, 2000),
      category: CAT_IDS.includes(g.category) ? g.category : 'otro',
      archived,
      startDate: ymdOrNull(g.startDate),
      deadline: ymdOrNull(g.deadline),
      color: typeof g.color === 'string' ? g.color : null,
      projects, resources,
      createdAt: Number.isFinite(g.createdAt) ? g.createdAt : Date.now(),
      updatedAt: Number.isFinite(g.updatedAt) ? g.updatedAt : Date.now(),
      rev: Number.isFinite(g.rev) ? g.rev : 0,
    };
    delete out.status;
    delete out.notes;          // notas en bloque: se quitaron en 1.24.2
    return out;
  };

  /* ---------- Consultas ---------- */
  K.goalById = id => (id && K.state.goals.find(g => g.id === id)) || null;
  K.goalCat = id => (K.GOAL_CATS.find(c => c[0] === id) || [null, 'Otro'])[1];
  K.goalProjects = g => g.projects.slice().sort((a, b) => a.order - b.order);
  /* Proyecto por id (los ids son únicos en toda la app): { goal, project } o null */
  K.findProject = pid => {
    if (!pid) return null;
    for (const goal of K.state.goals) {
      const project = goal.projects.find(p => p.id === pid);
      if (project) return { goal, project };
    }
    return null;
  };
  K.goalTasks = g => K.allTasks().filter(t => t.goalId === g.id);
  /* Avance: solo pendientes sueltos (las rutinas se cumplen día por día y no entran en el porcentaje) */
  K.goalProgress = g => {
    const singles = K.goalTasks(g).filter(t => !K.routineBlock(t));
    return { done: singles.filter(t => t.done).length, total: singles.length };
  };
  /* Próximo vencimiento: el pendiente abierto con fecha más cercana (o null) */
  K.goalNextDue = g => {
    const open = K.goalTasks(g).filter(t => !t.done && t.due && !K.routineBlock(t));
    return open.sort((a, b) => a.due.localeCompare(b.due))[0] || null;
  };
  K.projectTasks = (g, pid) => K.goalTasks(g).filter(t => (t.projectId || null) === (pid || null));
  K.projectResources = (g, pid) => g.resources.filter(r => (r.projectId || null) === (pid || null));

  /* ---------- Altas, cambios y borrados ---------- */
  K.persistGoal = g => { g.updatedAt = Date.now(); return K.run(K.api.saveGoal(g)); };

  K.createGoal = (over = {}) => {
    const g = K.normalizeGoal({ id: K.uid(), name: over.name || 'Nuevo objetivo', category: over.category || 'otro',
      description: over.description || '', startDate: over.startDate || null, deadline: over.deadline || null,
      archived: false, projects: [], resources: [], createdAt: Date.now(), updatedAt: Date.now(), rev: 0 });
    K.state.goals.push(g);
    K.run(K.api.saveGoal(g));
    return g;
  };

  /* Cambios de campos del objetivo (nombre, ámbito, archivado, descripción, fechas) */
  K.updateGoal = (g, patch) => {
    const cur = K.goalById(g.id);
    if (!cur) return;
    Object.assign(cur, K.normalizeGoal({ ...cur, ...patch }));
    K.persistGoal(cur);
    K.refreshAll();
  };

  /* Borrado con deshacer: los pendientes quedan sueltos, y el deshacer los devuelve a su lugar */
  K.removeGoal = g => {
    const cur = K.goalById(g.id);
    if (!cur) { K.refreshAll(); return; }
    const snapGoal = JSON.parse(JSON.stringify(cur));
    const snapTasks = K.goalTasks(cur).map(t => ({ id: t.id, goalId: t.goalId, projectId: t.projectId || null }));
    snapTasks.forEach(s => { const t = K.taskById(s.id); if (t) { t.goalId = null; t.projectId = null; K.persistTask(t); } });
    K.state.goals = K.state.goals.filter(x => x.id !== cur.id);
    K.run(K.api.deleteGoal(cur.id));
    K.refreshAll();
    K.toast('Objetivo eliminado', () => {
      const back = K.normalizeGoal(snapGoal);
      K.state.goals.push(back); K.run(K.api.saveGoal(back));
      snapTasks.forEach(s => { const t = K.taskById(s.id); if (t) { t.goalId = s.goalId; t.projectId = s.projectId; K.persistTask(t); } });
      K.refreshAll();
    });
  };

  /* ---------- Proyectos ---------- */
  K.addProject = (g, name, deadline = null) => {
    const cur = K.goalById(g.id);
    const clean = str(name, NAME_MAX).trim();
    if (!cur || !clean) return null;
    const order = cur.projects.reduce((m, p) => Math.max(m, p.order), -1) + 1;
    const p = { id: K.uid(), name: clean, order, deadline: ymdOrNull(deadline) };
    cur.projects.push(p);
    K.persistGoal(cur); K.refreshAll();
    return p;
  };
  K.updateProject = (g, pid, patch) => {
    const cur = K.goalById(g.id);
    const p = cur && cur.projects.find(x => x.id === pid);
    if (!p) return;
    if (typeof patch.name === 'string' && patch.name.trim()) p.name = str(patch.name, NAME_MAX).trim();
    if ('deadline' in patch) p.deadline = ymdOrNull(patch.deadline);
    K.persistGoal(cur); K.refreshAll();
  };
  /* Sube (dir -1) o baja (dir 1) un proyecto. Reasigna el orden: 0, 1, 2… sin huecos */
  K.moveProject = (g, pid, dir) => {
    const cur = K.goalById(g.id);
    if (!cur) return;
    const list = K.goalProjects(cur);
    const i = list.findIndex(p => p.id === pid);
    const j = i + (dir < 0 ? -1 : 1);
    if (i < 0 || j < 0 || j >= list.length) return;
    [list[i], list[j]] = [list[j], list[i]];
    list.forEach((p, k) => { p.order = k; });
    K.persistGoal(cur); K.refreshAll();
  };
  /* Duplica un proyecto justo debajo del original. Copia su fecha, recursos y pendientes:
     los pendientes vuelven sin tildar y sin fecha (una copia nueva no hereda los vencimientos). Las rutinas no se copian.
     Devuelve el proyecto nuevo (o null). */
  K.duplicateProject = (g, pid) => {
    const cur = K.goalById(g.id);
    const src = cur && cur.projects.find(p => p.id === pid);
    if (!src) return null;
    const copy = { id: K.uid(), name: str(src.name + ' (copia)', NAME_MAX), order: 0, deadline: src.deadline };
    const list = K.goalProjects(cur);
    list.splice(list.indexOf(src) + 1, 0, copy);
    list.forEach((p, k) => { p.order = k; });
    cur.projects = list;
    cur.resources.filter(r => (r.projectId || null) === pid).forEach(r => cur.resources.push({ ...r, id: K.uid(), projectId: copy.id }));
    const sources = K.projectTasks(cur, pid).filter(t => !K.routineBlock(t));
    const made = K.addTasks(sources.map(t => ({ text: t.text, due: null })), { goalId: cur.id, projectId: copy.id });
    made.forEach((t, i) => { t.labels = (sources[i].labels || []).slice(); K.persistTask(t); });
    K.persistGoal(cur); K.refreshAll();
    return copy;
  };
  /* Quitar un proyecto: sus pendientes y recursos pasan al objetivo en general (no se pierde nada) */
  K.removeProject = (g, pid) => {
    const cur = K.goalById(g.id);
    if (!cur) return;
    K.allTasks().filter(t => t.projectId === pid).forEach(t => { t.projectId = null; K.persistTask(t); });
    cur.resources.forEach(r => { if (r.projectId === pid) r.projectId = null; });
    cur.projects = cur.projects.filter(p => p.id !== pid);
    K.persistGoal(cur); K.refreshAll();
  };

  /* Vincula (o desvincula, con null) un pendiente a un objetivo y a uno de sus proyectos */
  K.setTaskGoal = (t, goalId, projectId = null) => {
    const cur = K.taskById(t.id);
    if (!cur) { K.refreshAll(); return; }
    const g = K.goalById(goalId);
    cur.goalId = g ? g.id : null;
    cur.projectId = g && projectId && g.projects.some(p => p.id === projectId) ? projectId : null;
    K.persistTask(cur);
    K.refreshAll();
  };

  /* ---------- Recursos: notas y enlaces que la persona agrega a mano ---------- */
  K.addResourceNote = (g, projectId, noteId) => {
    const cur = K.goalById(g.id);
    if (!cur || !K.noteById(noteId)) return;
    if (cur.resources.some(r => r.kind === 'note' && r.noteId === noteId && (r.projectId || null) === (projectId || null))) return;
    cur.resources.push({ id: K.uid(), projectId: projectId || null, kind: 'note', noteId });
    K.persistGoal(cur); K.refreshAll();
  };
  K.addResourceLink = (g, projectId, title, url) => {
    const cur = K.goalById(g.id);
    const safe = K.safeUrl(url);
    if (!cur || !safe) return false;
    cur.resources.push({ id: K.uid(), projectId: projectId || null, kind: 'link', title: str(title, 160).trim() || safe, url: safe });
    K.persistGoal(cur); K.refreshAll();
    return true;
  };
  K.removeResource = (g, rid) => {
    const cur = K.goalById(g.id);
    if (!cur) return;
    cur.resources = cur.resources.filter(r => r.id !== rid);
    K.persistGoal(cur); K.refreshAll();
  };

  /* Foco con el objetivo o un proyecto como destino (las métricas los atribuyen por su id) */
  K.focusOnGoal = g => { K.setTarget({ kind: 'goal', id: g.id, text: g.name }); K.go({ name: 'focus' }); };
  K.focusOnProject = (g, p) => { K.setTarget({ kind: 'project', id: p.id, goalId: g.id, text: p.name }); K.go({ name: 'focus' }); };

  /* Objetivo al que pertenece un destino de Foco (o null). Lo usan las métricas. */
  K.goalOfTarget = target => {
    if (!target) return null;
    if (target.kind === 'goal') return K.goalById(target.id) ? target.id : null;
    if (target.kind === 'project') { const f = K.findProject(target.id); return f ? f.goal.id : (target.goalId || null); }
    if (target.kind === 'task') {
      const t = K.taskById(target.id);
      const gid = (t && t.goalId) || target.goalId || null;
      return gid && K.goalById(gid) ? gid : null;
    }
    return null;
  };
})();
