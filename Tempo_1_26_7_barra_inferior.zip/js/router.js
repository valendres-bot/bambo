/* =========================================================
   router.js — rutas por hash:
   #/ (vacío) o #/today  → Hoy (inicio: lo que hay que hacer y el foco del día)
   #/notas  (Notas)   #/label/ID   #/archive   #/trash
   #/goals (Objetivos)   #/goal/ID (un objetivo)
   #/calendar  (Rutina semanal)   #/calendar/events  (Próximos eventos)
   #/focus   #/metrics   #/settings
   Las rutas viejas siguen funcionando: #/none → Notas, #/events → Calendario, #/ → Hoy.
   1.25.1.3: el inicio pasó de Notas a Hoy. Notas vive en #/notas.
   Las notas se abren en su pantalla, no son una ruta.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  const SIMPLE = ['archive', 'trash', 'today', 'goals', 'focus', 'metrics', 'settings'];

  K.parseRoute = () => {
    const [a, b] = location.hash.replace(/^#\/?/, '').split('/');
    if ((a === 'label' || a === 'folder') && b) return { name: 'label', id: decodeURIComponent(b) };  // "folder" = enlaces viejos
    if (a === 'goal' && b) return { name: 'goal', id: decodeURIComponent(b) };
    if (a === 'calendar' || a === 'schedule' || a === 'events') return { name: 'today' };   // Calendario se quitó: enlaces viejos a Hoy
    if (a === 'notas' || a === 'none') return { name: 'all' };
    if (!a || a === 'hoy') return { name: 'today' };        // inicio
    return SIMPLE.includes(a) ? { name: a } : { name: 'today' };
  };
  K.hashFor = r => {
    if (r.name === 'all') return '#/notas';
    return r.id ? `#/${r.name}/${encodeURIComponent(r.id)}` : `#/${r.name}`;
  };
  /* Cambiar de sección no agrega entradas al historial: el "atrás" del celular no recorre cada sección visitada.
     (Las notas y el editor sí usan el historial, para cerrarse con "atrás".) */
  K.navigate = hash => {
    const leftover = !!(history.state && history.state.keepEditor);   // entrada de una nota que se acaba de cerrar
    if (location.hash === hash && !leftover) return;
    history.replaceState(null, '', hash);
    K.onRoute();
  };
  K.go = r => K.navigate(K.hashFor(r));
  document.addEventListener('click', e => {
    const a = e.target && e.target.closest && e.target.closest('a[href^="#/"]');
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    K.navigate(a.getAttribute('href'));
  }, true);
  K.sameRoute = (a, b) => a.name === b.name && a.id === b.id;

  K.routeInfo = r => {
    switch (r.name) {
      case 'label': {
        const l = K.labelById(r.id);
        return l ? { title: l.name, icon: K.labelIcon(l) } : { title: 'Etiqueta no encontrada', icon: 'tag' };
      }
      case 'archive': return { title: 'Archivo', icon: 'archive' };
      case 'trash': return { title: 'Papelera', icon: 'trash' };
      case 'focus': return { title: 'Foco', icon: 'timer' };
      case 'metrics': return { title: 'Métricas', icon: 'chart' };
      case 'today': return { title: 'Hoy', icon: 'checklist' };
      case 'goals': return { title: 'Objetivos', icon: 'target' };
      case 'goal': { const g = K.goalById(r.id); return g ? { title: g.name, icon: 'target' } : { title: 'Objetivo no encontrado', icon: 'target' }; }
      case 'settings': return { title: 'Configuración', icon: 'gear' };
      default: return { title: 'Notas', icon: 'file' };
    }
  };

  /* Vistas que muestran notas (y por lo tanto buscador, orden y crear nota) */
  K.isNotesRoute = r => ['all', 'label', 'archive', 'trash'].includes(r.name);
  K.canCreate = r => ['all', 'label'].includes(r.name);
  K.defaultsForRoute = () => {
    const r = K.state.route;
    return r.name === 'label' && K.labelById(r.id) ? { labels: [r.id] } : {};
  };

  K.onRoute = () => {
    K.closePop();
    const st = K.state;
    let r = K.parseRoute();
    if (r.name === 'label' && !K.labelById(r.id)) { r = { name: 'all' }; history.replaceState(null, '', '#/notas'); }
    if (r.name === 'goal' && !K.goalById(r.id)) { r = { name: 'goals' }; history.replaceState(null, '', '#/goals'); }
    st.route = r;
    st.query = '';
    document.body.classList.toggle('no-create', !(K.canCreate(r) || r.name === 'today'));   // el (+) va donde se anota: notas y Hoy
    document.body.classList.remove('nav-open');
    K.refreshAll();
    document.documentElement.scrollTop = 0;
  };
})();
