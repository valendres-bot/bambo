/* =========================================================
   editor.js — la ventana de edición de una nota.
   · Encabezado: estado de guardado, fijar, menú ⋯ y "Listo".
   · Título grande, etiquetas y el texto. (Las cards de enlaces son de las etiquetas, no de las notas.)
   · El texto se edita directo (richedit.js / richinput.js): sin comandos.
     Se da formato con la barra, con la barra flotante al seleccionar
     texto, con el clic derecho o con atajos (Ctrl+B, Ctrl+I, Ctrl+K).
   · openEditor(): pantalla de la nota; Esc o "Listo" guarda y cierra.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon, iconBtn, fit } = K;

  /* ---------- Resolución de nombres (para [[Nombre]] y las cards) ---------- */
  K.resolveRef = name => {
    const key = K.norm(String(name).trim());
    if (!key) return null;
    const n = K.state.notes.find(x => K.isLive(x) && K.norm(x.title.trim()) === key);
    if (n) return { kind: 'note', item: n };
    const l = K.state.labels.find(x => !x.archived && K.norm(x.name) === key);
    return l ? { kind: 'label', item: l } : null;
  };
  /* Cierra la nota abierta (si hay) SIN volver atrás en el historial: su entrada la reutiliza lo que sigue
     (otra nota o una ruta, que usan replaceState). Así no queda una entrada huérfana ni llega un popstate tardío.
     Devuelve true si había una nota abierta. */
  K.releaseEditor = () => {
    const open = !!K.state.editor;
    if (open) K.state.editor.close(true);
    return open;
  };
  K.openRef = ref => {
    if (!ref) return;
    const swap = K.releaseEditor();
    if (ref.kind === 'note') K.openEditor(ref.item, { reuseEntry: swap });
    else K.go({ name: 'label', id: ref.item.id });
  };

  /* Menú anclado a un punto (clic derecho) */
  let ctxAnchor = null;
  function popAt(x, y, content, w = 1, hgt = 1) {
    if (ctxAnchor) ctxAnchor.remove();
    ctxAnchor = h('div', { style: `position:fixed;left:${x}px;top:${y}px;width:${w}px;height:${hgt}px;pointer-events:none` });
    document.body.append(ctxAnchor);
    return K.openPop(ctxAnchor, content);
  }

  /* Resalta un rango mientras el foco está en otra caja (selector de enlaces) */
  const hl = {
    set(r) { try { if (window.CSS && CSS.highlights && window.Highlight) CSS.highlights.set('ed-sel', new Highlight(r)); } catch { /* sin soporte */ } },
    clear() { try { if (window.CSS && CSS.highlights) CSS.highlights.delete('ed-sel'); } catch { /* sin soporte */ } },
  };

  /* opts: { isDraft(): bool, autofocus, onChange, onClose, onArchive, onTrash } */
  K.buildEditor = (note, opts = {}) => {
    const draft = () => (typeof opts.isDraft === 'function' ? opts.isDraft() : !!opts.isDraft);
    const root = h('div', { class: 'editor' });
    const changed = () => { if (opts.onChange) opts.onChange(); };
    /* Cambios de banderas (fijar, etiquetas…): se guardan al instante si la nota ya existe */
    const flags = () => { refresh(); if (draft()) changed(); else { K.save(note); K.refresh(); } };

    /* ---------- Encabezado ---------- */
    const status = h('span', { class: 'ed-status', 'aria-live': 'polite' });
    const pinBtn = iconBtn('pin', 'Fijar nota', () => { note.pinned = !note.pinned; if (note.pinned) note.archived = false; flags(); }, 'ed-pin');
    const moreBtn = iconBtn('more', 'Más opciones', () => K.togglePop(moreBtn, () => K.menu([
      { label: note.archived ? 'Desarchivar' : 'Archivar', icon: note.archived ? 'unarchive' : 'archive', run: () => {
        if (opts.onArchive) opts.onArchive(); else { note.archived = !note.archived; if (note.archived) note.pinned = false; flags(); } } },
      { label: 'Exportar como Markdown', icon: 'download', run: () => K.exportNoteMD(note) },
      ...(opts.onTrash ? [{ label: 'Enviar a la papelera', icon: 'trash', run: opts.onTrash }] : []),
    ])));
    const doneBtn = h('button', { class: 'ed-done', type: 'button', 'aria-label': 'Cerrar nota; los cambios se guardan automáticamente', onclick: () => opts.onClose && opts.onClose() }, 'Cerrar');
    const head = h('div', { class: 'ed-top' }, status, h('span', { class: 'grow' }), pinBtn, moreBtn, doneBtn);

    /* ---------- Título ---------- */
    const title = h('textarea', { class: 'ed-title', rows: '1', placeholder: 'Título (opcional)', 'aria-label': 'Título de la nota', spellcheck: 'true' });
    title.value = note.title;
    title.addEventListener('input', () => { note.title = title.value.replace(/\n/g, ' '); fit(title); changed(); });
    title.addEventListener('keydown', e => {
      if ((e.key === 'Enter' && !e.isComposing) || (e.key === 'ArrowDown' && title.selectionStart === title.value.length)) {
        e.preventDefault(); doc.focus({ preventScroll: true }); api.caretTo(api.blocks()[0], false);
      }
    });

    /* ---------- Etiquetas, fecha y vínculos ---------- */
    const chips = h('div', { class: 'ed-chips' });
    const addPill = h('button', { class: 'pill', type: 'button', onclick: () => K.togglePop(addPill, () =>
      K.labelPicker(note, addPill, () => { flags(); drawChips(); })) },
    h('span', { svg: icon('plus', 14) }), 'Etiqueta');
    function drawChips() {
      chips.replaceChildren(
        ...K.labelsOf(note).filter(l => !l.archived).map(l => h('span', { class: 'pill on' }, K.dot(l), l.name,
          h('button', { type: 'button', class: 'pill-x', 'aria-label': 'Quitar etiqueta ' + l.name, svg: icon('x', 13),
            onclick: () => { K.toggleNoteLabel(note, l.id); flags(); drawChips(); } }))),
        addPill);
    }
    /* ---------- Texto ---------- */
    const doc = h('div', {
      class: 'ed-doc', contenteditable: 'true', role: 'textbox', 'aria-multiline': 'true', 'aria-label': 'Contenido de la nota',
      'data-placeholder': 'Escribí lo que quieras recordar…', spellcheck: 'true',
    });
    const api = K.richDoc(doc, {
      onChange: () => { note.body = api.getBody(); changed(); refreshBar(); },
      onSelect: () => refreshBar(),
    });
    api.setBody(note.body);
    api.resetHistory();

    /* ---------- Acciones de formato (las usan barra, menú y barra flotante) ---------- */
    const doFormat = n => () => { doc.focus({ preventScroll: true }); api.toggleFormat(n); };
    const doKind = k => () => { doc.focus({ preventScroll: true }); api.setKind(k); };

    function openLink(anchor) {
      let r = api.getRange();
      if (!r) { api.focusEnd(); r = api.getRange(); }
      const range = r.cloneRange();
      hl.set(range);
      const picker = K.linkSearch({
        exclude: note.id,
        placeholder: 'Pegá un enlace o buscá una nota o etiqueta',
        onPick: (res, t) => {
          hl.clear(); doc.focus({ preventScroll: true });
          if (res.url) api.applyLink(range, res.url); else api.insertRef(range, res.name);
        },
      });
      if (anchor) K.openPop(anchor, picker);
      else {
        const rc = range.getBoundingClientRect();
        popAt(rc.left, rc.bottom || rc.top, picker, Math.max(1, rc.width), 1);
      }
    }

    /* Clic en un enlace del texto: abrir, editar, card o quitar */
    function linkPop(a) {
      const url = a.dataset.url;
      const view = h('div', { class: 'lp-linkview' },
        h('span', { class: 'lp-url', title: url }, url),
        h('div', { class: 'lp-btns' },
          h('a', { class: 'icon-btn', href: url, target: '_blank', rel: 'noopener noreferrer', title: 'Abrir', 'aria-label': 'Abrir', svg: icon('external', 16), onclick: () => K.closePop() }),
          iconBtn('edit', 'Editar dirección', () => {
            const inp = h('input', { class: 'lp-input', value: url, spellcheck: 'false', 'aria-label': 'Dirección' });
            const ok = () => { const nu = K.normUrl(inp.value); if (!nu) { inp.focus(); return; } a.dataset.url = nu; a.href = nu; K.closePop(); doc.focus({ preventScroll: true }); api.commit(false); };
            inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); ok(); } });
            K.openPop(a, h('div', { class: 'lp-link' }, inp, h('div', { class: 'lp-acts' }, h('button', { class: 'btn', type: 'button', onclick: ok }, 'Guardar'))));
            setTimeout(() => { inp.focus(); inp.select(); }, 0);
          }),
          iconBtn('unlink', 'Quitar enlace', () => { K.closePop(); api.removeLink(a); })));
      K.openPop(a, view);
    }

    K.richInput(api, {
      onSelect: () => refreshBar(),
      onLinkKey: () => openLink(),
      onLink: linkPop,
      onRef: (name) => { const ref = K.resolveRef(name); if (ref) K.openRef(ref); else K.toast(`No hay ninguna nota ni etiqueta llamada “${name}”`); },
    });

    /* ---------- Clic derecho ---------- */
    doc.addEventListener('contextmenu', e => {
      if (K.isTouch()) return;                           // en el celular queda el menú del sistema
      e.preventDefault();
      const r0 = api.getRange();
      const saved = r0 ? r0.cloneRange() : null;
      const st = api.state();
      const act = fn => () => { doc.focus({ preventScroll: true }); if (saved) api.setRange(saved); fn(); };
      const hasSel = !!(saved && !saved.collapsed);
      const items = [
        { label: 'Negrita', icon: 'bold', checked: st.strong, run: act(() => api.toggleFormat('strong')) },
        { label: 'Cursiva', icon: 'italic', checked: st.em, run: act(() => api.toggleFormat('em')) },
        { label: 'Resaltar', icon: 'highlight', checked: st.mark, run: act(() => api.toggleFormat('mark')) },
        '-',
        { label: 'Subtítulo', icon: 'heading', checked: st.kind === 'h', run: act(() => api.setKind('h')) },
        { label: 'Lista con viñetas', icon: 'list', checked: st.kind === 'b', run: act(() => api.setKind('b')) },
        '-',
        { label: 'Enlazar…', icon: 'link', run: act(() => openLink()) },
        ...(hasSel ? ['-',
          { label: 'Cortar', icon: 'cut', run: act(() => document.execCommand('cut')) },
          { label: 'Copiar', icon: 'copy', run: act(() => document.execCommand('copy')) }] : ['-']),
        { label: 'Pegar', icon: 'paste', run: act(() => {
          if (!navigator.clipboard || !navigator.clipboard.readText) { K.toast('Usá Ctrl+V para pegar'); return; }
          navigator.clipboard.readText().then(t => { doc.focus({ preventScroll: true }); if (saved) api.setRange(saved); api.insertMarkup(t.replace(/\r\n?/g, '\n')); }).catch(() => K.toast('Usá Ctrl+V para pegar'));
        }) },
      ];
      popAt(e.clientX, e.clientY, K.menu(items));
    });

    /* ---------- Barra de formato ---------- */
    const mk = (ic, label, hint, run) => {
      const b = iconBtn(ic, hint ? `${label} (${hint})` : label, run, 'fmt-btn');
      b.addEventListener('mousedown', e => e.preventDefault());       // no le roba la selección al texto
      return b;
    };
    const B = {
      undo: mk('undo', 'Deshacer', 'Ctrl+Z', () => { doc.focus({ preventScroll: true }); api.undo(); }),
      redo: mk('redo', 'Rehacer', 'Ctrl+Y', () => { doc.focus({ preventScroll: true }); api.redo(); }),
      strong: mk('bold', 'Negrita', 'Ctrl+B', doFormat('strong')),
      em: mk('italic', 'Cursiva', 'Ctrl+I', doFormat('em')),
      mark: mk('highlight', 'Resaltar', 'Ctrl+Shift+H', doFormat('mark')),
      h: mk('heading', 'Subtítulo', '', doKind('h')),
      b: mk('list', 'Lista con viñetas', '', doKind('b')),
      link: mk('link', 'Enlazar a una dirección, nota o etiqueta', 'Ctrl+K', () => openLink(B.link)),
    };
    const sep = () => h('span', { class: 'fmt-sep' });
    const fmt = h('div', { class: 'ed-fmt', role: 'toolbar', 'aria-label': 'Formato' },
      B.undo, B.redo, sep(), B.strong, B.em, B.mark, sep(), B.h, B.b, sep(), B.link);

    /* ---------- Barra flotante al seleccionar texto ---------- */
    const fl = {
      strong: mk('bold', 'Negrita', 'Ctrl+B', doFormat('strong')),
      em: mk('italic', 'Cursiva', 'Ctrl+I', doFormat('em')),
      mark: mk('highlight', 'Resaltar', '', doFormat('mark')),
      link: mk('link', 'Enlazar', 'Ctrl+K', () => openLink()),
      h: mk('heading', 'Subtítulo', '', doKind('h')),
    };
    const selBar = h('div', { class: 'sel-bar', role: 'toolbar', 'aria-label': 'Formato del texto seleccionado', hidden: true },
      fl.strong, fl.em, fl.mark, h('span', { class: 'fmt-sep' }), fl.link, fl.h);
    let mouseDown = false;
    doc.addEventListener('mousedown', () => { mouseDown = true; selBar.hidden = true; });
    const onMouseUp = () => { if (mouseDown) { mouseDown = false; setTimeout(refreshBar, 0); } };
    document.addEventListener('mouseup', onMouseUp);

    function placeSelBar() {
      const r = api.getRange();
      if (K.isTouch() || mouseDown || !r || r.collapsed || K.hasPop() || !root.isConnected) { selBar.hidden = true; return; }
      const rc = r.getBoundingClientRect();
      if (!rc.width && !rc.height) { selBar.hidden = true; return; }
      selBar.hidden = false;
      const w = selBar.offsetWidth, hh = selBar.offsetHeight;
      let top = rc.top - hh - 8;
      if (top < 8) top = rc.bottom + 8;
      const left = Math.max(8, Math.min(rc.left + rc.width / 2 - w / 2, innerWidth - w - 8));
      selBar.style.left = left + 'px'; selBar.style.top = top + 'px';
    }

    function refreshBar() {
      const st = api.state();
      const on = (b, v) => { b.classList.toggle('on', !!v); b.setAttribute('aria-pressed', String(!!v)); };
      on(B.strong, st.strong); on(B.em, st.em); on(B.mark, st.mark);
      on(B.h, st.kind === 'h'); on(B.b, st.kind === 'b');
      on(fl.strong, st.strong); on(fl.em, st.em); on(fl.mark, st.mark); on(fl.h, st.kind === 'h');
      B.undo.disabled = !api.canUndo(); B.redo.disabled = !api.canRedo();
      if (!K.hasPop()) hl.clear();
      placeSelBar();
    }
    const scroller = h('div', { class: 'ed-scroll' });
    scroller.addEventListener('scroll', () => { if (!selBar.hidden) placeSelBar(); }, { passive: true });
    window.addEventListener('resize', placeSelBar);

    /* ---------- Atajos de la ventana ---------- */
    root.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        e.preventDefault(); e.stopPropagation();
        if (K.hasPop()) { K.closePop(); doc.focus({ preventScroll: true }); return; }
        if (!selBar.hidden) { selBar.hidden = true; return; }
        if (opts.onClose) opts.onClose();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault(); e.stopPropagation();
        if (opts.onClose) opts.onClose();
      }
    });

    /* ---------- Armado ---------- */
    scroller.append(h('div', { class: 'ed-page' }, title, h('div', { class: 'ed-meta' }, chips), doc));
    root.append(head, fmt, scroller, selBar);

    function refresh() {
      pinBtn.classList.toggle('on', note.pinned);
      pinBtn.title = note.pinned ? 'Desfijar' : 'Fijar nota';
      pinBtn.setAttribute('aria-label', pinBtn.title);
      drawChips(); refreshBar();
    }
    refresh();

    return {
      el: root,
      api,
      setStatus: t => { status.textContent = t; },
      destroy() { api.destroy(); selBar.remove(); window.removeEventListener('resize', placeSelBar); document.removeEventListener('mouseup', onMouseUp); hl.clear(); },
      focus() {
        root.querySelectorAll('textarea').forEach(fit);
        if (opts.autofocus === false) return;
        if (draft() && !note.title && !note.body) title.focus({ preventScroll: true });
        else { doc.focus({ preventScroll: true }); api.caretTo(api.blocks()[api.blocks().length - 1], true); }
      },
    };
  };

  /* =========================================================
     Pantalla de la nota (nueva o existente)
     ========================================================= */
  K.openEditor = (note, o = {}) => {
    const st = K.state;
    if (st.editor) return;
    K.closePop();
    let persisted = !o.isNew;
    let dirty = false, closed = false, timer = 0, pushed = false;

    /* Una nota nueva se guarda sola apenas tiene algo escrito (así no se pierde si se cierra la pestaña) */
    const flush = () => {
      clearTimeout(timer);
      if (!persisted) {
        if (K.isEmpty(note)) return;
        persisted = true; dirty = false;
        note.order = K.topOrder(); st.notes.unshift(note);
        K.persist(note); K.refresh();
      } else if (dirty) { dirty = false; K.persist(note); }
      ed.setStatus('Guardado');
    };
    const saveSoon = () => {
      dirty = true;
      ed.setStatus('Guardando…');
      clearTimeout(timer);
      timer = setTimeout(flush, 600);
    };

    function close(action, fromPop) {
      if (closed) return;
      closed = true;
      clearTimeout(timer);
      K.closePop();
      ed.destroy();
      if (vv) { vv.removeEventListener('resize', fitView); vv.removeEventListener('scroll', fitView); }
      back.remove();
      document.body.classList.remove('modal-open');
      st.editor = null;
      if (pushed && !fromPop) { try { history.back(); } catch { /* sin historial */ } }

      note.body = ed.api.getBody();
      K.clean(note);
      if (!persisted) {
        if (!K.isEmpty(note)) { note.order = K.topOrder(); st.notes.unshift(note); K.persist(note); }
      } else if (K.isEmpty(note)) {                           // una nota vacía no se conserva
        st.notes = st.notes.filter(x => x.id !== note.id);
        K.run(K.api.deleteNote(note.id));
      } else if (dirty) {
        K.persist(note);
      }
      K.refresh();
      if (action === 'archive' && st.notes.includes(note)) K.toggleArchive(note);
      if (action === 'trash' && st.notes.includes(note)) K.trashNote(note);
    }

    const ed = K.buildEditor(note, {
      isDraft: () => !persisted, autofocus: !K.isTouch() || !!o.isNew,
      onChange: saveSoon, onClose: () => close(),
      onArchive: () => close('archive'), onTrash: !o.isNew || persisted ? () => close('trash') : null,
    });

    const back = h('div', { class: 'ed-back ed-note' }, h('div', { class: 'ed-card' }, ed.el));
    /* Se cierra solo si el toque empezó y terminó en el espacio de afuera */
    let downOnBack = false;
    back.addEventListener('pointerdown', e => { downOnBack = e.target === back; });
    back.addEventListener('click', e => { if (e.target === back && downOnBack) close(); });

    /* Celular: la pantalla se ajusta al teclado */
    const vv = window.visualViewport;
    const fitView = () => {
      back.style.setProperty('--vvh', vv.height + 'px');
      back.style.setProperty('--vvt', vv.offsetTop + 'px');
    };
    if (vv) { vv.addEventListener('resize', fitView); vv.addEventListener('scroll', fitView); fitView(); }

    st.editor = { close: fromPop => close(null, fromPop) };
    document.body.append(back);
    document.body.classList.add('modal-open');
    const card = back.querySelector('.ed-card');
    if (card) { card.setAttribute('role', 'dialog'); card.setAttribute('aria-label', 'Nota'); K.trapFocus(card); }
    try {
      if (o.reuseEntry) history.replaceState({ keepEditor: true }, '');   // ocupa el lugar de la nota anterior
      else history.pushState({ keepEditor: true }, '');
      pushed = true;
    } catch { /* file:// restrictivo */ }
    ed.setStatus(persisted ? 'Guardado' : 'Nota nueva');
    ed.focus();
  };

  /* El botón "atrás" del celular cierra la nota en vez de salir de la app */
  window.addEventListener('popstate', () => { if (K.state.editor) K.state.editor.close(true); });
})();
