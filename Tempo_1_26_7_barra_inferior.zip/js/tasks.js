/* =========================================================
   tasks.js — Pendientes. Son registros propios (colección "tasks"), no líneas de las notas.
   Un pendiente: { id, text, due ('AAAA-MM-DD' | null), done, doneAt, createdAt, updatedAt }
   · Se crean desde la pantalla Pendientes (K.parseCapture + K.addTasks). Las notas no
     tienen casillas: sus líneas "- [ ]" son solo texto.
   · Entrada en bloque (K.parseCapture): una línea = un pendiente. Una línea con el nombre
     de un día (VIERNES, sábado) fija la fecha de las líneas que siguen. Viñetas y casillas
     viejas ("- ", "• ", "- [ ] ") se quitan. Un @AAAA-MM-DD en la línea manda sobre lo demás.
   · Tildar o eliminar solo se hace acá. Eliminar se puede deshacer.
   · Objetivos (1.24.0): goalId y projectId (null si no tiene). Es el mismo registro que se ve en
     Objetivos: no se duplica. Ver goals.js y goalsui.js.
   · Rutina (etapa 2): un pendiente puede enlazarse a un bloque del calendario (blockId).
     Aparece los días que ese bloque tiene marcados, y se tilda por día (doneDays: {AAAA-MM-DD: ms}).
     Si el bloque se borra, el pendiente vuelve a ser suelto.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;
  const DUE = /(?:^|\s)@(\d{4}-\d{2}-\d{2})(?=\s|$)/;
  const TIME = /(?:^|\s)@(\d{1,2}:\d{2})(?=\s|$)/;   // hora de un pendiente: @9:30 o @18:00
  const MAX_ITEMS = 100;                   // tope por vez, para no crear cientos sin querer
  K.TASK_MAX = MAX_ITEMS;

  const pad = n => String(n).padStart(2, '0');
  const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parseYmd = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = n => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + n); return ymd(d); };

  /* @AAAA-MM-DD válida (rechaza fechas que no existen, como 2026-02-31) */
  const dueOf = text => {
    const m = DUE.exec(text);
    if (!m) return null;
    const d = parseYmd(m[1]);
    return ymd(d) === m[1] ? m[1] : null;
  };

  /* @H:MM o @HH:MM válida → "HH:MM"; null si no hay o es inválida (como 25:00) */
  const timeOf = text => {
    const m = TIME.exec(text);
    if (!m) return null;
    const [hh, mm] = m[1].split(':').map(Number);
    return hh < 24 && mm < 60 ? pad(hh) + ':' + pad(mm) : null;
  };

  /* Días de la semana por nombre (sin tildes, en minúscula) → número como en Date.getDay() */
  const WEEKDAYS = { domingo: 0, lunes: 1, martes: 2, miercoles: 3, jueves: 4, viernes: 5, sabado: 6 };
  const fold = s => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  /* Próxima vez que cae ese día (hoy, si hoy es ese día) */
  const nextWeekday = wd => addDays((wd - new Date().getDay() + 7) % 7);

  /* Texto pegado o escrito → [{ text, due }]. Una línea = un pendiente. Ver el encabezado del archivo. */
  K.parseCapture = (raw, fallbackDue = null) => {
    const out = [];
    let header = null;
    String(raw || '').split(/\r\n|\r|\n/).forEach(line0 => {
      let line = line0.trim();
      if (!line) return;
      if (/^[-=_*~·•\s]+$/.test(line)) return;                          // separadores: -----  =====  ~~~~
      const word = fold(line.replace(/:$/, '').trim());
      if (Object.prototype.hasOwnProperty.call(WEEKDAYS, word)) { header = nextWeekday(WEEKDAYS[word]); return; }
      line = line.replace(/^(?:[-*•]\s+)?(?:\[[ xX]?\]\s+)?/, '').trim();    // viñeta, "- [ ] " o "[ ] "
      if (!line) return;
      const explicit = dueOf(line);                                      // solo una fecha válida se saca del texto
      const due = explicit || header || fallbackDue || null;
      const time = timeOf(line);
      let text = explicit ? line.replace(DUE, ' ') : line;
      if (time) text = text.replace(TIME, ' ');
      text = text.replace(/\s+/g, ' ').trim().slice(0, 200);
      if (text) out.push(time ? { text, due, time } : { text, due });
    });
    return out;
  };

  /* Todos los pendientes (la copia de la app no trae los eliminados) */
  K.allTasks = () => K.state.tasks;
  K.taskById = id => K.state.tasks.find(t => t.id === id) || null;

  /* Días hasta la fecha límite: <0 vencida, 0 hoy */
  K.daysUntil = due => Math.round((parseYmd(due) - parseYmd(ymd(new Date()))) / 864e5);

  /* ---------- Rutinas ---------- */
  const nextDay = ds => { const d = parseYmd(ds); d.setDate(d.getDate() + 1); return ymd(d); };
  /* Día de la semana de AAAA-MM-DD: 0 = lunes (como en los bloques del calendario) */
  const dayIdx = ds => (parseYmd(ds).getDay() + 6) % 7;
  K.blockById = id => (id && K.state.blocks.find(b => b.id === id)) || null;
  /* Bloque al que está enlazada la rutina (null si es un pendiente suelto o el bloque ya no existe) */
  K.routineBlock = t => { const b = K.blockById(t.blockId); return K.isWeekly(b) ? b : null; };
  /* ¿Le toca a esta rutina ese día? */
  K.occursOn = (t, ds) => { const b = K.routineBlock(t); return !!b && K.daysOf(b).includes(dayIdx(ds)); };
  /* ¿Hecho? Rutina: ese día. Suelto: una sola vez. */
  K.isDone = (t, ds) => (K.routineBlock(t) ? !!(t.doneDays && t.doneDays[ds]) : !!t.done);
  /* Ocurrencias de rutina entre dos fechas (incluidas): [{ t, ds }] en orden de fecha */
  K.routineOccurrences = (from, to) => {
    const out = [];
    K.allTasks().forEach(t => {
      if (!K.routineBlock(t)) return;
      for (let ds = from; ds <= to; ds = nextDay(ds)) if (K.occursOn(t, ds)) out.push({ t, ds });
    });
    return out.sort((a, b) => a.ds.localeCompare(b.ds) || (a.t.createdAt || 0) - (b.t.createdAt || 0));
  };

  /* Alta de varios pendientes a la vez. items: [{ text, due }] */
  K.addTasks = (items, opts = {}) => {
    const now = Date.now();
    const made = items.slice(0, MAX_ITEMS).map((it, i) => {
      const t = { id: K.uid(), text: it.text, due: it.due || null, time: it.time || null, done: false, doneAt: null,
        blockId: opts.blockId || null, dur: opts.dur || null, labels: [], goalId: opts.goalId || null, projectId: opts.projectId || null,
        createdAt: now + i, updatedAt: now + i };
      K.state.tasks.push(t);
      K.run(K.api.saveTask(t));
      return t;
    });
    K.usageBump('tasks');
    return made;
  };

  /* Tilda o destilda. Rutina: solo ese día (ds). Suelto: una vez. La fecha de tildado alimenta
     "Hechas esta semana" en Métricas. */
  K.toggleTask = (t, ds) => {
    const cur = K.taskById(t.id);
    if (!cur) { K.refreshAll(); return; }
    if (K.routineBlock(cur)) {
      const days = { ...(cur.doneDays || {}) };
      if (days[ds]) delete days[ds]; else days[ds] = Date.now();
      cur.doneDays = days;
    } else {
      cur.done = !cur.done;
      cur.doneAt = cur.done ? Date.now() : null;
    }
    K.persistTask(cur);
    K.refreshAll();
  };

  /* Bloques ofrecidos para el lote: uno por bloque lógico (las mitades de un bloque que cruza medianoche cuentan una vez) */
  K.routineChoices = () => {
    const seen = new Set();
    return K.state.blocks.filter(K.isWeekly)
      .sort((a, b) => (K.daysOf(a)[0] ?? 9) - (K.daysOf(b)[0] ?? 9) || a.start - b.start)
      .filter(b => { const key = b.groupId || b.id; if (seen.has(key)) return false; seen.add(key); return true; });
  };
  K.rememberedRoutine = () => { try { return localStorage.getItem(K.PREF.capBlock) || ''; } catch { return ''; } };
  K.rememberRoutine = id => { try { if (id) localStorage.setItem(K.PREF.capBlock, id); else localStorage.removeItem(K.PREF.capBlock); } catch { /* sin storage */ } };

  /* Enlaza (o desenlaza, con null) un pendiente a un bloque de la rutina */
  K.setRoutine = (t, blockId) => {
    const cur = K.taskById(t.id);
    if (!cur) return;
    cur.blockId = blockId || null;
    cur.done = false; cur.doneAt = null; cur.doneDays = {};
    K.persistTask(cur);
    K.refreshAll();
    K.toast(blockId ? `Rutina: ${K.blockLabel(K.blockById(blockId))}` : 'Pendiente sin rutina');
  };

  const dropTask = id => {
    K.state.tasks = K.state.tasks.filter(x => x.id !== id);
    K.run(K.api.deleteTask(id));
  };
  const restoreTasks = snaps => {
    snaps.forEach(s => { K.state.tasks.push(s); K.run(K.api.saveTask(s)); });
    K.refreshAll();
  };

  /* Eliminar uno (con deshacer) */
  K.removeTask = t => {
    const cur = K.taskById(t.id);
    if (!cur) { K.refreshAll(); return; }
    const snap = { ...cur };
    dropTask(cur.id);
    K.refreshAll();
    K.toast('Pendiente eliminado', () => restoreTasks([snap]));
  };

  /* Eliminar varios (con deshacer) */
  K.removeTasks = list => {
    const snaps = list.map(t => K.taskById(t.id)).filter(Boolean).map(t => ({ ...t }));
    if (!snaps.length) return;
    snaps.forEach(s => dropTask(s.id));
    K.refreshAll();
    K.toast(snaps.length === 1 ? 'Pendiente eliminado' : `${snaps.length} pendientes eliminados`, () => restoreTasks(snaps));
  };

  /* Pasa un pendiente a una franja de su día (o la quita, con null) */
  K.setTaskSlot = (t, blockId) => {
    const cur = K.taskById(t.id);
    if (!cur) { K.refreshAll(); return; }
    cur.blockId = blockId || null;
    K.persistTask(cur);
    K.refreshAll();
    K.toast(blockId ? 'Pendiente en la franja' : 'Pendiente sin franja');
  };

  /* Movimiento desde Hoy: el destino puede ser una franja de una fecha, un bloque semanal
     o "Sin franja". Al salir de una rutina se convierte en pendiente puntual del día visible;
     así no se altera accidentalmente la repetición de las próximas semanas. */
  /* Mueve un pendiente a "Sin bloque" o a un bloque (rutina semanal o bloque de un día) */
  K.moveTaskInAgenda = (t, destination, date) => {
    const cur = K.taskById(t.id);
    if (!cur) { K.refreshAll(); return; }
    const ds = date || cur.due || ymd(new Date());
    if (destination === 'none') {
      const wasRoutine = !!K.routineBlock(cur);      // antes de soltar el vínculo
      cur.blockId = null;
      if (wasRoutine) {
        cur.doneDays = {};
        cur.done = false;
        cur.doneAt = null;
        cur.due = ds;
      }
      K.persistTask(cur);
      K.refreshAll();
      K.toast('Pendiente sin bloque');
      return;
    }
    if (destination.startsWith('block:')) {
      const id = destination.slice(6);
      const block = K.blockById(id);
      if (!block) return;
      cur.blockId = id;
      cur.doneDays = {};
      cur.done = false;
      cur.doneAt = null;
      cur.due = K.isWeekly(block) ? null : block.repeat.date;   // un bloque de un día fija el día del pendiente
      K.persistTask(cur);
      K.refreshAll();
      K.toast(K.isWeekly(block) ? 'Pendiente agregado a la rutina semanal' : 'Pendiente agregado al bloque');
    }
  };

  /* Abre Foco con este pendiente como objetivo */
  K.focusOnTask = t => {
    K.setTarget({ kind: 'task', id: t.id, text: t.text, goalId: t.goalId || null });
    K.go({ name: 'focus' });
  };

  /* Objetivo de un pendiente: el objetivo en general o uno de sus proyectos */
  const goalMenu = t => {
    const goals = K.state.goals.slice().sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
    if (!goals.length) return [{ label: 'No hay objetivos: creá uno en Objetivos', icon: 'target', run: () => K.go({ name: 'goals' }) }];
    const items = [{ label: 'Sin objetivo', icon: 'x', checked: !t.goalId, run: () => K.setTaskGoal(t, null) }];
    goals.forEach(g => {
      items.push({ label: g.name, icon: 'target', checked: t.goalId === g.id && !t.projectId, run: () => K.setTaskGoal(t, g.id, null) });
      K.goalProjects(g).forEach(p => items.push({ label: p.name, icon: 'chevron', indent: true,
        checked: t.projectId === p.id, run: () => K.setTaskGoal(t, g.id, p.id) }));
    });
    return items;
  };

  const dueBadge = t => {
    if (!t.due) return null;
    const n = K.daysUntil(t.due);
    let text, cls;
    if (t.done) { text = parseYmd(t.due).toLocaleDateString('es-AR', { day: 'numeric', month: 'short' }).replace('.', ''); cls = ''; }
    else if (n < 0) { text = n === -1 ? 'Venció ayer' : `Venció hace ${-n} días`; cls = ' overdue'; }
    else if (n === 0) { text = 'Hoy'; cls = ' today'; }
    else if (n === 1) { text = 'Mañana'; cls = ' soon'; }
    else { text = parseYmd(t.due).toLocaleDateString('es-AR', { day: 'numeric', month: 'short' }).replace('.', ''); cls = n <= 7 ? ' soon' : ''; }
    return h('span', { class: 'task-due' + cls, title: t.due }, text);
  };

  /* Con fecha primero (la más cercana arriba), sin fecha al final; en empates, el orden de alta */
  const byDue = (a, b) => (a.due ? 0 : 1) - (b.due ? 0 : 1) || (a.due || '').localeCompare(b.due || '') || (a.createdAt || 0) - (b.createdAt || 0);
  K.byDue = byDue;

  /* Menú del botón Rutina: los bloques del calendario */
  const routineMenu = t => {
    const blocks = K.state.blocks.filter(K.isWeekly).sort((a, b) => (K.daysOf(a)[0] ?? 9) - (K.daysOf(b)[0] ?? 9) || a.start - b.start);
    const items = blocks.length
      ? blocks.map(b => ({ label: K.blockLabel(b), icon: 'calendar', checked: t.blockId === b.id, run: () => K.setRoutine(t, b.id) }))
      : [{ label: 'No hay bloques: creá uno en Hoy', icon: 'calendar', run: () => K.go({ name: 'today' }) }];
    if (t.blockId) items.push('-', { label: 'Quitar rutina', icon: 'x', run: () => K.setRoutine(t, null) });
    return items;
  };

  /* Un pendiente como fila de lista. opts.date: el día de una rutina (se tilda ese día). opts.noDue: sin fecha visible */
  /* Franjas del día del pendiente (solo pendientes con fecha y que no son de una rutina) */
  const slotMenu = t => {
    const list = K.slotsOn(t.due);
    if (!list.length) return [{ label: 'No hay franjas este día: creá una en Hoy', icon: 'clock', run: () => K.go({ name: 'today' }) }];
    return [{ label: 'Sin bloque', icon: 'x', checked: !t.blockId, run: () => K.setTaskSlot(t, null) },
      ...list.map(s => ({ label: `${s.title || 'Franja'} · ${K.hm(s.start)}–${K.hmIn(s.end)}`, icon: 'clock',
        checked: t.blockId === s.id, run: () => K.setTaskSlot(t, s.id) }))];
  };

  /* Menú ⋯ de cada pendiente: enfocar, objetivo, rutina, franja y eliminar */
  const taskMenu = (t, anchor, edit) => {
    const done = K.isDone(t, null);
    return [
      { label: 'Editar texto', icon: 'edit', run: edit },
      ...(done ? [] : [{ label: 'Enfocar en esta tarea', icon: 'timer', run: () => K.focusOnTask(t) }]),
      { label: 'Objetivo…', icon: 'target', keep: true, run: () => K.openPop(anchor, K.menu(goalMenu(t))) },
      { label: 'Rutina…', icon: 'calendar', keep: true, run: () => K.openPop(anchor, K.menu(routineMenu(t))) },
      ...(t.due && !K.routineBlock(t) ? [{ label: 'Franja…', icon: 'clock', keep: true, run: () => K.openPop(anchor, K.menu(slotMenu(t))) }] : []),
      '-',
      { label: 'Eliminar pendiente', icon: 'x', run: () => K.removeTask(t) },
    ];
  };

  K.taskItem = (t, opts = {}) => {
    const b = K.routineBlock(t), ds = opts.date || null;
    const done = K.isDone(t, ds);
    const c = b && K.blockColor(b);
    const goal = t.goalId ? K.goalById(t.goalId) : null;
    const proj = goal && t.projectId ? goal.projects.find(p => p.id === t.projectId) : null;
    const more = h('button', {
      type: 'button', class: 'task-more', title: 'Más opciones', 'aria-label': 'Opciones de: ' + t.text,
      svg: icon('more', 16), onclick: e => K.togglePop(e.currentTarget, () => K.menu(taskMenu(t, e.currentTarget, beginEdit))),
    });
    const label = h('span', { class: 'task-label' }, t.text || 'Sin texto');
    const textWrap = h('span', { class: 'task-text' }, label,
      t.time ? h('small', { class: 'task-time' }, t.time) : null,
      b ? h('small', { class: 'task-src' }, c ? h('span', { class: 'dot', style: `--c:${c.hex}` }) : null, ' ', K.blockLabel(b)) : null,
      goal ? h('small', { class: 'task-src task-goal' }, h('span', { svg: icon('target', 12) }), ' ', goal.name + (proj ? ' › ' + proj.name : '')) : null);
    function beginEdit() {
      if (!textWrap.isConnected || textWrap.querySelector('input.task-edit-input')) return;
      const input = h('input', { type: 'text', class: 'task-edit-input', value: t.text, maxlength: '200', 'aria-label': 'Editar pendiente' });
      let finished = false;
      const finish = save => {
        if (finished) return; finished = true;
        const value = input.value.trim().slice(0, 200);
        if (save && value && value !== t.text) { t.text = value; K.persistTask(t); K.refreshAll(); }
        else { input.replaceWith(label); if (save && !value) K.toast('El pendiente necesita un texto'); }
      };
      label.replaceWith(input); input.focus(); input.select();
      input.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); finish(true); }
        else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
      });
      input.addEventListener('blur', () => finish(true));
    }
    return h('li', { class: 'task-item' + (done ? ' done' : '') + (b ? ' routine' : ''), 'data-task-id': t.id },
      h('button', {
        type: 'button', class: 'task-check', role: 'checkbox', 'aria-checked': String(done),
        'aria-label': (done ? 'Marcar como pendiente: ' : 'Marcar como hecha: ') + t.text,
        onclick: () => K.toggleTask(t, ds),
      }, done ? h('span', { svg: icon('check', 14) }) : null),
      textWrap,
      opts.noDue || b ? null : dueBadge(t),
      more);
  };
})();
