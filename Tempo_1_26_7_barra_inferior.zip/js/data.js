/* =========================================================
   data.js — exportar / importar, migración desde versiones
   anteriores y datos de ejemplo del primer arranque.
   Formato que se acepta: v5 (y v4, que tiene la misma forma).
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const st = K.state;

  /* ---------- Exportar ----------
     El JSON se arma por lotes de EXPORT_CHUNK registros, cediendo el hilo entre lotes: con muchos
     registros la pantalla sigue respondiendo y no se congela al tocar "Exportar".
     La copia refleja lo que había al tocar el botón (se toma una foto de cada colección primero). */
  const EXPORT_KEYS = ['notes', 'labels', 'blocks', 'events', 'sessions', 'tasks', 'goals', 'slots'];
  const EXPORT_CHUNK = 250;
  const EXPORT_NOTICE = 2000;               // desde esta cantidad de registros se avisa que se está preparando
  const yieldTurn = () => new Promise(r => setTimeout(r, 0));
  let exporting = false;

  K.buildExport = async () => {
    const snap = Object.fromEntries(EXPORT_KEYS.map(k => [k, JSON.parse(JSON.stringify(st[k] || []))]));
    const parts = ['{"version":6'];
    for (const key of EXPORT_KEYS) {
      const items = snap[key];
      parts.push(`,${JSON.stringify(key)}:[`);
      for (let i = 0; i < items.length; i += EXPORT_CHUNK) {
        const chunk = items.slice(i, i + EXPORT_CHUNK).map(x => JSON.stringify(x)).join(',\n');
        parts.push(i ? ',\n' + chunk : chunk);
        await yieldTurn();
      }
      parts.push(']');
    }
    parts.push('}');
    return parts.join('');
  };



  K.exportData = async () => {
    if (exporting) return;                  // un toque por vez: no se arman dos copias a la vez
    exporting = true;
    const total = EXPORT_KEYS.reduce((n, k) => n + (st[k] || []).length, 0);
    if (total >= EXPORT_NOTICE) K.toast('Preparando la copia…');
    try {
      const json = await K.buildExport();
      const blob = new Blob([json], { type: 'application/json' });
      const a = K.h('a', { href: URL.createObjectURL(blob), download: 'tempo-' + new Date().toISOString().slice(0, 10) + '.json' });
      document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      try { localStorage.setItem(K.PREF.exported, new Date().toISOString()); } catch { /* sin storage */ }
      if (st.route && st.route.name === 'settings') K.refreshAll();   // "Última copia" se actualiza sin recargar
    } catch (e) {
      console.error(e);
      K.toast('No se pudo preparar la copia. Probá de nuevo.');
    } finally {
      exporting = false;
    }
  };

  /* ---------- Aviso de copia de seguridad ----------
     Aparece arriba de las pantallas si nunca se exportó o pasaron 14 días, y hay algo que perder.
     "Más tarde" lo oculta 7 días. Nunca se muestra con menos de 8 elementos guardados (los ejemplos iniciales no cuentan). */
  K.BACKUP_DAYS = 14;
  K.BACKUP_MIN_ITEMS = 8;   // ni los ejemplos de bienvenida cuentan: hace falta contenido propio
  K.BACKUP_SNOOZE_DAYS = 7;
  K.backupBanner = () => {
    const get = k => { try { return localStorage.getItem(k) || ''; } catch { return ''; } };
    const items = st.notes.length + st.labels.length + st.blocks.length + st.events.length;
    if (items < K.BACKUP_MIN_ITEMS) return null;
    const now = Date.now();
    const snooze = Date.parse(get(K.PREF.backupSnooze));
    if (snooze && snooze > now) return null;
    const last = Date.parse(get(K.PREF.exported));
    const days = Number.isFinite(last) ? Math.floor((now - last) / 864e5) : null;
    if (days !== null && days < K.BACKUP_DAYS) return null;
    const text = days === null
      ? 'Todavía no hiciste una copia de seguridad. Tus datos viven solo en este navegador.'
      : `Hace ${days} días que no hacés una copia de seguridad. Tus datos viven solo en este navegador.`;
    const box = K.h('div', { class: 'banner backup-banner', role: 'status' },
      K.h('span', {}, text),
      K.h('button', { class: 'btn small', type: 'button', onclick: () => { K.exportData(); box.remove(); } }, 'Exportar copia'),
      K.h('button', { class: 'btn small', type: 'button', onclick: () => {
        try { localStorage.setItem(K.PREF.backupSnooze, new Date(now + K.BACKUP_SNOOZE_DAYS * 864e5).toISOString()); } catch { /* sin storage */ }
        box.remove();
      } }, 'Más tarde'));
    return box;
  };

  /* ---------- Importar Markdown: una nota por archivo ---------- */
  const MD_MAX = 500000;     // caracteres por archivo
  const mdToBody = text => text.split('\n').map(line => line
    .replace(/^#{1,6}\s+/, '## ')                      // todo encabezado pasa a subtítulo
    .replace(/^(\s*)[*+]\s+/, '$1- ')                  // viñetas * y + → -
    .replace(/__(.+?)__/g, '**$1**')).join('\n').trim();

  K.parseMarkdownNote = (text, fileName) => {
    const lines = String(text).replace(/\r\n?/g, '\n').split('\n');
    let i = 0;
    while (i < lines.length && !lines[i].trim()) i++;
    let title;
    const m = /^#\s+(.+?)\s*#*\s*$/.exec(lines[i] || '');
    if (m) { title = m[1].trim(); i++; }
    else title = String(fileName || '').replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' ').trim();
    let labels = [];
    while (i < lines.length && !lines[i].trim()) i++;
    const lm = /^_?Etiquetas:\s*(.+?)_?\s*$/i.exec(lines[i] || '');   // la línea que escribe la exportación
    if (lm) { labels = lm[1].split(',').map(x => x.trim()).filter(Boolean); i++; }
    return { title, labels, body: mdToBody(lines.slice(i).join('\n')) };
  };

  /* Un archivo exportado por Tempo trae "<!-- tempo:nota=ID -->" antes de cada nota.
     Si el ID ya existe, la nota se actualiza en su lugar (texto y título); si no, se crea. El orden del archivo se conserva. */
  const splitTempoNotes = text => {
    const parts = String(text).split(/^<!-- tempo:nota=([^\s>]+) -->[ \t]*$/m);
    if (parts.length < 3) return null;
    const out = [];
    for (let k = 1; k < parts.length; k += 2) {
      out.push({ id: parts[k], text: parts[k + 1].replace(/(^|\n)-{3,}\s*$/, '') });
    }
    return out;
  };

  K.importMarkdown = async files => {
    await K.retryRefresh();
    const docs = [];
    let skipped = 0;
    for (const f of files) {
      let text;
      try { text = await f.text(); } catch { skipped++; continue; }
      if (!text.trim() || text.length > MD_MAX) { skipped++; continue; }
      docs.push({ name: f.name, text, stamp: K.stampOf({ updatedAt: f.lastModified }) });   // fecha del archivo
    }
    let res;
    try { res = await commitPlan((snap, un) => planMarkdown(docs, snap, un)); }
    catch (err) { console.error(err); K.toast('No se pudo guardar la importación. No se cambió nada: probá de nuevo.'); return 0; }
    const refreshed = await refreshFromStore();
    K.refreshAll();
    const parts = [];
    if (res.added) parts.push(`${res.added} ${res.added === 1 ? 'nota nueva' : 'notas nuevas'}`);
    if (res.updated) parts.push(`${res.updated} ${res.updated === 1 ? 'actualizada' : 'actualizadas'}`);
    if (res.conflicts.length) parts.push(`${res.conflicts.length} ${res.conflicts.length === 1 ? 'conflicto' : 'conflictos'}: se conservó la versión de este dispositivo`);
    const omitted = skipped + (res.skipped || 0);
    if (omitted) parts.push(`${omitted} ${omitted === 1 ? 'omitida' : 'omitidas'}`);
    const summary = parts.length ? parts.join(' · ') : 'No se importó nada: archivos vacíos, muy grandes o repetidos';
    K.toast(refreshed ? summary : summary + '. Los datos ya están guardados, pero la pantalla no se actualizó: recargá la página.');
    return res.added + res.updated;
  };

  /* ---------- Markdown: una nota, o todas las notas de una etiqueta ---------- */
  K.downloadText = (name, text, type) => {
    const blob = new Blob([text], { type });
    const a = K.h('a', { href: URL.createObjectURL(blob), download: name });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  const slug = s => String(s || 'sin-titulo').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'nota';
  const linkMD = l => {
    if (l.url) return `- [${l.title || l.url}](${l.url})`;
    const name = K.targetName(l.target);
    return `- [[${name}]]`;
  };
  K.noteToMarkdown = n => {
    const lines = [`<!-- tempo:nota=${n.id} -->`, `# ${n.title || 'Sin título'}`, ''];
    const names = K.labelsOf(n).map(l => l.name);
    if (names.length) lines.push(`_Etiquetas: ${names.join(', ')}_`, '');
    if ((n.links || []).length) lines.push(...n.links.map(linkMD), '');
    lines.push((n.body || '').trimEnd(), '');
    return lines.join('\n');
  };
  K.exportNoteMD = n => {
    K.downloadText(slug(n.title) + '.md', K.noteToMarkdown(n), 'text/markdown;charset=utf-8');
    K.toast('Nota exportada en Markdown');
  };
  K.exportLabelMD = l => {
    const notes = K.state.notes.filter(n => K.isLive(n) && n.labels.includes(l.id)).sort(K.byOrder);
    if (!notes.length) { K.toast(`“${l.name}” no tiene notas para exportar`); return; }
    const text = ['<!-- Tempo: podés reordenar, editar o agregar un plan a estas notas. Conservá las líneas "<!-- tempo:nota=... -->" para que Tempo reconozca cada nota al importar. -->', `# ${l.name}`, '', ...notes.map(K.noteToMarkdown).flatMap(t => [t, '---', ''])].join('\n');
    K.downloadText(slug(l.name) + '.md', text, 'text/markdown;charset=utf-8');
    K.toast(`${notes.length} ${notes.length === 1 ? 'nota exportada' : 'notas exportadas'} en Markdown`);
  };

  /* Calendario → .ics (Google Calendar, Outlook, Apple Calendar).
     Bloques de la rutina = eventos semanales recurrentes (desde su próximo día).
     Eventos con hora = 60 min; sin hora = todo el día. Horas "flotantes" (hora local). */
  K.exportICS = () => {
    const pad = n => String(n).padStart(2, '0');
    const CODES = ['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU'];       // índice 0 = lunes
    const ymd = d => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
    /* 24:00 no existe en iCalendar (RFC 5545): el fin del día es 00:00 del día siguiente */
    const local = (d, mins) => {
      const m = Math.round(mins) % 1440;
      return `${ymd(mins >= 1440 ? addDays(d, 1) : d)}T${pad(Math.floor(m / 60))}${pad(m % 60)}00`;
    };
    const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
    const esc = s => String(s || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');
    const enc = new TextEncoder();
    const fold = line => {                                          // máximo 75 octetos por línea
      const out = []; let cur = '', bytes = 0;
      for (const ch of line) {
        const n = enc.encode(ch).length;
        if (bytes + n > 75) { out.push(cur); cur = ' '; bytes = 1; }
        cur += ch; bytes += n;
      }
      out.push(cur); return out.join('\r\n');
    };
    const labelById = new Map(st.labels.map(l => [l.id, l]));
    const labelNames = ids => (ids || []).map(id => labelById.get(id)?.name).filter(Boolean);
    const now = new Date();
    const stamp = d => d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const todayIdx = (today.getDay() + 6) % 7;
    const out = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Tempo//ES', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:Tempo'];
    const ev = (uid, props) => out.push('BEGIN:VEVENT', `UID:${uid}@mi-keep`, `DTSTAMP:${stamp(now)}`, ...props, 'END:VEVENT');
    let count = 0;

    st.blocks.forEach(b => {
      if (K.isOnce(b)) {                                    // franja de un día: un solo evento
        const [y, mo, dd] = b.repeat.date.split('-').map(Number);
        const first = new Date(y, mo - 1, dd);
        const cats1 = labelNames(b.labels);
        ev(b.id, [
          `SUMMARY:${esc(b.title || 'Bloque')}`,
          `DTSTART:${local(first, b.start)}`, `DTEND:${local(first, b.end > b.start ? b.end : Math.min(1440, b.start + 60))}`,
          ...(cats1.length ? [`CATEGORIES:${cats1.map(esc).join(',')}`] : []),
        ]);
        count++;
        return;
      }
      const days = [...new Set(K.daysOf(b))].filter(i => i >= 0 && i <= 6).sort((x, y) => x - y);
      if (!days.length) return;
      const ahead = Math.min(...days.map(i => (i - todayIdx + 7) % 7));
      const first = addDays(today, ahead);
      const start = b.start, end = b.end > b.start ? b.end : Math.min(1440, b.start + 60);
      const cats = labelNames(b.labels);
      ev(b.id, [
        `SUMMARY:${esc(b.title || 'Bloque')}`,
        `DTSTART:${local(first, start)}`, `DTEND:${local(first, end)}`,
        `RRULE:FREQ=WEEKLY;BYDAY=${days.map(i => CODES[i]).join(',')}`,
        ...(cats.length ? [`CATEGORIES:${cats.map(esc).join(',')}`] : []),
      ]);
      count++;
    });

    st.events.forEach(e => {
      const [y, m, d] = e.date.split('-').map(Number);
      const day = new Date(y, m - 1, d);
      const cats = labelNames(e.labels);
      const meta = cats.length ? [`CATEGORIES:${cats.map(esc).join(',')}`] : [];
      if (e.time == null) {
        ev(e.id, [`SUMMARY:${esc(e.title || 'Evento')}`, `DTSTART;VALUE=DATE:${ymd(day)}`, `DTEND;VALUE=DATE:${ymd(addDays(day, 1))}`, ...meta]);
      } else {
        ev(e.id, [`SUMMARY:${esc(e.title || 'Evento')}`, `DTSTART:${local(day, e.time)}`, `DTEND:${local(day, Math.min(1440, e.time + 60))}`, ...meta]);
      }
      count++;
    });

    out.push('END:VCALENDAR');
    const blob = new Blob([out.map(fold).join('\r\n') + '\r\n'], { type: 'text/calendar;charset=utf-8' });
    const a = K.h('a', { href: URL.createObjectURL(blob), download: 'tempo-calendario-' + ymd(now).replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3') + '.ics' });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    K.toast(`Calendario exportado: ${count} ${count === 1 ? 'elemento' : 'elementos'}`);
  };

  /* Acepta el JSON histórico (v4-v6) y el formato de respaldo completo de versiones anteriores (su historial se ignora). */
  K.normalizeImport = data => {
    if (!data || typeof data !== 'object' || Array.isArray(data) || !Array.isArray(data.notes))
      throw new Error('no es un archivo de Tempo');
    const full = data.format === 'tempo-full-backup' && data.backupVersion === 1;
    if (!full && data.version != null && ![4, 5, 6].includes(data.version))
      throw new Error('versión de respaldo no compatible');
    if (data.format != null && !full) throw new Error('formato de respaldo no compatible');
    const out = { notes: data.notes };
    for (const key of ['labels', 'blocks', 'events', 'sessions', 'tasks', 'goals', 'slots']) {
      if (data[key] != null && !Array.isArray(data[key])) throw new Error(`colección ${key} inválida`);
      out[key] = Array.isArray(data[key]) ? data[key] : [];
    }
    return out;
  };

  /* ---------- Validación de lo que se importa ---------- */
  const isObj = x => !!x && typeof x === 'object' && !Array.isArray(x);
  const strs = a => (Array.isArray(a) ? a.filter(x => typeof x === 'string') : []);
  const num = (v, lo, hi) => (Number.isInteger(v) && v >= lo && v <= hi ? v : null);
  const validId = id => typeof id === 'string' && id.trim().length > 0 && id.length <= 200;
  const validDate = value => {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [y, m, d] = value.split('-').map(Number);
    const date = new Date(0);
    date.setFullYear(y, m - 1, d);
    date.setHours(0, 0, 0, 0);
    return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === d;
  };
  const validStamp = v => Number.isFinite(v) && v >= 0;
  /* Solo http(s): un enlace "javascript:" de un archivo ajeno no se acepta */
  K.safeUrl = u => (typeof u === 'string' && /^https?:\/\/\S+$/i.test(u.trim()) ? u.trim() : null);
  const cleanCards = arr => arr.filter(l => isObj(l) && (!l.url || K.safeUrl(l.url))).map(l => (l.url ? { ...l, url: K.safeUrl(l.url) } : l));

  const timeIn = v => (typeof v === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(v) ? v : null);
  const cleanTask = (raw, labelMap) => {
    if (!isObj(raw) || !validId(raw.id) || typeof raw.text !== 'string' || !raw.text.trim() || raw.text.length > 200) return null;
    if (raw.due != null && !validDate(raw.due)) return null;
    if (raw.done != null && typeof raw.done !== 'boolean') return null;
    if (raw.doneAt != null && !validStamp(raw.doneAt)) return null;
    if (raw.createdAt != null && !validStamp(raw.createdAt)) return null;
    if (raw.updatedAt != null && !validStamp(raw.updatedAt)) return null;
    if (raw.blockId != null && !validId(raw.blockId)) return null;
    if (raw.slotId != null && !validId(raw.slotId)) return null;     // respaldos anteriores
    if (raw.labels != null && !Array.isArray(raw.labels)) return null;
    const taskLabels = raw.labels || [];
    if (taskLabels.some(id => !validId(id) || !labelMap[id])) return null;
    const doneDays = {};
    if (raw.doneDays != null && !isObj(raw.doneDays)) return null;
    for (const [day, at] of Object.entries(raw.doneDays || {})) {
      if (!validDate(day) || !validStamp(at)) return null;
      doneDays[day] = at;
    }
    const src = { ...raw };
    delete src.slotId;                       // campo de versiones anteriores: ahora es blockId
    return { ...(timeIn(raw.time) ? { time: timeIn(raw.time) } : {}), ...src, id: raw.id, text: raw.text, due: raw.due ?? null, done: raw.done === true,
      labels: [...new Set(taskLabels.map(id => labelMap[id]))],
      doneAt: raw.doneAt ?? null, blockId: raw.blockId ?? raw.slotId ?? null, dur: Number.isInteger(raw.dur) && raw.dur > 0 && raw.dur <= 1440 ? raw.dur : null,
      pos: Number.isFinite(raw.pos) ? raw.pos : null, doneDays,
      goalId: raw.goalId ?? null, projectId: raw.projectId ?? null,
      createdAt: raw.createdAt ?? Date.now(), updatedAt: raw.updatedAt ?? Date.now() };
  };

  /* Bloque de rutina (weekly, con días) o franja de un día (once, con fecha). Acepta la forma vieja
     (days[] o date) para respaldos anteriores a 1.26.4. */
  const cleanBlock = (b, labelMap) => {
    if (!isObj(b) || !validId(b.id)) return null;
    const src = { ...b };
    delete src.days;
    const start = num(b.start, 0, 1439), end = num(b.end, 1, 1440);
    if (start == null || end == null || end <= start) return null;
    let repeat;
    if (isObj(b.repeat) && b.repeat.type === 'once') {
      if (!validDate(b.repeat.date)) return null;
      repeat = { type: 'once', date: b.repeat.date };
    } else if (!isObj(b.repeat) && b.date != null) {                     // franja de versiones anteriores
      if (!validDate(b.date)) return null;
      repeat = { type: 'once', date: b.date };
    } else {
      const raw = isObj(b.repeat) && Array.isArray(b.repeat.days) ? b.repeat.days : (Array.isArray(b.days) ? b.days : []);
      const days = [...new Set(raw.filter(d => Number.isInteger(d) && d >= 0 && d <= 6))];
      if (!days.length) return null;
      repeat = { type: 'weekly', days };
    }
    delete src.date;
    return { ...K.makeBlock(), ...src, repeat, title: String(b.title || '').slice(0, 60), start, end,
      color: typeof b.color === 'string' ? b.color : null,
      labels: strs(b.labels).map(id => labelMap[id]).filter(Boolean), notes: strs(b.notes) };
  };
  const cleanEvent = (e, labelMap) => {
    if (!isObj(e) || !validId(e.id) || !validDate(e.date) || (e.time != null && num(e.time, 0, 1439) == null)) return null;
    return { ...K.makeEvent(), ...e, title: String(e.title || '').slice(0, 120), time: e.time == null ? null : e.time,
      labels: strs(e.labels).map(id => labelMap[id]).filter(Boolean), notes: strs(e.notes) };
  };
  /* Objetivo importado: se valida lo que el normalizador no puede arreglar solo (fechas, tipos) */
  const cleanGoal = raw => {
    if (!isObj(raw) || !validId(raw.id) || typeof raw.name !== 'string' || !raw.name.trim()) return null;
    for (const k of ['startDate', 'deadline']) if (raw[k] != null && !K.isYmd(raw[k])) return null;
    if (raw.projects != null && !Array.isArray(raw.projects)) return null;
    if (raw.resources != null && !Array.isArray(raw.resources)) return null;
    for (const k of ['createdAt', 'updatedAt']) if (raw[k] != null && !validStamp(raw[k])) return null;
    return K.normalizeGoal(raw);
  };
  const cleanSession = s => (isObj(s) && validId(s.id) && Number.isFinite(s.start) && s.start >= 0 &&
    Number.isFinite(s.end) && s.end >= s.start && Number.isFinite(s.ms) && s.ms > 0 ? s : null);

  /* ---------- Plan de importación ----------
     makePlan arma, sobre una copia de lo guardado, qué registros hay que escribir y el resumen.
     No toca la memoria ni el disco: K.api.transact escribe todo junto o nada. */
  const COLL_NAMES = ['notes', 'labels', 'blocks', 'events', 'sessions', 'tasks', 'goals', 'slots'];
  const makePlan = (snap, unstamped) => {
    const ops = [];
    const res = { added: 0, updated: 0, same: 0, kept: 0, conflicts: [], invalid: 0, skipped: 0 };
    const idx = Object.fromEntries(COLL_NAMES.map(c => [c, new Map(snap[c].map(x => [x.id, x]))]));
    const planned = new Map();              // "coleccion\u0000id" -> registro planeado en esta importación
    const plannedNoStamp = new Set();       // registros planeados sin fecha válida
    const key = (c, id) => c + '\u0000' + id;
    const get = (c, id) => planned.get(key(c, id)) || idx[c].get(id) || null;
    const live = (c, id) => { const r = get(c, id); return r && !r.deleted ? r : null; };
    const put = (c, rec, known) => {
      ops.push({ c, rec });
      planned.set(key(c, rec.id), rec);
      if (!known) plannedNoStamp.add(key(c, rec.id));
    };
    /* Fecha de lo que ya hay: null si no se puede comparar (sin fecha válida) */
    const localStamp = (c, id, local) => {
      const k = key(c, id);
      const unknown = planned.has(k) ? plannedNoStamp.has(k) : unstamped(c, id);
      return unknown ? null : K.stampOf(local);
    };
    const decide = (c, rec, incomingStamp) => {
      const local = get(c, rec.id);
      return { local, action: K.resolveRecord(local, rec, local ? localStamp(c, rec.id, local) : null, incomingStamp) };
    };
    const act = (c, rec, action, local, known, label) => {
      switch (action) {
        case 'add': put(c, rec, known); res.added++; break;
        case 'replace':
          put(c, rec, known); res.updated++; break;
        case 'same': res.same++; break;
        case 'kept': res.kept++; break;
        default: res.conflicts.push(label);
      }
    };
    /* Etiquetas: el nombre (sin mayúsculas ni acentos) identifica a la etiqueta; si falta, se crea */
    const liveLabels = snap.labels.filter(l => !l.deleted);
    const byName = new Map(liveLabels.map(l => [K.norm(l.name), l]));
    let order = liveLabels.reduce((m, l) => Math.max(m, l.order), -1) + 1;
    const labelMap = {};
    liveLabels.forEach(l => { labelMap[l.id] = l.id; });
    /* Crea una etiqueta a partir de un registro completo (conserva color, tipo, enlaces e id del archivo) */
    const createLabel = rec => {
      const nl = K.normalizeLabel({ ...K.makeLabel(rec.name.trim()), ...rec, name: rec.name.trim(), order: order++ });
      put('labels', nl, true);
      byName.set(K.norm(nl.name), nl);
      return nl.id;
    };
    const labelFor = name => {
      const clean = String(name || '').trim();
      if (!clean) return null;
      const ex = byName.get(K.norm(clean));
      return ex ? ex.id : createLabel({ name: clean });
    };
    const top = snap.notes.reduce((m, n) => Math.min(m, Number.isFinite(n.order) ? n.order : 0), 0) - 1;
    return { ops, res, get, live, put, decide, act, labelFor, createLabel, byName, labelMap, top };
  };

  /* Plan de un archivo JSON (formato histórico o respaldo completo) */
  const planImport = (d, snap, unstamped) => {
    const P = makePlan(snap, unstamped);
    const labelMap = P.labelMap;
    for (const l of d.labels || []) {
      if (!isObj(l) || !validId(l.id) || typeof l.name !== 'string' || !l.name.trim()) continue;
      const exById = P.get('labels', l.id);
      if (exById) { labelMap[l.id] = exById.deleted ? undefined : exById.id; continue; }   // un borrado no se revive
      const ex = P.byName.get(K.norm(l.name));
      if (ex) { labelMap[l.id] = ex.id; continue; }
      labelMap[l.id] = P.createLabel(l);
    }
    /* Notas: la más reciente primero; las nuevas quedan arriba y en orden de archivo */
    const raws = [...(d.notes || [])].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    const base = P.top - raws.length;
    raws.forEach((raw, i) => {
      if (!isObj(raw) || !validId(raw.id) || (raw.title != null && typeof raw.title !== 'string') || (raw.body != null && typeof raw.body !== 'string')) { P.res.invalid++; return; }
      const fixed = {
        ...raw,
        labels: [...new Set((Array.isArray(raw.labels) ? raw.labels : []).filter(validId).map(id => labelMap[id]).filter(Boolean))],
        order: typeof raw.order === 'number' ? raw.order : base + i,
      };
      if (Array.isArray(raw.links)) fixed.links = cleanCards(raw.links);
      const rec = K.noteDefaults(fixed);
      const inStamp = K.stampOf(raw);
      const { local, action } = P.decide('notes', rec, inStamp);
      P.act('notes', rec, action, local, inStamp !== null, rec.title || 'Sin título');
    });
    for (const b of [...(d.blocks || []), ...(d.slots || [])]) {       // franjas viejas entran como bloques once
      const nb = cleanBlock(b, labelMap);
      if (!nb) { P.res.invalid++; continue; }
      const inStamp = K.stampOf(b);
      const { local, action } = P.decide('blocks', nb, inStamp);
      P.act('blocks', nb, action, local, inStamp !== null, nb.title || 'Bloque');
    }
    for (const e of d.events || []) {
      const ne = cleanEvent(e, labelMap);
      if (!ne) { P.res.invalid++; continue; }
      const inStamp = K.stampOf(e);
      const { local, action } = P.decide('events', ne, inStamp);
      P.act('events', ne, action, local, inStamp !== null, ne.title || 'Evento');
    }
    for (const raw of d.sessions || []) {
      const s = cleanSession(raw);
      if (!s) { P.res.invalid++; continue; }
      const { local, action } = P.decide('sessions', s, null);
      P.act('sessions', s, action, local, false, 'sesión de foco');
    }
    for (const raw of d.goals || []) {
      const g = cleanGoal(raw);
      if (!g) { P.res.invalid++; continue; }
      const inStamp = K.stampOf(raw);
      const { local, action } = P.decide('goals', g, inStamp);
      P.act('goals', g, action, local, inStamp !== null, g.name);
    }
    for (const raw of d.tasks || []) {
      const t0raw = cleanTask(raw, labelMap);
      if (!t0raw) { P.res.invalid++; continue; }
      /* Bloque que no está ni en el archivo ni en este dispositivo: el pendiente se conserva, sin bloque */
      const t0 = t0raw.blockId && !P.live('blocks', t0raw.blockId) ? { ...t0raw, blockId: null } : t0raw;
      /* Objetivo y proyecto solo si existen (en el archivo o ya en este dispositivo) */
      const goal = t0.goalId ? P.live('goals', t0.goalId) : null;
      /* Bloque de un día solo si el pendiente es de ese mismo día */
      const link = t0.blockId ? P.live('blocks', t0.blockId) : null;
      const t = { ...t0, goalId: goal ? goal.id : null,
        projectId: goal && t0.projectId && goal.projects.some(p => p.id === t0.projectId) ? t0.projectId : null,
        blockId: link && K.isOnce(link) && link.repeat.date !== t0.due ? null : t0.blockId };
      const inStamp = K.stampOf(raw);
      const { local, action } = P.decide('tasks', t, inStamp);
      P.act('tasks', t, action, local, inStamp !== null, t.text);
    }
    return { ops: withMateriaConversion(P.ops, snap), result: P.res };
  };

  /* Materias de un respaldo viejo → objetivos, como al arrancar la app. Se aplica sobre lo que quedará
     guardado (lo del archivo ya planeado + lo de este dispositivo), así no depende del orden. */
  function withMateriaConversion(ops, snap) {
    const next = {};
    COLL_NAMES.forEach(c => {
      const m = new Map((snap[c] || []).map(x => [x.id, x]));
      ops.filter(o => o.c === c).forEach(o => m.set(o.rec.id, o.rec));
      next[c] = [...m.values()];
    });
    const conv = K.convertMaterias(next);
    return [...ops, ...conv.ops.map(o => ({ c: o.c, rec: o.rec }))];
  }

  /* Plan de archivos Markdown: notas exportadas por Tempo (con su id) o notas sueltas */
  const planMarkdown = (docs, snap, unstamped) => {
    const P = makePlan(snap, unstamped);
    const base = P.top - docs.length;
    const contentKeys = new Set(snap.notes.filter(n => !n.deleted).map(n => n.title + '\u0000' + n.body));
    docs.forEach((f, i) => {
      const tempo = splitTempoNotes(f.text);
      if (tempo) {
        tempo.forEach((part, j) => {
          const p = K.parseMarkdownNote(part.text, f.name);
          const local = P.live('notes', part.id);
          if (local) {
            // Nota existente: el archivo es la versión de la que se habla. Gana si es más reciente que la local.
            const rec = K.noteDefaults({ ...local, title: p.title, body: p.body, updatedAt: (f.stamp ?? Date.now()) - j * 1000 });
            const { action } = P.decide('notes', rec, f.stamp);
            P.act('notes', rec, action, local, f.stamp !== null, p.title);
            return;
          }
          const labels = [...new Set(p.labels.map(name => P.labelFor(name)).filter(Boolean))];
          const n = K.makeNote({ title: p.title, body: p.body, labels, order: base + i });
          n.updatedAt = (f.stamp ?? Date.now()) - j * 1000;
          P.put('notes', n, f.stamp !== null);
          P.res.added++;
        });
        return;
      }
      const p = K.parseMarkdownNote(f.text, f.name);
      const key = p.title + '\u0000' + p.body;
      if (contentKeys.has(key)) { P.res.skipped++; return; }            // ya estaba
      contentKeys.add(key);
      const labels = [...new Set(p.labels.map(name => P.labelFor(name)).filter(Boolean))];
      P.put('notes', K.makeNote({ title: p.title, body: p.body, labels, order: base + i }), true);
      P.res.added++;
    });
    return { ops: P.ops, result: P.res };
  };

  /* Importa un JSON ya validado: todo o nada, y la pantalla se actualiza solo después de guardar */
  /* Escribe un plan. Si falla ANTES de confirmar, lanza (nada cambió). Si el fallo es posterior a la
     confirmación, devuelve el resumen igual: los datos ya están guardados. */
  const commitPlan = async plan => {
    try { return await K.api.transact(plan); }
    catch (err) {
      if (err && err.committed) { console.error(err); return err.result; }
      throw err;
    }
  };
  /* Pasa lo guardado a la pantalla. Si la lectura falla, la pantalla queda marcada como pendiente de actualizar. */
  const refreshFromStore = async () => {
    try { K.applyData(await (K.api.reload ? K.api.reload() : K.api.load())); K.refreshPending = false; return true; }
    catch (err) { console.error(err); K.refreshPending = true; return false; }
  };
  /* Reintenta solo la lectura: no vuelve a importar nada */
  K.retryRefresh = async () => {
    if (!K.refreshPending) return true;
    const ok = await refreshFromStore();
    if (ok) K.refreshAll();
    return ok;
  };
  /* Si la pestaña vuelve a estar visible con la pantalla pendiente, se reintenta la lectura */
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && K.refreshPending) K.retryRefresh();
  });

  /* Importa un JSON ya validado. Devuelve el resumen con refreshed: false si la pantalla no pudo actualizarse. */
  K.mergeData = async d => {
    const res = await commitPlan((snap, un) => planImport(d, snap, un));   // lanza solo si NO se confirmó nada
    res.refreshed = await refreshFromStore();
    return res;
  };

  const resumen = res => {
    const parts = [];
    if (res.added) parts.push(`Se agregaron ${res.added} ${res.added === 1 ? 'elemento' : 'elementos'}`);
    if (res.updated) parts.push(`${res.updated} ${res.updated === 1 ? 'actualizado' : 'actualizados'}`);
    if (res.kept) parts.push(`${res.kept} ${res.kept === 1 ? 'ya estaba más al día' : 'ya estaban más al día'} acá`);
    if (res.conflicts.length) parts.push(`${res.conflicts.length} ${res.conflicts.length === 1 ? 'conflicto' : 'conflictos'}: se conservó la versión de este dispositivo`);
    if (res.invalid) parts.push(`${res.invalid} ${res.invalid === 1 ? 'elemento inválido ignorado' : 'elementos inválidos ignorados'}`);
    return parts.length ? parts.join(' · ') : 'No había nada nuevo para importar';
  };

  K.importData = async file => {
    await K.retryRefresh();
    let data;
    try { data = JSON.parse(await file.text()); }
    catch (err) { console.error(err); K.toast('El archivo no es un JSON válido de Tempo'); return; }
    let d;
    try { d = K.normalizeImport(data); }
    catch (err) { K.toast(`No se importó nada: ${err.message}`); return; }
    let res;
    try { res = await K.mergeData(d); }
    catch (err) { console.error(err); K.toast('No se pudo guardar la importación. No se cambió nada: probá de nuevo.'); return; }
    K.refreshAll();
    K.toast(res.refreshed ? resumen(res) : resumen(res) + '. Los datos ya están guardados, pero la pantalla no se actualizó: recargá la página.');
  };

  /* Primer arranque: crea las notas de ejemplo (las versiones anteriores ya no se importan solas) */
  K.firstRun = async () => {
    let seen = false; try { seen = !!localStorage.getItem('mi-keep:v4:init'); } catch { /* sin storage */ }
    if (st.notes.length || st.labels.length || seen) return;
    try { localStorage.setItem('mi-keep:v4:init', '1'); } catch { /* sin storage */ }
    const facultad = K.createLabel('Facultad');
    const fisica = K.createLabel('Física');
    const seeds = [
      K.makeNote({ title: 'Bienvenido', body: [
        'Todo se guarda en este navegador. Hacé clic en cualquier parte del texto y escribí.',
        '',
        '## Cómo darle formato',
        'Seleccioná texto: aparece una barra con **negrita**, *cursiva* y ==resaltado==.',
        'También podés usar la barra de arriba o el clic derecho. Sin comandos que memorizar.',
        '',
        '## Listas y tareas',
        '- Una viñeta',
        '- Las notas son solo texto: los pendientes van en Hoy',
        '- Tildá un pendiente en Hoy cuando lo hagas',
        '',
        '## Enlaces',
        'Seleccioná una palabra y apretá Ctrl+K para enlazarla: [Apunte de ejemplo](https://drive.google.com).',
        'Para enlazar a otra nota o etiqueta: [[Apuntes de ejemplo]].',
        'Las cards de enlaces van dentro de cada etiqueta: ahí podés pegar una dirección y elegir su color.',
      ].join('\n') }),
      K.makeNote({ title: 'Apuntes de ejemplo', labels: [fisica.id, facultad.id],
        body: ['## Unidad 1', 'Vectores y fuerzas.', '', '## Parcial', 'Fecha a confirmar.'].join('\n') }),
      K.makeNote({ title: 'Ideas sueltas', body: 'Una nota también puede enlazar a otra, como [[Apuntes de ejemplo]].' }),
    ];
    /* Mismo milisegundo para todas: el orden de la lista pasa a depender de la base. Se fija por posición (lo primero, lo más nuevo). */
    const base = Date.now();
    seeds.forEach((n, i) => { n.order = i; n.createdAt = n.updatedAt = base - i; });
    for (const n of seeds.reverse()) { st.notes.unshift(n); await K.api.saveNote(n); }
  };
})();
