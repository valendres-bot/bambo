/* =========================================================
   actions.js — todo lo que modifica notas y etiquetas.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const st = K.state;

  K.refresh = () => {
    /* Otra pestaña guardó mientras había una nota abierta: se actualiza apenas se cierra (después de lo que cierre la nota) */
    if (K.externalStale && !st.editor) { K.externalStale = false; setTimeout(() => K.syncFromStorage(), 0); }
    K.renderSidebar(); K.renderList();
  };
  K.refreshAll = () => { K.renderSidebar(); K.renderTopbar(); K.renderList(); };

  /* ---------- Notas ---------- */
  K.togglePin = n => {
    n.pinned = !n.pinned;
    if (n.pinned) n.archived = false;          // fijar una nota archivada la desarchiva
    K.save(n); K.refresh();
  };

  K.toggleArchive = n => {
    const prev = { archived: n.archived, pinned: n.pinned };
    n.archived = !n.archived;
    if (n.archived) n.pinned = false;
    K.save(n); K.refresh();
    K.toast(n.archived ? 'Nota archivada' : 'Nota desarchivada', () => { Object.assign(n, prev); K.save(n); K.refresh(); });
  };

  K.trashNote = n => {
    const prev = { trashed: n.trashed, trashedAt: n.trashedAt, pinned: n.pinned };
    n.trashed = true; n.trashedAt = Date.now(); n.pinned = false;
    K.save(n); K.refresh();
    K.toast('Nota enviada a la papelera', () => { Object.assign(n, prev); K.save(n); K.refresh(); });
  };
  K.restoreNote = n => { n.trashed = false; n.trashedAt = null; K.save(n); K.refresh(); K.toast('Nota restaurada'); };
  K.deleteForever = n => {
    st.notes = st.notes.filter(x => x.id !== n.id);
    K.run(K.api.deleteNote(n.id));
    K.pruneLinks('notes', n.id);
    K.refresh();
    K.toast('Nota eliminada para siempre');
  };
  /* Papelera: una nota se elimina sola 7 días después de enviarse. Las que ya estaban en la papelera
     (de antes de esta versión) no tienen fecha: el plazo arranca desde la primera vez que se revisa. */
  K.purgeTrash = (now = Date.now()) => {
    const st = K.state;
    st.notes.forEach(n => { if (n.trashed && !Number.isFinite(n.trashedAt)) { n.trashedAt = now; K.save(n); } });
    const limit = now - 7 * 24 * 60 * 60 * 1000;
    const gone = st.notes.filter(n => n.trashed && Number.isFinite(n.trashedAt) && n.trashedAt <= limit);
    if (!gone.length) return 0;
    st.notes = st.notes.filter(n => !gone.includes(n));
    gone.forEach(n => { K.run(K.api.deleteNote(n.id)); K.pruneLinks('notes', n.id); });
    K.toast(gone.length === 1 ? 'Una nota de la papelera se eliminó por tener más de 7 días'
      : `${gone.length} notas de la papelera se eliminaron por tener más de 7 días`);
    return gone.length;
  };
  K.emptyTrash = async () => {
    const count = st.notes.filter(n => n.trashed).length;
    if (!count) return;
    if (!(await K.ask({ title: '¿Vaciar la papelera?', danger: true, ok: 'Eliminar para siempre',
      text: `Se eliminan para siempre ${count === 1 ? 'una nota' : count + ' notas'}. No se puede deshacer.` }))) return;
    const t = st.notes.filter(n => n.trashed);      // se vuelve a leer: pudo cambiar mientras se confirmaba
    st.notes = st.notes.filter(n => !n.trashed);
    t.forEach(n => { K.run(K.api.deleteNote(n.id)); K.pruneLinks('notes', n.id); });
    K.refresh();
  };

  /* Etiquetas de una nota */
  K.toggleNoteLabel = (n, id) => {
    n.labels = n.labels.includes(id) ? n.labels.filter(x => x !== id) : [...n.labels, id];
    if (K.noteById(n.id)) K.save(n);          // una nota nueva (borrador) se guarda al cerrar la card
  };

  /* Botones de acción directos de cada renglón (sin menú) */
  K.noteActions = n => {
    const { iconBtn } = K;
    if (n.trashed) {
      return [iconBtn('restore', 'Restaurar', () => K.restoreNote(n)),
        iconBtn('trash', 'Eliminar para siempre', () => K.deleteForever(n))];
    }
    /* Acciones frecuentes a un clic; lo menos frecuente queda detrás de ⋯.
       En móvil estas acciones siguen disponibles dentro del editor, sin llenar la fila. */
    const tag = iconBtn('tag', 'Etiquetas', () => K.togglePop(tag, () =>
      K.labelPicker(n, tag, () => { K.renderSidebar(); K.renderList(); })));
    const more = iconBtn('more', 'Más opciones', () => K.togglePop(more, () => K.menu([
      { label: n.archived ? 'Desarchivar' : 'Archivar', icon: n.archived ? 'unarchive' : 'archive', run: () => K.toggleArchive(n) },
      '-',
      { label: 'Enviar a la papelera', icon: 'trash', run: () => K.trashNote(n) },
    ])));
    return [
      iconBtn('pin', n.pinned ? 'Desfijar' : 'Fijar', () => K.togglePin(n), n.pinned ? 'on' : ''),
      tag,
      more,
    ];
  };

  /* Abrir una nota desde cualquier lugar. Si hay otra nota abierta, la reemplaza sin apilar historial. */
  K.openNote = n => { const swap = K.releaseEditor(); K.openEditor(n, { reuseEntry: swap }); };

  /* Una nota arrastrada puede soltarse sobre un destino de la barra lateral */
  K.dropNote = (n, key) => {
    if (key === 'archive') { if (!n.archived) K.toggleArchive(n); }
    else if (key === 'trash') { if (!n.trashed) K.trashNote(n); }
    else if (key.startsWith('label:')) {
      const id = key.slice(6);
      if (!n.labels.includes(id)) { K.toggleNoteLabel(n, id); K.refresh(); K.toast(`Etiqueta agregada: ${K.labelById(id).name}`); }
    }
  };

  /* ---------- Etiquetas ---------- */
  K.createLabel = name => {
    const clean = name.trim();
    if (!clean) return null;
    const existing = st.labels.find(l => K.norm(l.name) === K.norm(clean));
    if (existing) { existing.archived = false; K.saveLabel(existing); return existing; }
    const order = st.labels.reduce((m, l) => Math.max(m, l.order), -1) + 1;
    const l = K.makeLabel(clean, order);
    st.labels.push(l);
    K.saveLabel(l);
    return l;
  };

  K.renameLabel = (l, name) => {
    const clean = name.trim();
    if (!clean || clean === l.name) return;
    l.name = clean; K.saveLabel(l); K.refreshAll();
  };

  K.toggleLabelPin = l => {
    l.pinned = !l.pinned; K.saveLabel(l); K.refreshAll();
    K.toast(l.pinned ? `Etiqueta "${l.name}" fijada` : `Etiqueta "${l.name}" quitada de fijadas`);
  };

  /* Eliminar: la etiqueta se quita de todas sus notas. Las notas que solo tenían
     esa etiqueta van a la papelera. Deshacer lo revierte todo. */
  K.removeLabel = l => {
    const touched = st.notes.filter(n => n.labels.includes(l.id));
    const onlyThis = touched.filter(n => n.labels.length === 1 && !n.trashed);
    const snapshot = touched.map(n => ({ n, labels: [...n.labels], trashed: n.trashed, trashedAt: n.trashedAt }));

    st.labels = st.labels.filter(x => x.id !== l.id);
    touched.forEach(n => {
      n.labels = n.labels.filter(x => x !== l.id);
      if (onlyThis.includes(n)) { n.trashed = true; n.trashedAt = Date.now(); }
      K.save(n);
    });
    K.run(K.api.deleteLabel(l.id));
    const relink = K.pruneLinks('labels', l.id);
    if (st.route.name === 'label' && st.route.id === l.id) K.go({ name: 'all' }); else K.refreshAll();

    const extra = onlyThis.length ? `. ${onlyThis.length} nota(s) fueron a la papelera` : '';
    K.toast(`Etiqueta "${l.name}" eliminada${extra}`, () => {
      st.labels.push(l); K.saveLabel(l); relink();
      snapshot.forEach(({ n, labels, trashed, trashedAt }) => { n.labels = labels; n.trashed = trashed; n.trashedAt = trashedAt; K.save(n); });
      K.refreshAll();
    });
  };

  /* Archivar etiqueta: deja de verse en la barra; sus notas siguen donde están */
  K.archiveLabel = l => {
    l.archived = true; K.saveLabel(l);
    if (st.route.name === 'label' && st.route.id === l.id) K.go({ name: 'all' }); else K.refreshAll();
    K.toast(`Etiqueta "${l.name}" archivada`, () => K.unarchiveLabel(l, true));
  };

  K.unarchiveLabel = (l, quiet) => {
    l.archived = false; K.saveLabel(l);
    K.refreshAll();
    if (!quiet) K.toast(`Etiqueta "${l.name}" desarchivada`);
  };

  /* Reordenar etiquetas arrastrándolas (la lista de la barra lateral) */

  K.setLabelColor = (l, id) => { l.color = id; K.saveLabel(l); K.refreshAll(); };

  K.labelMenu = (l, anchor) => [
    { label: 'Renombrar', icon: 'text', run: () => { st.renaming = l.id; K.refreshAll(); } },
    { label: 'Color', icon: 'tone', keep: true, run: () => K.openPop(anchor, K.colorPicker(l.color, id => K.setLabelColor(l, id))) },
    { label: l.pinned ? 'Quitar de fijadas' : 'Fijar', icon: 'pin', run: () => K.toggleLabelPin(l) },
    { label: 'Archivar etiqueta', icon: 'archive', run: () => K.archiveLabel(l) },
    { label: 'Exportar notas (.md)', icon: 'download', run: () => K.exportLabelMD(l) },
    '-',
    { label: 'Eliminar etiqueta', icon: 'trash', run: () => K.removeLabel(l) },
  ];

  /* Selector de etiquetas de una nota: marcar, o crear escribiendo un nombre nuevo */
  K.labelPicker = (n, anchor, onChange) => {
    const box = K.h('div', { class: 'label-picker' });
    const input = K.h('input', { class: 'lp-input', placeholder: 'Buscar o crear etiqueta', 'aria-label': 'Buscar o crear etiqueta', autocomplete: 'off' });
    const list = K.h('div', { class: 'lp-list' });
    const draw = () => {
      const q = input.value.trim();
      const tk = K.tokens(q);
      list.replaceChildren();
      K.activeLabels()
        .filter(l => K.matchAll(l.name, tk))
        .sort((a, b) => Number(n.labels.includes(b.id)) - Number(n.labels.includes(a.id))
          || Number(!!b.pinned) - Number(!!a.pinned) || a.order - b.order)
        .forEach(l => {
        const on = n.labels.includes(l.id);
        list.append(K.h('button', { class: 'menu-item', type: 'button', role: 'menuitemcheckbox', 'aria-checked': String(on),
          onclick: () => { K.toggleNoteLabel(n, l.id); draw(); onChange && onChange(); } },
        K.h('span', { class: 'mi', svg: K.icon('tag', 16) }),
        K.h('span', { class: 'mlbl' }, K.hl(l.name, q)),
        on ? K.h('span', { class: 'check', svg: K.icon('check', 16) }) : null));
      });
      const exact = K.activeLabels().some(l => K.norm(l.name) === K.norm(q));
      if (q && !exact) {
        list.append(K.h('button', { class: 'menu-item', type: 'button', onclick: () => {
          const l = K.createLabel(q); if (l) K.toggleNoteLabel(n, l.id);
          input.value = ''; draw(); onChange && onChange();
        } }, K.h('span', { class: 'mi', svg: K.icon('plus', 16) }), K.h('span', { class: 'mlbl' }, `Crear “${q}”`)));
      }
      if (!list.children.length) list.append(K.h('div', { class: 'lp-none' }, 'Escribí para crear una etiqueta'));
    };
    input.addEventListener('input', draw);
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const q = input.value.trim();
        const exact = K.activeLabels().find(l => K.norm(l.name) === K.norm(q));
        const target = exact || (q ? K.createLabel(q) : null);
        if (target) { if (!n.labels.includes(target.id)) K.toggleNoteLabel(n, target.id); input.value = ''; draw(); onChange && onChange(); }
      }
    });
    box.append(input, list);
    draw();
    setTimeout(() => input.focus(), 0);
    return box;
  };

  /* Crear nota: la card de nota nueva (igual en escritorio y celular).
     Si estás dentro de una etiqueta, la nota nace con esa etiqueta. */
  K.newNote = () => {
    if (st.editor) return;
    K.openEditor(K.makeNote({ ...(K.capNoLabel() ? {} : K.defaultsForRoute()) }), { isNew: true });
  };

  /* ---------- Vista de notas: renglones o cuadros (se recuerda en este navegador) ---------- */
  K.noteView = () => { try { return localStorage.getItem(K.PREF.noteView) === 'cards' ? 'cards' : 'rows'; } catch { return 'rows'; } };
  K.setNoteView = v => { try { localStorage.setItem(K.PREF.noteView, v); } catch { /* sin storage */ } K.refreshAll(); };

  /* ---------- Captura: la nota nueva hereda o no la etiqueta de la vista (preferencia) ---------- */
  K.capNoLabel = () => { try { return localStorage.getItem(K.PREF.capNoLabel) === '1'; } catch { return false; } };
  K.setCapNoLabel = v => { try { localStorage.setItem(K.PREF.capNoLabel, v ? '1' : '0'); } catch { /* sin storage */ } };

  /* ---------- Selección y acciones en lote ----------
     Ctrl/⌘ + clic, o clic con algo ya seleccionado, suma o quita una nota. Al cambiar de vista se borra. */
  let selRoute = null;
  K.selIds = () => (K.state.sel = K.state.sel || []);
  K.isSel = id => K.selIds().includes(id);
  K.toggleSel = id => { const s = K.selIds(); const i = s.indexOf(id); if (i < 0) s.push(id); else s.splice(i, 1); K.refreshAll(); };
  K.clearSel = () => { K.state.sel = []; K.refreshAll(); };
  K.resetSelIfRouteChanged = () => { const key = K.hashFor(K.state.route); if (key !== selRoute) { selRoute = key; K.state.sel = []; } };

  /* Cambia varias notas a la vez. Guarda cómo estaban para poder deshacer desde el aviso. */
  K.batchChange = (notes, mutate, msg) => {
    const snap = notes.map(n => ({ n, pinned: n.pinned, archived: n.archived, trashed: n.trashed, trashedAt: n.trashedAt, labels: [...n.labels] }));
    notes.forEach(mutate);
    notes.forEach(n => K.save(n));
    K.state.sel = [];
    K.refreshAll();
    K.toast(msg, () => {
      snap.forEach(s => { s.n.pinned = s.pinned; s.n.archived = s.archived; s.n.trashed = s.trashed; s.n.trashedAt = s.trashedAt; s.n.labels = s.labels; K.save(s.n); });
      K.refreshAll();
    });
  };

  /* Botón flotante (celular): hoja para anotar algo rápido. El botón principal crea un pendiente;
     "Nota" pasa el mismo texto a una nota (primera línea = título). */
  K.quickAdd = () => {
    if (st.editor) return;
    const h = K.h;   // este módulo no trae su propio h()
    K.modal(close => {
      const input = h('textarea', { class: 'cap-in', rows: '3', spellcheck: 'true', maxlength: '5000',
        placeholder: 'Escribí un pendiente… (una línea por pendiente)', 'aria-label': 'Pendiente o nota' });
      const add = () => {
        const items = K.parseCapture(input.value, null);
        if (!items.length) { input.focus(); return; }
        K.addTasks(items);
        close();
        K.toast(items.length === 1 ? 'Pendiente agregado' : `${Math.min(items.length, K.TASK_MAX)} pendientes agregados`);
        K.refreshAll();
      };
      const asNote = () => {
        const lines = input.value.split('\n');
        const n = K.makeNote({ ...(K.capNoLabel() ? {} : K.defaultsForRoute()), title: (lines[0] || '').trim(), body: lines.slice(1).join('\n').trim() });
        close();
        K.openEditor(n, { isNew: true });
      };
      const addBtn = h('button', { type: 'button', class: 'btn primary', onclick: add }, 'Agregar pendiente');
      const syncAdd = () => { addBtn.disabled = !K.parseCapture(input.value, null).length; };
      input.addEventListener('input', syncAdd);
      input.addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); add(); } });
      syncAdd();
      setTimeout(() => input.focus(), 0);
      return [
        h('div', { class: 'sheet-head' }, h('h2', {}, 'Anotar algo'),
          h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Cerrar', svg: K.icon('x', 18), onclick: close })),
        h('div', { class: 'form' },
          h('p', { class: 'hint' }, 'Se guarda como pendiente. Si preferís una nota, tocá "Nota": el texto pasa a la nota, la primera línea como título.'),
          input),
        h('div', { class: 'sheet-foot' }, h('span', { class: 'grow' }),
          h('button', { type: 'button', class: 'btn', onclick: asNote }, 'Nota'),
          addBtn),
      ];
    });
  };

  K.startNewLabel = () => {
    st.newLabel = true;
    K.refreshAll();   // el campo aparece en Notas, junto a las etiquetas
  };

  /* ---------- Preferencias ---------- */
  K.setSort = s => { st.sort = s; try { localStorage.setItem(K.PREF.sort, s); } catch { /* sin storage */ } K.renderTopbar(); K.renderList(); };
  K.toggleSidebar = () => {
    if (K.isMobile()) document.body.classList.toggle('nav-open');
    else { try { localStorage.setItem(K.PREF.side, document.body.classList.toggle('side-closed') ? 'closed' : 'open'); } catch { /* sin storage */ } }
  };
})();
