/* =========================================================
   sidebar.js — barra lateral, agrupada según el recorrido de Tempo (1.25.1.3):
     Hacer:    Hoy (con el contador de lo que falta) · Foco
     Planear:  Objetivos
     Registro: Notas · Métricas
   Después, las etiquetas fijadas, y abajo archivo, papelera y configuración.
   Los elementos con data-drop reciben notas o etiquetas arrastradas.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon, iconBtn } = K;

  /* Campo de texto en línea para crear o renombrar etiquetas */
  K.nameInput = ({ value = '', placeholder = 'Nombre', onSubmit, onCancel }) => {
    const input = h('input', { class: 'nav-input', placeholder, 'aria-label': placeholder, maxlength: '40', autocomplete: 'off' });
    input.value = value;
    let done = false;
    const finish = ok => { if (done) return; done = true; if (ok && input.value.trim()) onSubmit(input.value.trim()); else onCancel(); };
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
    setTimeout(() => { input.focus(); input.select(); }, 0);
    return h('div', { class: 'nav-edit' }, h('span', { class: 'ni', svg: icon('tag', 17) }), input);
  };

  /* Marca de fijado: la misma para notas y etiquetas (barra lateral y lista) */
  K.pinMark = () => h('span', { class: 'pin-mark', title: 'Fijada', 'aria-hidden': 'true', svg: icon('pin', 12) });

  K.renderSidebar = () => {
    const st = K.state;
    const side = K.$('#side');
    side.replaceChildren();


    /* Fila de navegación genérica. o.tb: la sección también está en la barra inferior (celular), así que ahí se oculta */
    const row = (r, o) => {
      const a = h('a', {
        class: 'nav-item', href: K.hashFor(r),
        'aria-current': (o.current || K.sameRoute(r, st.route)) ? 'page' : null,
        onclick: () => document.body.classList.remove('nav-open'),
      },
      h('span', { class: 'ni', svg: icon(o.ic, 17) }),
      h('span', { class: 'lbl' }, o.label),
      o.n ? h('span', { class: 'count', 'aria-label': `${o.n} pendientes` }, String(o.n)) : null);
      const cls = 'nav-row' + (o.tb ? ' tb-row' : '');
      return h('div', o.drop ? { class: cls, 'data-drop': o.drop } : { class: cls }, a);
    };

    /* Fila de etiqueta: abre la etiqueta, acepta notas arrastradas y tiene su menú */
    const labelRow = l => {
      const a = h('a', {
        class: 'nav-item', href: K.hashFor({ name: 'label', id: l.id }), draggable: 'false',
        'aria-current': K.sameRoute({ name: 'label', id: l.id }, st.route) ? 'page' : null,
        onclick: () => document.body.classList.remove('nav-open'),
      },
      h('span', { class: 'ni', style: K.colorOf(l.color) ? `color:${K.colorOf(l.color).hex}` : null, svg: icon(K.labelIcon(l), 17) }),
      h('span', { class: 'lbl' }, l.name),
      l.pinned ? K.pinMark() : null);
      const more = iconBtn('more', 'Opciones de la etiqueta', e => {
        e.preventDefault(); e.stopPropagation();
        K.togglePop(more, () => K.menu(K.labelMenu(l, more)));
      }, 'more');
      return h('div', { class: 'nav-row', 'data-label-id': l.id, 'data-drop': 'label:' + l.id }, a, more);
    };

    /* ---------- Armado ---------- */
    side.append(
      h('div', { class: 'brand' }, h('span', { class: 'brand-mark' }), 'Tempo'),
      h('button', { class: 'side-search', type: 'button', onclick: K.openPalette },
        h('span', { svg: icon('search', 16) }), h('span', {}, 'Buscar'), h('kbd', {}, 'K')),
      h('div', { class: 'side-title tb-title' }, h('span', {}, 'Hacer')),
      row({ name: 'today' }, { ic: 'checklist', label: 'Hoy', n: K.todayCount(), tb: true }),
      row({ name: 'focus' }, { ic: 'timer', label: 'Foco', tb: true }),
      h('div', { class: 'side-title tb-title' }, h('span', {}, 'Planear')),
      row({ name: 'goals' }, { ic: 'target', label: 'Objetivos', tb: true }),
      h('div', { class: 'side-title' }, h('span', {}, 'Registro')),
      row({ name: 'all' }, { ic: 'file', label: 'Notas', tb: true }),
      row({ name: 'metrics' }, { ic: 'chart', label: 'Métricas' }),
    );

    /* Etiquetas: solo las fijadas (las demás se ven y se gestionan en Notas). En su orden propio. */
    const labels = K.activeLabels().filter(l => l.pinned).sort((a, b) => a.order - b.order);
    if (labels.length) side.append(h('div', { class: 'side-title' }, h('span', {}, 'Etiquetas')));
    const list = h('div', { class: 'label-list' });
    labels.forEach(l => {
      const el = labelRow(l);
      list.append(el);
      K.attachDrag(el, l, {
        container: list, reorder: true, item: '[data-label-id]', skip: 'button, input, textarea, select',
        onDrop: () => { /* soltar una etiqueta sobre otro destino no hace nada */ },
        commit: () => K.commitLabelOrder([...list.children].map(c => c.dataset.labelId).filter(Boolean)),
      });
    });
    side.append(list);

    side.append(
      h('div', { class: 'side-spacer' }),
      row({ name: 'archive' }, { ic: 'archive', label: 'Archivo', drop: 'archive' }),
      row({ name: 'trash' }, { ic: 'trash', label: 'Papelera', drop: 'trash' }),
      row({ name: 'settings' }, { ic: 'gear', label: 'Configuración' }),
    );
    K.renderTabbar();
  };

  /* Barra inferior (celular): Hoy · Foco · Objetivos · Notas · Más.
     "Más" abre la barra lateral (etiquetas, Métricas, Archivo, Papelera, Configuración). */
  K.renderTabbar = () => {
    const st = K.state, r = st.route;
    const bar = K.$('#tabbar');
    if (!bar) return;

    const tab = (route, o) => {
      const current = o.current !== undefined ? o.current : K.sameRoute(route, r);
      return h('a', {
        class: 'tab', href: K.hashFor(route), 'aria-current': current ? 'page' : null,
      },
      h('span', { class: 'tab-ico', svg: icon(o.ic, 22) },
        o.n ? h('span', { class: 'tab-count', 'aria-label': `${o.n} pendientes` }, String(o.n)) : null),
      h('span', { class: 'tab-lbl' }, o.label));
    };

    const moreCurrent = ['metrics', 'settings', 'archive', 'trash'].includes(r.name);
    bar.replaceChildren(
      tab({ name: 'today' }, { ic: 'checklist', label: 'Hoy', n: K.todayCount() }),
      tab({ name: 'focus' }, { ic: 'timer', label: 'Foco' }),
      tab({ name: 'goals' }, { ic: 'target', label: 'Objetivos', current: r.name === 'goals' || r.name === 'goal' }),
      tab({ name: 'all' }, { ic: 'file', label: 'Notas', current: r.name === 'all' || r.name === 'label' }),
      h('button', {
        class: 'tab', type: 'button', 'aria-current': moreCurrent ? 'page' : null,
        onclick: () => K.toggleSidebar(),
      },
      h('span', { class: 'tab-ico', svg: icon('more', 22) }),
      h('span', { class: 'tab-lbl' }, 'Más')));
  };
})();
