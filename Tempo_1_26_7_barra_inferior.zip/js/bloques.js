/* =========================================================
   bloques.js — modelo unificado de bloque (1.26.4)
   Una sola colección, \"blocks\", para lo que antes eran dos:
     · rutina semanal  → repeat: { type: 'weekly', days: [0..6] }   (0 = lunes)
     · franja de un día → repeat: { type: 'once', date: 'AAAA-MM-DD' }
   Campos comunes: id, groupId, title, start, end, color, labels, notes, createdAt, updatedAt, rev.
   La colección \"slots\" queda vacía: sus registros pasan a \"blocks\" con el mismo id, y en
   el disco se dejan como tombstones (ver K.migrateStored en storage.js).
   Funciones puras, sin DOM ni almacenamiento. Hoy, Calendario, Foco y la importación las usan.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  const isYmd = s => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);
  const idxOfYmd = ds => {
    const [y, m, d] = ds.split('-').map(Number);
    return (new Date(y, m - 1, d).getDay() + 6) % 7;          // 0 = lunes
  };

  /* Forma unificada válida */
  const hasRepeat = b => !!(b && b.repeat && (
    (b.repeat.type === 'weekly' && Array.isArray(b.repeat.days)) ||
    (b.repeat.type === 'once' && isYmd(b.repeat.date))));

  K.ymdOf = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  K.todayYmd = () => K.ymdOf(new Date());
  K.isWeekly = b => !!b && !b.deleted && !!b.repeat && b.repeat.type === 'weekly';
  K.isOnce = b => !!b && !b.deleted && !!b.repeat && b.repeat.type === 'once';
  /* Días de la semana de una rutina (lunes = 0). Una franja no tiene días de la semana. */
  K.daysOf = b => (K.isWeekly(b) ? [...b.repeat.days] : []);

  /* Rutina semanal (forma vieja: days[]) → unificada. Conserva id, groupId y fechas. */
  K.unifyBlock = b => {
    if (!b || b.deleted || hasRepeat(b)) return b;
    const { days, ...rest } = b;
    return { ...rest, repeat: { type: 'weekly', days: [...(days || [])] } };
  };

  /* Franja de un día (forma vieja: date) → unificada. Conserva id y color. */
  K.unifySlot = s => {
    if (!s || s.deleted || hasRepeat(s)) return s;
    const { date, ...rest } = s;
    return { ...rest, groupId: rest.groupId ?? null, labels: rest.labels || [], notes: rest.notes || [],
      repeat: { type: 'once', date } };
  };

  /* Pendientes: un solo vínculo con un bloque (blockId). El antiguo slotId pasa a blockId.
     Si el bloque ya no existe, el pendiente queda sin bloque. Idempotente. */
  K.migrateTask = (t, blockIds) => {
    if (!t || t.deleted || !('slotId' in t)) {
      if (t && t.blockId && blockIds && !blockIds.has(t.blockId)) return { ...t, blockId: null };
      return t;
    }
    const { slotId, ...rest } = t;
    const keep = slotId && blockIds.has(slotId) ? slotId : (rest.blockId && blockIds.has(rest.blockId) ? rest.blockId : null);
    return { ...rest, blockId: keep };
  };

  /* Migra la forma de un conjunto de registros (sin tocar lo que ya está migrado) y devuelve
     { blocks, tasks }. */
  K.migrateToUnified = (blocks = [], slots = [], tasks = []) => {
    const outBlocks = [...blocks.map(K.unifyBlock), ...slots.map(K.unifySlot)];
    const ids = new Set(outBlocks.map(b => b.id));
    return { blocks: outBlocks, tasks: tasks.map(t => K.migrateTask(t, ids)) };
  };

  /* Migración de los datos guardados (lo que sale de storage). Devuelve el conjunto nuevo y las
     operaciones a escribir en el disco: los bloques convertidos y un tombstone por cada franja
     que pasó a \"blocks\". Idempotente: una segunda pasada no escribe nada. */
  K.migrateStored = data => {
    const ops = [];
    const blocks = [], slots = [];
    const ids = new Set();
    (data.blocks || []).forEach(b => {
      if (b.deleted) { blocks.push(b); return; }
      const u = K.unifyBlock(b);
      blocks.push(u); ids.add(u.id);
      if (u !== b) ops.push({ c: 'blocks', id: u.id, rec: { ...u, rev: (Number(b.rev) || 0) + 1 } });
    });
    (data.slots || []).forEach(s => {
      if (s.deleted) { slots.push(s); return; }
      if (!ids.has(s.id)) {
        const u = K.unifySlot(s);
        blocks.push(u); ids.add(u.id);
        ops.push({ c: 'blocks', id: u.id, rec: { ...u, rev: (Number(s.rev) || 0) + 1 } });
      }
      const tomb = { id: s.id, deleted: true, rev: (Number(s.rev) || 0) + 1, updatedAt: Date.now() };
      slots.push(tomb);
      ops.push({ c: 'slots', id: s.id, rec: tomb });
    });
    const bIds = new Set(blocks.filter(b => !b.deleted).map(b => b.id));
    const tasks = (data.tasks || []).map(t => {
      const u = K.migrateTask(t, bIds);
      if (u !== t && !t.deleted) ops.push({ c: 'tasks', id: t.id, rec: { ...u, rev: (Number(t.rev) || 0) + 1 } });
      return u;
    });
    if (!ops.length) return { data, ops };
    return { data: { ...data, blocks, slots, tasks }, ops };
  };

  /* Ocurrencias de un día: bloques (rutina o franja) que caen en ds, ordenados por inicio.
     Es el único selector que deberían usar Hoy, Calendario y Foco. */
  K.occurrencesOn = (blocks, ds) => {
    if (!isYmd(ds)) return [];
    const wd = idxOfYmd(ds);
    return blocks
      .filter(b => !b.deleted && hasRepeat(b) && (
        (b.repeat.type === 'weekly' && b.repeat.days.includes(wd)) ||
        (b.repeat.type === 'once' && b.repeat.date === ds)))
      .sort((a, b) => (a.start - b.start) || (a.end - b.end));
  };
})();
