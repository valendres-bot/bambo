/* =========================================================
   schedule.js — Calendario de la barra lateral:
   · Rutina semanal: grilla 24/7 (lunes a domingo), bloques con
     horarios de 10 en 10 min, colores, días múltiples y vínculos
     En celular se ve un día por vez.
   · Próximos eventos: lista aparte, con fecha y hora opcional.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;
  const st = K.state;

  const DAY_LONG = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
  const DAY_SHORT = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  const MONTH_SHORT = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const pad = n => String(n).padStart(2, '0');

  /* ---------- Horas: minutos desde las 00:00. Campos y grilla usan el mismo intervalo: 10 min (STEP) ---------- */
  const STEP = '600';                                   // segundos del input de hora (10 min)
  K.hm = m => pad(Math.floor((m % 1440) / 60)) + ':' + pad(m % 60);        // 1440 se muestra 00:00 (fin del día)
  K.hmIn = m => (m >= 1440 ? '23:59' : K.hm(m));          // el input de hora no acepta 24:00
  const toMin = v => { if (!v) return null; const [a, b] = v.split(':').map(Number); return a * 60 + b; };
  const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

  /* Texto corto de un bloque para listas y vínculos: "Estudio · Lun+ 08:20" (título, primer día y hora de inicio) */
  K.blockLabel = b => { const ds = K.daysOf(b); return `${b.title || 'Sin título'} · ${DAY_SHORT[ds[0]]}${ds.length > 1 ? '+' : ''} ${K.hm(b.start)}`; };

  K.dot = l => { const c = l && K.colorOf(l.color); return c ? h('span', { class: 'dot', style: `--c:${c.hex}` }) : null; };

  /* Color de un bloque: el propio (las etiquetas no dan color: quedan aisladas en Notas) */
  K.blockColor = b => K.colorOf(b.color) || null;

  /* ---------- Modelos ---------- */
  /* groupId: nulo salvo que el bloque sea una mitad de uno que cruza la medianoche (ver "Bloques que cruzan") */
  /* days (forma de formulario) se guarda como rutina semanal; repeat, si viene, se usa tal cual */
  K.makeBlock = (over = {}) => {
    const { days, ...rest } = over;
    const repeat = days ? { type: 'weekly', days: [...days] } : (rest.repeat ? { ...rest.repeat } : { type: 'weekly', days: [0] });
    return { id: K.uid(), groupId: null, title: '', start: 480, end: 540, color: null, labels: [], notes: [],
      createdAt: Date.now(), updatedAt: Date.now(), rev: 0, ...rest, repeat };
  };
  K.makeEvent = (over = {}) => ({
    id: K.uid(), title: '', date: ymd(new Date()), time: null, labels: [], notes: [],
    createdAt: Date.now(), updatedAt: Date.now(), rev: 0, ...over,
  });

  /* ---------- Guardado ---------- */
  K.saveBlock = b => { b.updatedAt = Date.now(); K.run(K.api.saveBlock(b)); };
  K.saveEvent = e => { e.updatedAt = Date.now(); K.run(K.api.saveEvent(e)); };

  /* ---------- Bloques que cruzan la medianoche ----------
     Se guardan como dos registros con el mismo groupId:
       mitad 1: days D,   start s, end 1440   (hasta las 24:00)
       mitad 2: days D+1, start 0, end e      (desde las 00:00 del día siguiente)
     Editar, borrar o deshacer actúa siempre sobre el grupo entero, en una sola escritura.
     Los bloques sin groupId siguen siendo bloques comunes. */

  /* Todas las mitades del bloque (o el bloque solo). Siempre usa los registros que están en st.blocks. */
  K.groupOf = b => {
    if (!b) return [];
    const same = b.groupId ? st.blocks.filter(x => x.groupId === b.groupId) : st.blocks.filter(x => x.id === b.id);
    return same.length ? same : [b];
  };

  /* Una sola fila para el formulario: une las dos mitades (inicio de la primera, fin de la segunda) */
  K.logicalBlock = b => {
    const parts = K.groupOf(b);
    if (parts.length < 2) return { ...b, days: K.daysOf(b), labels: [...b.labels], notes: [...b.notes] };
    const head = parts.find(x => x.end === 1440) || parts[0];
    const tail = parts.find(x => x !== head);
    return { ...head, end: tail.end, days: K.daysOf(head), labels: [...head.labels], notes: [...head.notes] };
  };

  /* Parte un bloque lógico en 1 o 2 registros, según cruce la medianoche */
  K.splitBlock = (d, s, endMin) => {
    const base = { title: d.title, color: d.color, labels: [...d.labels], notes: [...d.notes] };
    if (endMin >= s) return [{ ...base, days: [...d.days], start: s, end: endMin }];
    return [
      { ...base, days: [...d.days], start: s, end: 1440 },
      { ...base, days: d.days.map(x => (x + 1) % 7), start: 0, end: endMin },
    ];
  };

  /* Reemplaza `prev` (un bloque o el grupo entero; [] si es nuevo) por `parts`.
     Mantiene el id y el createdAt de la primera parte, y el groupId si sigue habiendo dos mitades. */
  K.commitBlock = (prev, parts) => {
    const first = prev[0];
    const groupId = parts.length > 1 ? ((first && first.groupId) || K.uid()) : null;
    const out = parts.map((p, i) => K.makeBlock({
      ...p,
      id: i === 0 && first ? first.id : K.uid(),
      groupId,
      createdAt: first ? first.createdAt : Date.now(),
    }));
    const prevIds = new Set(prev.map(x => x.id));
    const outIds = new Set(out.map(x => x.id));
    st.blocks = st.blocks.filter(x => !prevIds.has(x.id)).concat(out);
    prev.forEach(x => { if (!outIds.has(x.id)) K.run(K.api.deleteBlock(x.id)); });
    out.forEach(b => K.saveBlock(b));
    return out;
  };

  /* Datos viejos: las dos mitades de un bloque que cruzaba la medianoche se guardaron sin groupId.
     Se emparejan: mismo título, mitad 1 hasta 24:00, mitad 2 desde 00:00 y con los días corridos un día. */
  K.linkLegacyHalves = () => {
    const key = days => [...days].sort((a, c) => a - c).join(',');
    const tails = st.blocks.filter(b => K.isWeekly(b) && !b.groupId && b.start === 0 && b.end < 1440);
    st.blocks.filter(b => K.isWeekly(b) && !b.groupId && b.end === 1440 && b.start > 0).forEach(head => {
      const want = key(K.daysOf(head).map(d => (d + 1) % 7));
      const tail = tails.find(t => !t.groupId && t.title === head.title && key(K.daysOf(t)) === want);
      if (!tail) return;
      const gid = K.uid();
      head.groupId = gid; tail.groupId = gid;
      K.saveBlock(head); K.saveBlock(tail);
    });
  };

  K.removeBlock = b => {
    const members = K.groupOf(b);
    const ids = new Set(members.map(m => m.id));
    st.blocks = st.blocks.filter(x => !ids.has(x.id));
    members.forEach(m => K.run(K.api.deleteBlock(m.id)));
    K.refreshAll();
    K.toast(`Bloque "${b.title || 'Sin título'}" eliminado`, () => {
      members.forEach(m => { st.blocks.push(m); K.saveBlock(m); });
      K.refreshAll();
    });
  };
  K.removeEvent = e => {
    st.events = st.events.filter(x => x.id !== e.id);
    K.run(K.api.deleteEvent(e.id));
    K.refreshAll();
    K.toast(`Evento "${e.title || 'Sin título'}" eliminado`, () => { st.events.push(e); K.saveEvent(e); K.refreshAll(); });
  };

  /* Al eliminar una etiqueta o una nota, se quitan también de bloques y eventos.
     Devuelve una función que los vuelve a vincular (para "Deshacer"). */
  K.pruneLinks = (kind, id) => {
    const touched = [];
    const keep = x => (st.blocks.includes(x) ? K.saveBlock(x) : K.saveEvent(x));
    [...st.blocks, ...st.events].forEach(x => {
      if (!Array.isArray(x[kind]) || !x[kind].includes(id)) return;
      x[kind] = x[kind].filter(v => v !== id);
      touched.push(x); keep(x);
    });
    return () => touched.forEach(x => { if (!x[kind].includes(id)) { x[kind] = [...x[kind], id]; keep(x); } });
  };

  /* ---------- Modal (reutiliza la card flotante y Esc para cerrar) ---------- */
  /* onClose: se llama al cerrar, también si se cierra sin confirmar (para resolver K.ask) */
  K.modal = (build, onClose) => {
    if (st.editor) return null;
    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      back.remove();
      document.body.classList.remove('modal-open');
      st.editor = null;
      if (onClose) onClose();
    };
    const sheet = h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Diálogo', tabindex: '-1' }, build(close));
    const back = h('div', { class: 'ed-back' }, sheet);
    let downOnBack = false;
    back.addEventListener('pointerdown', e => { downOnBack = e.target === back; });
    back.addEventListener('click', e => { if (e.target === back && downOnBack) close(); });
    st.editor = { close };
    document.body.append(back);
    document.body.classList.add('modal-open');
    K.trapFocus(sheet);
    /* El foco entra al diálogo: primero un campo; si no hay, el botón de cancelar (la opción segura) */
    const target = sheet.querySelector('input') || sheet.querySelector('.sheet-foot .btn.quiet') || sheet;
    target.focus({ preventScroll: true });
    return close;
  };

  /* ---------- Piezas de formulario ---------- */
  const field = (label, control, extra) => h('label', { class: 'fld' }, h('span', { class: 'fld-l' }, label), control, extra || null);

  function colorSwatches(current, pick) {
    const wrap = h('div', { class: 'csw', role: 'group', 'aria-label': 'Color' });
    const draw = cur => wrap.replaceChildren(
      h('button', { type: 'button', class: 'csw-none', 'aria-pressed': String(!cur), title: 'Sin color', 'aria-label': 'Sin color', onclick: () => { pick(null); draw(null); } }, '—'),
      ...K.COLORS.map(c => h('button', {
        type: 'button', class: 'csw-dot', style: `--c:${c.hex}`, 'aria-pressed': String(cur === c.id),
        title: c.id, 'aria-label': c.id, onclick: () => { pick(c.id); draw(c.id); },
      })));
    draw(current);
    return wrap;
  }
  K.colorPicker = (current, pick) => { const w = colorSwatches(current, pick); return h('div', { class: 'csw-pop' }, w); };

  function dayToggles(days, onChange) {
    return h('div', { class: 'daypick', role: 'group', 'aria-label': 'Días' }, DAY_SHORT.map((d, i) => {
      const b = h('button', { type: 'button', 'aria-pressed': String(days.includes(i)), title: DAY_LONG[i], onclick: () => {
        const on = days.includes(i);
        const next = on ? days.filter(x => x !== i) : [...days, i].sort((a, c) => a - c);
        days = next; onChange(next);
        b.setAttribute('aria-pressed', String(!on));
      } }, d);
      return b;
    }));
  }

  /* ---------- Formulario de bloque ---------- */
  function eventForm(e, isNew, close) {
    const draft = { ...e, labels: [...e.labels], notes: [...e.notes] };
    const err = h('p', { class: 'form-err', role: 'alert' });
    const title = h('input', { class: 'fld-in', placeholder: 'Ej: Parcial de Física', value: draft.title, 'aria-label': 'Título', maxlength: '80' });
    const date = h('input', { class: 'fld-in', type: 'date', value: draft.date, 'aria-label': 'Fecha' });
    const time = h('input', { class: 'fld-in', type: 'time', step: STEP, value: draft.time != null ? K.hmIn(draft.time) : '', 'aria-label': 'Hora (opcional)' });
    const clear = h('button', { type: 'button', class: 'btn quiet small', onclick: () => { time.value = ''; } }, 'Sin hora');

    const save = () => {
      draft.title = title.value.trim() || 'Sin título';
      if (!date.value) { err.textContent = 'Elegí la fecha del evento.'; return; }
      draft.date = date.value;
      draft.time = toMin(time.value);
      Object.assign(e, draft);
      if (isNew) st.events.push(e);
      K.saveEvent(e);
      close();
      K.refreshAll();
    };

    return [
      h('div', { class: 'sheet-head' }, h('h2', {}, isNew ? 'Nuevo evento' : 'Editar evento'),
        h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Cerrar', svg: icon('x', 18), onclick: close })),
      h('div', { class: 'form' },
        field('Título', title),
        h('div', { class: 'row2' }, field('Fecha', date), field('Hora', h('div', { class: 'timerow' }, time, clear))),
        err),
      h('div', { class: 'sheet-foot' },
        !isNew ? h('button', { type: 'button', class: 'btn quiet danger', onclick: () => { close(); K.removeEvent(e); } }, 'Eliminar') : h('span'),
        h('span', { class: 'grow' }),
        h('button', { type: 'button', class: 'btn', onclick: close }, 'Cancelar'),
        h('button', { type: 'button', class: 'btn primary', onclick: save }, 'Guardar')),
    ];
  }
  K.dayToggles = dayToggles;
  K.openEvent = e => K.modal(close => eventForm(e, !st.events.includes(e), close));
  K.newEvent = () => K.modal(close => eventForm(K.makeEvent(), true, close));

  /* ---------- Fecha legible ---------- */
  K.dayLabel = ds => {
    const [y, m, d] = ds.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    const diff = Math.round((date - new Date(new Date().setHours(0, 0, 0, 0))) / 86400000);
    if (diff === 0) return 'Hoy';
    if (diff === 1) return 'Mañana';
    if (diff === -1) return 'Ayer';
    return DAY_SHORT[(date.getDay() + 6) % 7] + ' ' + d + ' de ' + MONTH_SHORT[m - 1];
  };

  /* ---------- Rutina semanal (grilla 24/7) ---------- */
  /* Asigna carril a cada bloque de un día para que los que se superponen se vean lado a lado */
})();
