/* =========================================================
   metrics.js — Métricas: progreso por objetivo, rutinas y pendientes.
   Usa las sesiones de Foco (minutos y objetivo) y las notas y pendientes.
   Un enfoque de un objetivo (o de un pendiente que pertenece a uno, o de un proyecto) suma a ese objetivo.
   Rutinas (pendientes enlazados a un bloque): cuántas veces tocaban esta semana y cuántas se hicieron.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h } = K;
  const MIN = 60000;
  const WEEKS = 8;

  const addDays = (t, n) => { const d = new Date(t); return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n).getTime(); };
  const dayStart = t => addDays(t, 0);
  const weekStart = t => addDays(dayStart(t), -((new Date(t).getDay() + 6) % 7));
  const hours = min => min >= 60 ? `${(min / 60).toFixed(1).replace('.0', '')} h` : `${Math.round(min)} min`;
  const dateShort = t => new Date(t).toLocaleDateString('es-AR', { day: 'numeric', month: 'numeric' });
  /* Fecha AAAA-MM-DD de un instante (hora local), para comparar con los días de las rutinas */
  const keyOf = t => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

  /* Racha: días seguidos con al menos 5 min de enfoque, terminando hoy (o ayer, si hoy todavía no hubo) */
  const STREAK_MIN = 5 * MIN;
  function streak(sessions) {
    const perDay = new Map();
    sessions.forEach(s => { const d = dayStart(s.end); perDay.set(d, (perDay.get(d) || 0) + s.ms); });
    const days = new Set([...perDay].filter(([, ms]) => ms >= STREAK_MIN).map(([d]) => d));
    let d = dayStart(Date.now());
    if (!days.has(d)) d = addDays(d, -1);
    let n = 0;
    while (days.has(d)) { n++; d = addDays(d, -1); }
    return n;
  }

  K.metricsData = () => {
    const st = K.state, now = Date.now();
    const ws = weekStart(now), today = dayStart(now);
    const sessions = st.sessions;

    const trend = [];
    for (let i = WEEKS - 1; i >= 0; i--) {
      const from = addDays(ws, -7 * i), to = addDays(from, 7);
      const ms = sessions.filter(s => s.end >= from && s.end < to).reduce((n, s) => n + s.ms, 0);
      trend.push({ from, min: ms / MIN });
    }

    const thisWeek = sessions.filter(s => s.end >= ws);
    const weekMin = thisWeek.reduce((n, s) => n + s.ms / MIN, 0);
    const todayMin = sessions.filter(s => s.end >= today).reduce((n, s) => n + s.ms / MIN, 0);

    /* Minutos por objetivo esta semana (un enfoque suma a un solo objetivo) */
    const byGoal = new Map();
    thisWeek.forEach(s => {
      const gid = K.goalOfTarget(s.target);
      if (!gid) return;
      byGoal.set(gid, (byGoal.get(gid) || 0) + s.ms / MIN);
    });
    const goals = [...byGoal.entries()]
      .map(([id, min]) => ({ name: K.goalById(id).name, min, color: K.goalById(id).color ? (K.colorOf(K.goalById(id).color) || {}).hex || null : null }))
      .sort((a, b) => b.min - a.min);

    /* Objetivos más trabajados esta semana */
    const byTarget = new Map();
    thisWeek.forEach(s => {
      const key = s.target ? `${s.target.kind}:${s.target.id || s.target.text}` : 'none';
      const cur = byTarget.get(key) || { name: s.target ? K.targetName(s.target) : 'Sin objetivo', min: 0 };
      cur.min += s.ms / MIN; byTarget.set(key, cur);
    });
    const targets = [...byTarget.values()].sort((a, b) => b.min - a.min).slice(0, 8);

    /* Pendientes sueltos (una vez) y rutinas (por día). Las rutinas hechas cuentan en "hechas". */
    const tasks = K.allTasks();
    const singles = tasks.filter(t => !K.routineBlock(t));
    const wsKey = keyOf(ws), todayKey = keyOf(now);
    const routineDone = tasks.reduce((n, t) => n + Object.keys(t.doneDays || {}).length, 0);
    const routineDoneWeek = tasks.reduce((n, t) => n + Object.keys(t.doneDays || {}).filter(ds => ds >= wsKey).length, 0);

    /* Rutinas esta semana, por bloque: cuántas veces tocaban hasta hoy y cuántas se hicieron */
    const byBlock = new Map();
    K.routineOccurrences(wsKey, todayKey).forEach(({ t, ds }) => {
      const b = K.routineBlock(t);
      const cur = byBlock.get(b.id) || { name: K.blockLabel(b), color: (K.blockColor(b) || {}).hex || null, expected: 0, done: 0 };
      cur.expected++;
      if (K.isDone(t, ds)) cur.done++;
      byBlock.set(b.id, cur);
    });
    const routines = [...byBlock.values()].sort((a, b) => b.expected - a.expected);

    const rated = thisWeek.filter(s => s.q);
    const quality = { bien: 0, medias: 0, distraje: 0, sin: thisWeek.length - rated.length };
    rated.forEach(s => { quality[s.q === 'bien' ? 'bien' : s.q === 'medias' ? 'medias' : 'distraje']++; });

    return {
      weekMin, todayMin, trend, goals, targets, routines, quality,
      streak: streak(sessions),
      sessionsWeek: thisWeek.length,
      notesWeek: st.notes.filter(n => n.createdAt >= ws && K.isLive(n)).length,
      tasksDone: singles.filter(t => t.done).length + routineDone,
      tasksDoneWeek: singles.filter(t => t.done && (t.doneAt || 0) >= ws).length + routineDoneWeek,
      tasksTotal: tasks.length,
    };
  };

  const tile = (v, l) => h('div', { class: 'fx-tile' }, h('b', {}, v), h('span', {}, l));

  K.renderMetrics = root => {
    const m = K.metricsData();
    const maxTrend = Math.max(60, ...m.trend.map(w => w.min));
    const maxGoal = Math.max(1, ...m.goals.map(g => g.min));
    const maxTarget = Math.max(1, ...m.targets.map(t => t.min));
    const rowsOf = (list, max) => h('ul', { class: 'mx-rows' }, list.map(a => h('li', {},
      h('span', { class: 'mx-name' }, a.name),
      h('span', { class: 'mx-track' }, h('span', { class: 'mx-fill', style: `width:${(a.min / max) * 100}%` + (a.color ? `;background:${a.color}` : '') })),
      h('span', { class: 'mx-val' }, hours(a.min)))));
    const maxRoutine = Math.max(1, ...m.routines.map(r => r.expected));
    const routineRows = m.routines.map(r => h('li', {},
      h('span', { class: 'mx-name' }, r.color ? h('span', { class: 'dot', style: `--c:${r.color}` }) : null, ' ', r.name),
      h('span', { class: 'mx-track' }, h('span', { class: 'mx-fill', style: `width:${(r.done / maxRoutine) * 100}%` + (r.color ? `;background:${r.color}` : '') })),
      h('span', { class: 'mx-val' }, `${r.done} de ${r.expected}`)));

    /* Lo principal: el foco de la semana. Después, dos números de apoyo. */
    root.append(h('div', { class: 'mx-hero' }, h('b', {}, hours(m.weekMin)), h('span', {}, 'de foco esta semana')));
    const q = m.quality;
    if (q.bien + q.medias + q.distraje) root.append(h('p', { class: 'mx-quality hint' },
      `Cómo fueron tus enfoques: ${q.bien} bien · ${q.medias} a medias · ${q.distraje} me distraje` + (q.sin ? ` · ${q.sin} sin calificar` : '')));
    root.append(h('div', { class: 'fx-tiles mx-tiles' },
      tile(String(m.streak), m.streak === 1 ? 'Día de racha' : 'Días de racha'),
      tile(String(m.tasksDoneWeek), 'Pendientes hechas esta semana'),
      tile(String(m.notesWeek), m.notesWeek === 1 ? 'Nota nueva esta semana' : 'Notas nuevas esta semana')));

    root.append(h('div', { class: 'mx-grid' },
      h('section', { class: 'fx-card' },
        h('h3', {}, 'Tendencia de foco (8 semanas)'),
        m.trend.every(w => !w.min)
          ? h('p', { class: 'fx-empty' }, 'Todavía no hay enfoques registrados. Arrancá uno en Foco.')
          : h('div', { class: 'fx-bars mx-trend', role: 'img', 'aria-label': 'Minutos de enfoque por semana' }, m.trend.map((w, i) => h('div', {
              class: 'fx-bar' + (i === m.trend.length - 1 ? ' today' : ''),
              title: `Semana del ${dateShort(w.from)}: ${hours(w.min)}`,
            },
              h('span', { class: 'fx-bar-m' }, w.min ? hours(w.min) : ''),
              h('span', { class: 'fx-bar-track' }, h('span', { class: 'fx-bar-fill', style: `height:${w.min ? Math.max(6, (w.min / maxTrend) * 100) : 3}%` })),
              h('span', { class: 'fx-bar-d' }, dateShort(w.from)))))),

      h('section', { class: 'fx-card' },
        h('h3', {}, 'Objetivos esta semana'),
        m.goals.length
          ? rowsOf(m.goals, maxGoal)
          : h('p', { class: 'fx-empty' }, 'Enfocá en un objetivo (desde Foco o desde su página) para verlo acá.')),

      h('section', { class: 'fx-card' },
        h('h3', {}, 'Rutinas esta semana'),
        m.routines.length
          ? h('ul', { class: 'mx-rows' }, routineRows)
          : h('p', { class: 'fx-empty' }, 'Enlazá un pendiente a un bloque de tu calendario (botón Rutina en Hoy) para ver cómo vas.')),

      m.targets.length
        ? h('section', { class: 'fx-card' }, h('h3', {}, 'Lo más trabajado'), rowsOf(m.targets, maxTarget))
        : null));
  };
})();
