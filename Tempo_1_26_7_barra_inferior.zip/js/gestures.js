/* =========================================================
   gestures.js — gestos táctiles livianos (sin librerías).
   · K.swipe(el, { onMove(dx), onEnd(dx, vx), canStart(x) })
       Arrastre horizontal con bloqueo de dirección: si el dedo se mueve más
       en vertical, el gesto no es nuestro y el scroll de la página sigue normal.
   · K.initEdgeSwipe()
       Celular: deslizar hacia la derecha desde la zona en blanco de la mitad
       inferior de la pantalla abre la barra lateral; con la barra abierta,
       deslizar hacia la izquierda la cierra. No cuentan los toques sobre cards,
       textos editables, botones, campos ni el calendario.
   Solo cambian clases y transformaciones; no tocan los datos.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  const LOCK_PX = 8;          // movimiento mínimo antes de decidir la dirección
  // Elementos donde el gesto no cuenta (cards, textos, botones, calendario, formularios)
  const NOT_BLANK = 'input,textarea,select,button,a,label,[contenteditable],[role=dialog],[role=textbox],[role=tab],' +
    '.sheet,.ed-back,.backdrop,.cap,.today-sec,.today-week,.hoy-days,.hoy-day,.tf,.task-group,.task-list,.card,.lcard,.lcards,.row,.ev-row,' +
    '.wk-swipe,.ed-doc,.cal-tabs,.daytabs,.chip,.fx-step,.fx-ctl,.fx-presets,.fx-modes,.ed-card,.note-list';
  const onBlank = el => !!el && !(el.closest && el.closest(NOT_BLANK));

  /* Arrastre horizontal sobre un elemento */
  K.swipe = (el, o = {}) => {
    let x0 = 0, y0 = 0, t0 = 0, dx = 0, mode = null;   // mode: null | 'h' | 'v' | 'skip'
    el.addEventListener('touchstart', e => {
      if (e.touches.length !== 1) { mode = 'skip'; return; }
      const t = e.touches[0];
      x0 = t.clientX; y0 = t.clientY; t0 = Date.now(); dx = 0; mode = null;
      if (o.canStart && !o.canStart(x0)) mode = 'skip';
    }, { passive: true });

    el.addEventListener('touchmove', e => {
      if (mode === 'skip' || mode === 'v' || e.touches.length !== 1) return;
      const t = e.touches[0];
      const ddx = t.clientX - x0, ddy = t.clientY - y0;
      if (mode === null) {
        if (Math.abs(ddx) < LOCK_PX && Math.abs(ddy) < LOCK_PX) return;
        mode = Math.abs(ddx) > Math.abs(ddy) ? 'h' : 'v';
        if (mode === 'v') return;
      }
      dx = ddx;
      o.onMove && o.onMove(dx);
      if (e.cancelable) e.preventDefault();      // mientras arrastrás de costado, no rebota la página
    }, { passive: false });

    el.addEventListener('touchend', () => {
      if (mode !== 'h') { mode = null; return; }
      const vx = dx / Math.max(1, Date.now() - t0);            // px por ms
      mode = null;
      o.onEnd && o.onEnd(dx, vx);
    }, { passive: true });

    el.addEventListener('touchcancel', () => {
      if (mode === 'h') o.onEnd && o.onEnd(0, 0);
      mode = null;
    }, { passive: true });
  };

  /* Barra lateral: en la zona en blanco de la mitad inferior, deslizar a la derecha la abre;
     con la barra abierta, deslizar a la izquierda la cierra. Semi-horizontal también cuenta. */
  K.initEdgeSwipe = () => {
    let x0 = 0, y0 = 0, lx = 0, ly = 0, mode = null;
    document.addEventListener('touchstart', e => {
      if (!K.isMobile() || e.touches.length !== 1) { mode = null; return; }
      const t = e.touches[0];
      x0 = lx = t.clientX; y0 = ly = t.clientY;
      const open = document.body.classList.contains('nav-open');
      const tgt = e.target;
      if (open) mode = (tgt && tgt.closest && tgt.closest('.side')) || onBlank(tgt) ? 'close' : null;
      else mode = onBlank(tgt) && y0 >= window.innerHeight / 2 ? 'open' : null;
    }, { passive: true });

    document.addEventListener('touchmove', e => {
      if (!mode || e.touches.length !== 1) return;
      lx = e.touches[0].clientX; ly = e.touches[0].clientY;
    }, { passive: true });

    document.addEventListener('touchend', () => {
      if (!mode || !K.isMobile()) { mode = null; return; }
      const dx = lx - x0, dy = Math.abs(ly - y0);
      // Semi-horizontal: el recorrido horizontal domina (hasta ~42° de inclinación)
      const horizontal = Math.abs(dx) > 64 && dy <= Math.abs(dx) * 0.9;
      if (mode === 'open' && horizontal && dx > 0) document.body.classList.add('nav-open');
      if (mode === 'close' && horizontal && dx < 0) document.body.classList.remove('nav-open');
      mode = null;
    }, { passive: true });
  };
})();
