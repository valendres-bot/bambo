/* =========================================================
   views.js — pantallas de módulos que no son notas.
   · Foco: temporizador Pomodoro (focus.js y focusui.js).
   · Calendario y eventos: schedule.js.
   · Métricas: metrics.js.  · Pendientes: today.js (casillas en tasks.js).
   · Objetivos: goalsui.js (datos en goals.js).
   · Configuración: settings.js.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;

  K.renderModule = (root, r) => {
    const info = K.routeInfo(r);
    const banner = K.backupBanner && K.backupBanner();
    if (banner) root.append(banner);
    if (r.name === 'goals') return K.renderGoals(root);      // estas dos pantallas arman su propio encabezado
    if (r.name === 'goal') return K.renderGoal(root, r);
    root.append(h('div', { class: 'page-head' },
      h('h1', { class: 'page-title' }, h('span', { class: 'page-ico', svg: icon(info.icon, 26) }), info.title),
      h('p', { class: 'page-sub' }, MODULE_SUB[r.name])));

    if (r.name === 'focus') return K.renderFocus(root);
    if (r.name === 'settings') return K.renderSettings(root);
    if (r.name === 'metrics') return K.renderMetrics(root);
    if (r.name === 'today') return K.renderToday(root);
  };

  const MODULE_SUB = {
    focus: 'Estudiá en bloques de enfoque y mirá cuánto avanzás cada día.',
    metrics: 'Cómo va tu progreso en cada objetivo y en cada área de tu vida.',
    today: 'Lo que tenés que hacer hoy, y cuánto tiempo le dedicás.',
    settings: 'Preferencias, foco, datos guardados en este navegador y la versión de Tempo.',
  };
})();
