/* =========================================================
   dom.js — helpers de DOM, íconos, fechas y búsqueda.
   Todo el proyecto cuelga de un único objeto global: K.
   (Scripts clásicos, sin build: funciona abriendo index.html directo.)
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});

  K.$ = (s, root = document) => root.querySelector(s);
  K.$$ = (s, root = document) => [...root.querySelectorAll(s)];
  K.uid = () => (window.crypto && crypto.randomUUID
    ? crypto.randomUUID()
    : Date.now().toString(36) + Math.random().toString(16).slice(2));
  K.fit = t => { t.style.height = 'auto'; t.style.height = t.scrollHeight + 'px'; };
  K.isTouch = () => !!(window.matchMedia && matchMedia('(hover: none)').matches);
  K.isMobile = () => window.innerWidth < 860;

  /* Crea elementos: h('div', {class:'x', onclick: fn}, ...hijos) */
  K.h = function h(tag, props = {}, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') el.className = v;
      else if (k === 'svg') el.innerHTML = v; // solo íconos fijos de K.icon (SVG confiable)
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else if (v !== false && v != null) el.setAttribute(k, v);
    }
    for (const k of kids.flat()) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(k));
    return el;
  };

  K.ago = function (ts) {
    const s = (Date.now() - ts) / 1000;
    if (s < 60) return 'ahora';
    const m = s / 60; if (m < 60) return `hace ${Math.floor(m)} min`;
    const hr = m / 60; if (hr < 24) return `hace ${Math.floor(hr)} h`;
    const d = hr / 24; if (d < 2) return 'ayer'; if (d < 7) return `hace ${Math.floor(d)} d`;
    return new Date(ts).toLocaleDateString('es-AR', { day: 'numeric', month: 'short' }).replace('.', '');
  };

  /* ---------- Búsqueda: sin mayúsculas ni acentos ---------- */
  const DIACRITICS = /[̀-ͯ]/g;
  K.norm = s => String(s).normalize('NFD').replace(DIACRITICS, '').toLowerCase();
  /* Cada palabra de la búsqueda debe aparecer (en cualquier orden) */
  K.tokens = q => K.norm(q).trim().split(/\s+/).filter(Boolean);
  K.matchAll = (text, tokens) => { if (!tokens.length) return true; const t = K.norm(text); return tokens.every(k => t.includes(k)); };
  /* Igual que matchAll, con un texto ya normalizado (K.searchNorm) */
  K.matchNorm = (norm, tokens) => !tokens.length || tokens.every(k => norm.includes(k));

  /* Resalta coincidencias. Mapea cada posición del texto normalizado al original,
     así los acentos no corren los índices. Devuelve nodos (nunca innerHTML). */
  K.hl = (text, query) => {
    const tokens = K.tokens(query);
    if (!tokens.length || !text) return text;
    let norm = '';
    const map = [];
    for (let i = 0; i < text.length; i++) {
      const part = text[i].normalize('NFD').replace(DIACRITICS, '').toLowerCase();
      for (let j = 0; j < part.length; j++) { norm += part[j]; map.push(i); }
    }
    const ranges = [];
    tokens.forEach(tk => {
      let at = norm.indexOf(tk);
      while (at >= 0) {
        ranges.push([map[at], map[at + tk.length - 1] + 1]);
        at = norm.indexOf(tk, at + tk.length);
      }
    });
    if (!ranges.length) return text;
    ranges.sort((a, b) => a[0] - b[0]);
    const merged = [];
    ranges.forEach(r => {
      const last = merged[merged.length - 1];
      if (last && r[0] <= last[1]) last[1] = Math.max(last[1], r[1]); else merged.push([...r]);
    });
    const out = [];
    let pos = 0;
    merged.forEach(([s, e]) => {
      if (s > pos) out.push(text.slice(pos, s));
      out.push(K.h('mark', {}, text.slice(s, e)));
      pos = e;
    });
    if (pos < text.length) out.push(text.slice(pos));
    return out;
  };

  /* ---------- Íconos (SVG de trazo, 24x24) ---------- */
  K.ICONS = {
    sidebar: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9.5 4v16"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    file: '<path d="M6.5 3h7l4.5 4.5V20a1 1 0 01-1 1h-10.5a1 1 0 01-1-1V4a1 1 0 011-1z"/><path d="M13.5 3v5H18M9 13h6M9 17h6"/>',
    inbox: '<path d="M3 13.5L6 5.5h12l3 8V19a1 1 0 01-1 1H4a1 1 0 01-1-1z"/><path d="M3 13.5h5l1 2.5h6l1-2.5h5"/>',
    pin: '<path d="M12 16.5V22M8 3h8l-1 6 3 4.5H6L9 9z"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
    restore: '<path d="M4 12a8 8 0 108-8 8 8 0 00-5.7 2.4M4 4v4h4M12 8v4l3 2"/>',
    archive: '<path d="M3.5 5.5h17v4h-17zM5 9.5V19a1 1 0 001 1h12a1 1 0 001-1V9.5M10 13.5h4"/>',
    unarchive: '<path d="M3.5 5.5h17v4h-17zM5 9.5V19a1 1 0 001 1h12a1 1 0 001-1V9.5M12 17v-5M9.5 14l2.5-2.5 2.5 2.5"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>',
    moon: '<path d="M20 14.5A8 8 0 019.5 4a8 8 0 1010.5 10.5z"/>',
    monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
    more: '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
    rows: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
    sort: '<path d="M8 5v14M8 19l-3-3M8 19l3-3M16 19V5M16 5l-3 3M16 5l3 3"/>',
    target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>',
    checklist: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8.5 12.5l2.5 2.5 4.5-5.5"/>',
    text: '<path d="M5 7h14M5 12h14M5 17h9"/>',
    tone: '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5a8.5 8.5 0 010 17z" fill="currentColor"/>',
    anchor: '<path d="M7 4h10a1 1 0 011 1v15l-6-4-6 4V5a1 1 0 011-1z"/>',
    link: '<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"/>',
    heading: '<path d="M5 6v12M19 6v12M5 12h14"/>',
    ref: '<path d="M9 5H6.5A1.5 1.5 0 005 6.5v11A1.5 1.5 0 006.5 19H9M15 5h2.5A1.5 1.5 0 0119 6.5v11a1.5 1.5 0 01-1.5 1.5H15"/>',
    book: '<path d="M4 5.5a2 2 0 012-2h13v15H6a2 2 0 00-2 2zM4 5.5v15"/><path d="M8 8.5h7M8 12h5"/>',
    tag: '<path d="M3.5 12.2V4.5a1 1 0 011-1h7.7a1 1 0 01.7.3l8 8a1 1 0 010 1.4l-7.3 7.3a1 1 0 01-1.4 0l-8-8a1 1 0 01-.3-.7z"/><circle cx="8" cy="8" r="1.4"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    today: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/><path d="M8.5 15.5l2.3 2.3 4.7-4.7"/>',
    timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 10v3.8l2.4 1.6M9.5 2.5h5"/>',
    chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    play: '<path d="M8 5.5v13l10.5-6.5z" fill="currentColor"/>',
    pause: '<path d="M8.5 5.5v13M15.5 5.5v13"/>',
    reset: '<path d="M4 12a8 8 0 108-8 8 8 0 00-5.7 2.4M4 4v4h4"/>',
    skip: '<path d="M5 6l8 6-8 6zM19 6v12"/>',
    download: '<path d="M12 4v11M7.5 11L12 15.5 16.5 11M5 20h14"/>',
    upload: '<path d="M12 15V4M7.5 8L12 3.5 16.5 8M5 20h14"/>',
    chevron: '<path d="M9.5 6l6 6-6 6"/>',
    up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
    bold: '<path d="M7 5h6a3.5 3.5 0 010 7H7zM7 12h7.5a3.5 3.5 0 010 7H7z"/>',
    italic: '<path d="M10 5h7M7 19h7M14.5 5l-5 14"/>',
    highlight: '<path d="M4 20h16M14.5 4.5l5 5-8 8H7v-4.5z"/>',
    list: '<circle cx="5.5" cy="7" r="1" fill="currentColor"/><circle cx="5.5" cy="12" r="1" fill="currentColor"/><circle cx="5.5" cy="17" r="1" fill="currentColor"/><path d="M10 7h10M10 12h10M10 17h10"/>',
    undo: '<path d="M8 6L4 10l4 4M4 10h10a6 6 0 010 12h-3"/>',
    redo: '<path d="M16 6l4 4-4 4M20 10H10a6 6 0 000 12h3"/>',
    card: '<rect x="3.5" y="6" width="17" height="12" rx="2.5"/><path d="M7.5 11h6M7.5 14.5h4"/>',
    copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M15.5 8.5V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7.5a2 2 0 002 2h2.5"/>',
    cut: '<circle cx="6.5" cy="17" r="2.5"/><circle cx="17.5" cy="17" r="2.5"/><path d="M8.2 15.2L18 4M15.8 15.2L6 4"/>',
    paste: '<rect x="5" y="5" width="14" height="16" rx="2.5"/><path d="M9 5V4h6v1M9 12h6M9 16h4"/>',
    external: '<path d="M14 4h6v6M20 4l-8 8M18 14v4a2 2 0 01-2 2H6a2 2 0 01-2-2V8a2 2 0 012-2h4"/>',
    unlink: '<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1M4 4l16 16"/>',
    edit: '<path d="M4 20h4L19 9a2.1 2.1 0 00-3-3L5 17z"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  };
  K.icon = (name, size = 18) =>
    `<svg class="ico" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${K.ICONS[name]}</svg>`;
  K.iconBtn = (name, title, onclick, extra = '') =>
    K.h('button', { class: ('icon-btn ' + extra).trim(), type: 'button', title, 'aria-label': title, svg: K.icon(name), onclick });
})();
