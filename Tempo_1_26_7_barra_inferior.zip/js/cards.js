/* =========================================================
   cards.js — cards de enlaces y el selector para crearlos.
   · K.linkSearch: caja única para pegar una dirección o buscar una
     nota o etiqueta. La usan "Enlazar" (dentro del texto) y "Card".
   · K.linkCards: fila de cards de una nota o etiqueta. Sin botón de
     agregar dentro de la nota: se agregan desde la barra, pegando una
     dirección en una línea vacía o arrastrando un enlace.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;

  /* "ejemplo.com/ruta" o "https://…" → dirección completa; si no parece una, null */
  K.normUrl = s => {
    const t = String(s || '').trim();
    if (/^https?:\/\/\S+$/i.test(t)) return t;
    if (/^(?:[a-z0-9-]+\.)+[a-z]{2,}(?:[/?#]\S*)?$/i.test(t)) return 'https://' + t;
    return null;
  };

  /* ---------- Selector ----------
     opts: { card, exclude: noteId, skip: () => [ids], only: 'notes',
             keepOpen, autofocus, onPick(res, title), placeholder }
     only:'notes' → solo notas (sin direcciones ni etiquetas), para formularios.
     keepOpen → no cierra al elegir; deja la caja lista para otra búsqueda.
     res: { url } | { kind: 'note'|'label', id, name } */
  K.linkSearch = (opts = {}) => {
    const notesOnly = opts.only === 'notes';
    const box = h('div', { class: 'lp-link' });
    const input = h('input', {
      class: 'lp-input', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Enlace, nota o etiqueta',
      placeholder: opts.placeholder || 'Pegá un enlace o buscá una nota o etiqueta',
    });
    const title = opts.card ? h('input', { class: 'lp-input', autocomplete: 'off', placeholder: 'Título de la card (opcional)', 'aria-label': 'Título' }) : null;
    const list = h('div', { class: 'lp-list', role: 'listbox' });
    let items = [], sel = 0;

    const collect = () => {
      const q = input.value.trim(), tk = K.tokens(q), out = [];
      const skip = (opts.skip && opts.skip()) || [];
      const url = notesOnly ? null : K.normUrl(q);
      if (url) out.push({ ic: 'link', label: 'Enlace a ' + url, sub: K.domainOf(url), res: { url } });
      K.state.notes.filter(n => K.isLive(n) && n.id !== opts.exclude && !skip.includes(n.id) && n.title.trim() && K.matchAll(n.title, tk))
        .sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 6)
        .forEach(n => out.push({ ic: 'file', label: n.title, sub: 'Nota', res: { kind: 'note', id: n.id, name: n.title.trim() } }));
      if (tk.length && !notesOnly) K.activeLabels().filter(l => K.matchAll(l.name, tk)).slice(0, 5)
        .forEach(l => out.push({ ic: 'tag', label: l.name, sub: 'Etiqueta', res: { kind: 'label', id: l.id, name: l.name } }));
      return out;
    };
    const pick = it => {
      if (!it) return;
      if (!opts.keepOpen) K.closePop();
      opts.onPick && opts.onPick(it.res, title ? title.value.trim() : '');
      if (opts.keepOpen) { input.value = ''; if (title) title.value = ''; sel = 0; draw(); input.focus(); }
    };
    const draw = () => {
      items = collect();
      sel = Math.min(sel, Math.max(0, items.length - 1));
      list.replaceChildren(...(items.length ? items.map((it, i) => h('button', {
        type: 'button', class: 'menu-item lp-row', role: 'option', 'aria-selected': String(i === sel),
        onmousedown: e => e.preventDefault(), onclick: () => pick(it),
        onmouseenter: () => { sel = i; mark(); },
      }, h('span', { class: 'mi', svg: icon(it.ic, 16) }), h('span', { class: 'mlbl' }, it.label), h('span', { class: 'lp-sub' }, it.sub)))
        : [h('div', { class: 'lp-none' }, input.value.trim()
          ? (notesOnly ? 'Ninguna nota coincide' : 'No hay coincidencias. Pegá una dirección completa.')
          : 'Todavía no hay otras notas.')]));
    };
    const mark = () => [...list.children].forEach((el, i) => el.setAttribute('aria-selected', String(i === sel)));
    input.addEventListener('input', () => { sel = 0; draw(); });
    [input, title].filter(Boolean).forEach(el => el.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(items.length - 1, sel + 1); mark(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); mark(); }
      else if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); pick(items[sel]); }
    }));
    box.append(input, title, list);
    draw();
    if (opts.autofocus !== false) setTimeout(() => input.focus(), 0);
    return box;
  };

  /* Una card nueva a partir de lo que devuelve el selector */
  K.cardFrom = (res, title) => res.url
    ? { id: K.uid(), title: title || K.domainOf(res.url), url: res.url }
    : { id: K.uid(), title: title || res.name || 'Sin título', target: { kind: res.kind, id: res.id } };

  /* ---------- Cards ---------- */
  function targetRef(l) {
    const t = l.target;
    if (!t) return null;
    if (t.kind === 'note') { const n = K.noteById(t.id); return n && K.isLive(n) ? { kind: 'note', item: n } : null; }
    const lb = K.labelById(t.id);
    return lb ? { kind: 'label', item: lb } : null;
  }

  /* Formulario para editar el título (y la dirección) de una card */
  function editForm(l, done) {
    const t = h('input', { class: 'lp-input', value: l.title || '', placeholder: 'Título', 'aria-label': 'Título' });
    const u = l.url != null ? h('input', { class: 'lp-input', value: l.url, placeholder: 'https://…', 'aria-label': 'Dirección', spellcheck: 'false' }) : null;
    const save = () => {
      if (u) { const nu = K.normUrl(u.value); if (!nu) { u.focus(); return; } l.url = nu; }
      l.title = t.value.trim() || (l.url ? K.domainOf(l.url) : l.title);
      K.closePop(); done();
    };
    [t, u].filter(Boolean).forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } }));
    setTimeout(() => t.focus(), 0);
    return h('div', { class: 'lp-link' }, t, u, h('div', { class: 'lp-acts' }, h('button', { class: 'btn', type: 'button', onclick: save }, 'Guardar')));
  }

  /* Debajo del título: el sitio, o la ruta si el título ya es el sitio */
  const subUrl = l => {
    const d = K.domainOf(l.url);
    if (l.title && l.title !== d) return d;
    const rest = l.url.replace(/^https?:\/\/(www\.)?/i, '').replace(/\/$/, '');
    return rest === d ? 'Enlace' : rest;
  };

  function cardEl(l0, i, owner, redraw) {
    const l = l0.url && !K.safeUrl(l0.url) ? { ...l0, url: '' } : l0;      // un enlace que no es http(s) no se abre
    const ref = l.url ? null : targetRef(l);
    const ic = l.url ? 'link' : (l.target && l.target.kind === 'label' ? 'tag' : 'file');
    const body = [
      h('span', { class: 'lc-ico', svg: icon(ic, 16) }),
      h('span', { class: 'lc-text' },
        h('span', { class: 'lc-title' }, l.title || (ref ? (ref.kind === 'note' ? ref.item.title : ref.item.name) : 'Sin destino') || 'Sin título'),
        h('span', { class: 'lc-sub' }, l.url ? subUrl(l) : (ref ? (ref.kind === 'note' ? 'Nota' : 'Etiqueta') : 'No encontrado'))),
    ];
    const main = l.url
      ? h('a', { class: 'lc-main', href: l.url, target: '_blank', rel: 'noopener noreferrer', title: l.url }, body)
      : h('button', { class: 'lc-main', type: 'button', disabled: ref ? null : '', onclick: e => { e.stopPropagation(); K.openRef(ref); } }, body);
    const more = h('button', { class: 'lc-more', type: 'button', 'aria-label': 'Opciones de la card', title: 'Opciones', svg: icon('more', 16) });
    more.addEventListener('click', e => {
      e.stopPropagation();
      K.togglePop(more, () => K.menu([
        { label: 'Editar', icon: 'edit', keep: true, run: () => K.openPop(more, editForm(l, () => { redraw(true); })) },
        ...(l.url ? [{ label: 'Copiar enlace', icon: 'copy', run: () => { try { navigator.clipboard.writeText(l.url); K.toast('Enlace copiado'); } catch { /* sin portapapeles */ } } }] : []),
        '-',
        { label: 'Color del borde', icon: 'tone', keep: true, run: () => K.openPop(more, K.colorPicker(l.color, id => { l.color = id; redraw(true); })) },
        '-',
        { label: 'Quitar card', icon: 'trash', run: () => { owner.links.splice(i, 1); redraw(true); } },
      ]));
    });
    const col = K.colorOf(l.color);                                  // borde de color opcional (solo cards de etiquetas)
    return h('div', { class: 'lcard' + (col ? ' has-c' : ''), style: col ? `--lc:${col.hex}` : null, role: 'listitem' }, main, more);
  }

  /* owner: nota o etiqueta (usa owner.links). opts.addable: muestra un "+" discreto (páginas de etiqueta) */
  K.linkCards = (owner, changed, opts = {}) => {
    if (!Array.isArray(owner.links)) owner.links = [];
    const box = h('div', { class: 'lcards-box' });
    const addHere = () => K.togglePop(plus, () => K.linkSearch({ card: true, onPick: (res, t) => { box.add(res, t); } }));
    const plus = h('button', { class: 'lc-plus', type: 'button', title: 'Agregar card', 'aria-label': 'Agregar card', svg: icon('plus', 16), onclick: addHere });
    const hint = h('button', { class: 'lc-hint-btn', type: 'button', onclick: addHere }, h('span', { svg: icon('plus', 14) }), 'Agregar enlace');

    function draw(notify) {
      if (notify) changed();
      const has = owner.links.length > 0;
      box.hidden = !has && !opts.addable;
      box.classList.toggle('is-empty', !has);
      box.replaceChildren(...(has
        ? [h('div', { class: 'lcards', role: 'list' }, owner.links.map((l, i) => cardEl(l, i, owner, draw)), opts.addable ? plus : null)]
        : (opts.addable ? [hint] : [])));
      if (!has && opts.addable) hint.replaceWith(hint);
    }
    box.add = (res, title) => { owner.links = [...owner.links, K.cardFrom(res, title)]; draw(true); };
    box.addUrl = url => { const l = K.cardFrom({ url }); owner.links = [...owner.links, l]; draw(true); return l; };
    box.removeLast = () => { owner.links = owner.links.slice(0, -1); draw(true); };
    box.redraw = () => draw(false);
    draw(false);
    return box;
  };
})();
