/* =========================================================
   focusui.js — la pantalla Foco: anillo de progreso, etapas,
   "en qué trabajás", estadísticas de hoy y de la semana, y ajustes
   de duración. El motor está en focus.js.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;
  const st = K.state;
  const P = K.pomo;

  const R = 112, C = 2 * Math.PI * R;                 // anillo
  const PRESETS = [[25, 5, 15], [50, 10, 20], [15, 3, 10]];
  const DAYS = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  let settingsOpen = false;

  const mins = m => {
    if (m > 0 && m < 1) return `${Math.max(1, Math.round(m * 60))} s`;
    m = Math.round(m);
    if (m < 60) return `${m} min`;
    return `${Math.floor(m / 60)} h${m % 60 ? ' ' + (m % 60) + ' min' : ''}`;
  };
  const clock = ts => new Date(ts).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', hour12: false });

  /* ---------- A qué vas a dedicar el enfoque ---------- */
  function routineNow() {
    const d = new Date(), m = d.getHours() * 60 + d.getMinutes();
    return K.occurrencesOn(st.blocks, K.todayYmd()).find(b => b.start <= m && m < b.end) || null;
  }
  function targetPicker() {
    const box = h('div', { class: 'lp-link' });
    const input = h('input', { class: 'lp-input', autocomplete: 'off', placeholder: 'Una nota, etiqueta, evento… o escribí un tema', 'aria-label': 'En qué vas a trabajar' });
    const list = h('div', { class: 'lp-list', role: 'listbox' });
    let items = [], sel = 0;
    const pick = it => { if (!it) return; K.closePop(); K.setTarget(it.t); };

    const collect = () => {
      const q = input.value.trim(), tk = K.tokens(q), out = [];
      const now = routineNow();
      if (now && !q) out.push({ ic: 'calendar', label: now.title || 'Bloque sin título', sub: 'Ahora en tu rutina', t: { kind: 'block', id: now.id } });
      /* Sin texto: lo que hay que hacer hoy, primero (1.25.1.3). Un clic y el enfoque ya tiene tarea. */
      if (!q) K.todayTasks().filter(t => K.daysUntil(t.due) <= 0).sort(K.byDue).slice(0, 3)
        .forEach(t => out.push({ ic: 'checklist', label: t.text, sub: K.daysUntil(t.due) < 0 ? 'Vencida' : 'Para hoy',
          t: { kind: 'task', id: t.id, text: t.text, goalId: t.goalId || null } }));
      const today = new Date(new Date().setHours(0, 0, 0, 0));
      st.events.filter(e => {
        const [y, mo, d] = e.date.split('-').map(Number);
        const diff = (new Date(y, mo - 1, d) - today) / 86400000;
        return diff >= 0 && diff <= 21 && K.matchAll(e.title, tk);
      }).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4)
        .forEach(e => out.push({ ic: 'clock', label: e.title, sub: K.dayLabel(e.date), t: { kind: 'event', id: e.id } }));
      st.notes.filter(n => K.isLive(n) && n.title.trim() && K.matchAll(n.title, tk))
        .sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 5)
        .forEach(n => out.push({ ic: 'file', label: n.title, sub: 'Nota', t: { kind: 'note', id: n.id } }));
      K.state.goals.filter(g => !g.archived && K.matchAll(g.name, tk)).slice(0, 4)
        .forEach(g => out.push({ ic: 'target', label: g.name, sub: 'Objetivo', t: { kind: 'goal', id: g.id } }));
      if (q) out.push({ ic: 'text', label: `Usar “${q}”`, sub: 'Texto libre', t: { kind: 'text', text: q } });
      return out;
    };
    const mark = () => [...list.children].forEach((el, i) => el.setAttribute('aria-selected', String(i === sel)));
    const draw = () => {
      items = collect();
      sel = Math.min(sel, Math.max(0, items.length - 1));
      list.replaceChildren(...(items.length ? items.map((it, i) => h('button', {
        type: 'button', class: 'menu-item lp-row', role: 'option', 'aria-selected': String(i === sel),
        onclick: () => pick(it), onmouseenter: () => { sel = i; mark(); },
      }, h('span', { class: 'mi', svg: icon(it.ic, 16) }), h('span', { class: 'mlbl' }, it.label), h('span', { class: 'lp-sub' }, it.sub)))
        : [h('div', { class: 'lp-none' }, 'Escribí un tema para usarlo como objetivo.')]));
    };
    input.addEventListener('input', () => { sel = 0; draw(); });
    input.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(items.length - 1, sel + 1); mark(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); mark(); }
      else if (e.key === 'Enter') { e.preventDefault(); pick(items[sel]); }
    });
    box.append(input, list);
    draw();
    setTimeout(() => input.focus(), 0);
    return box;
  }

  function openTarget(t) {
    if (t.kind === 'note') { const n = K.noteById(t.id); if (n && K.isLive(n)) K.openNote(n); else K.toast('Esa nota ya no existe'); }
    else if (t.kind === 'label') { if (K.labelById(t.id)) K.go({ name: 'label', id: t.id }); else K.toast('Esa etiqueta ya no existe'); }
    else if (t.kind === 'text' && t.noteId) { const n = K.noteById(t.noteId); if (n && K.isLive(n)) K.openNote(n); else K.toast('Esa nota ya no existe'); }
    else if (t.kind === 'event' || t.kind === 'block') K.go({ name: 'today' });
    else if (t.kind === 'goal') { if (K.goalById(t.id)) K.go({ name: 'goal', id: t.id }); else K.toast('Ese objetivo ya no existe'); }
    else if (t.kind === 'project') { const f = K.findProject(t.id); if (f) K.go({ name: 'goal', id: f.goal.id }); else K.toast('Ese proyecto ya no existe'); }
  }

  function targetBox() {
    const t = P.target;
    if (t) {
      const openable = t.kind !== 'text' || !!t.noteId;   // una tarea (texto) abre su nota
      return h('div', { class: 'fx-target on' },
        h('span', { class: 'fx-t-ic', svg: icon({ note: 'file', label: 'tag', event: 'clock', block: 'calendar', text: 'text', task: 'check', goal: 'target', project: 'target' }[t.kind] || 'file', 16) }),
        h('button', { class: 'fx-t-name', type: 'button', title: openable ? 'Abrir' : '', disabled: openable ? null : '', onclick: () => openable && openTarget(t) }, K.targetName(t)),
        h('button', { class: 'fx-t-btn', id: 'fxChange', type: 'button', onclick: e => K.togglePop(e.currentTarget, targetPicker) }, 'Cambiar'),
        K.iconBtn('x', 'Quitar objetivo', () => K.setTarget(null), 'fx-t-x'));
    }
    const now = routineNow();
    return h('div', { class: 'fx-target' },
      h('button', { class: 'fx-t-add', id: 'fxChange', type: 'button', onclick: e => K.togglePop(e.currentTarget, targetPicker) },
        h('span', { svg: icon('plus', 16) }), '¿En qué vas a trabajar?'),
      now ? h('button', { class: 'fx-t-sug', type: 'button', onclick: () => K.setTarget({ kind: 'block', id: now.id }) },
        h('span', { svg: icon('calendar', 14) }), `Ahora: ${now.title || 'tu rutina'}`) : null);
  }

  /* Avisos al terminar: el navegador pide permiso solo cuando la persona lo elige, con esta explicación antes */
  function notifRow() {
    if (!('Notification' in window)) return null;
    const p = Notification.permission;
    const text = p === 'granted'
      ? 'Avisos activados: te avisamos cuando termina un enfoque o una pausa, aunque estés en otra pantalla.'
      : p === 'denied'
        ? 'Los avisos están bloqueados en el navegador. Podés permitirlos desde el ícono de candado de la barra de direcciones.'
        : 'Te avisamos cuando termina un enfoque o una pausa, aunque estés en otra pantalla. El navegador va a pedir permiso; podés cambiarlo cuando quieras.';
    return h('div', { class: 'fx-notif' }, h('p', { class: 'hint form-hint' }, text),
      p === 'default' ? h('button', { type: 'button', class: 'btn small', onclick: async () => {
        try { await Notification.requestPermission(); } catch { /* sin soporte */ }
        K.refreshAll();
      } }, 'Permitir avisos') : null);
  }
  function settings() {
    const cur = [K.POMO.focus, K.POMO.short, K.POMO.long].map(x => Math.round(x / 60000));
    const box = h('details', { class: 'fx-set', open: settingsOpen ? '' : null },
      h('summary', {}, h('span', { svg: icon('timer', 16) }), 'Duraciones'),
      h('div', { class: 'fx-set-body' },
        h('div', { class: 'fx-presets', role: 'group', 'aria-label': 'Combinaciones' }, PRESETS.map(p => h('button', {
          type: 'button', disabled: P.running ? '' : null, 'data-p': p.join(','),
          'aria-pressed': String(p.every((v, i) => v === cur[i])),
          onclick: () => { K.setPreset(...p); K.focusPaint(false); },
        }, `${p[0]} · ${p[1]} · ${p[2]}`))),
        h('p', { class: 'hint form-hint' }, 'Enfoque · pausa corta · pausa larga, en minutos.'),
        P.running ? h('p', { class: 'hint form-hint' }, 'Pausá el temporizador para cambiar la duración.') : null,
        h('p', { class: 'hint form-hint' }, 'Con la extensión Bloqueador horario, al iniciar un enfoque solo quedan abiertos los sitios que elegiste.'),
        notifRow(),
        K.wakeSupported() ? h('label', { class: 'fx-wake' },
          h('input', { type: 'checkbox', checked: K.wakeOn(), onchange: e => K.setWake(e.target.checked) }),
          h('span', {}, 'Mantener la pantalla encendida mientras corre. En el celular, si se apaga, el temporizador puede frenarse.')) : null));
    box.addEventListener('toggle', () => { settingsOpen = box.open; });
    return box;
  }

  /* ---------- Piezas ---------- */
  function ring() {
    return h('div', { class: 'fx-ring' },
      h('div', { svg: `<svg viewBox="0 0 260 260" aria-hidden="true"><circle class="fx-track" cx="130" cy="130" r="${R}"/><circle class="fx-arc" id="pomoRing" cx="130" cy="130" r="${R}" stroke-dasharray="${C}"/></svg>` }),
      h('div', { class: 'fx-center' },
        h('p', { class: 'fx-mode', id: 'pomoMode' }, K.POMO_LABEL[P.mode]),
        h('div', { class: 'fx-time', id: 'pomoTime', role: 'timer', 'aria-live': 'off' }, K.pomoFmt(K.pomoRemaining())),
        h('p', { class: 'fx-sub', id: 'pomoSub' })));
  }
  /* Mantener apretado repite el ajuste (despacio al principio, rápido después) */
  function holdRepeat(b, fn) {
    let t1 = 0, t2 = 0;
    const stop = () => { clearTimeout(t1); clearInterval(t2); t1 = 0; t2 = 0; };
    b.addEventListener('pointerdown', e => {
      if (b.disabled || e.button > 0) return;
      e.preventDefault();
      fn(); stop();
      t1 = setTimeout(() => { t2 = setInterval(fn, 80); }, 400);
    });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => b.addEventListener(ev, stop));
    b.addEventListener('click', e => { if (e.detail === 0) fn(); });     // teclado (Enter / Espacio)
  }
  /* − 1 min · duración de la etapa actual · + 1 min. Solo cambia el texto: no se redibuja la pantalla. */
  /* Duración de la etapa: se escribe en minutos (toque el número, como la alarma del celular) o se ajusta con − / +. */
  function stepper() {
    const dec = h('button', { type: 'button', class: 'fx-step-btn', 'aria-label': 'Restar 1 minuto', title: 'Restar 1 minuto', 'data-delta': '-1', svg: icon('minus', 18) });
    const inc = h('button', { type: 'button', class: 'fx-step-btn', 'aria-label': 'Sumar 1 minuto', title: 'Sumar 1 minuto', 'data-delta': '1', svg: icon('plus', 18) });
    [dec, inc].forEach(b => holdRepeat(b, () => K.adjustDuration(P.mode, Number(b.dataset.delta) * 60)));

    const val = h('input', {
      id: 'fxStepVal', class: 'fx-step-in', type: 'text', inputmode: 'numeric', maxlength: '3', autocomplete: 'off',
      'aria-label': 'Minutos de la etapa', 'aria-live': 'polite',
    });
    const restore = () => { val.value = String(Math.round(K.POMO[P.mode] / 60000)); };
    val.addEventListener('focus', () => val.select());
    val.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); val.blur(); }
      else if (e.key === 'Escape') { e.preventDefault(); restore(); val.blur(); }
    });
    val.addEventListener('blur', () => {
      if (!K.setDurationMin(P.mode, val.value)) restore();
      K.focusPaint(false);
    });
    return h('div', { class: 'fx-step', role: 'group', 'aria-label': 'Duración de la etapa' },
      dec,
      h('div', { class: 'fx-step-txt' }, h('span', { class: 'fx-step-l' }, 'Duración en minutos'),
        h('span', { class: 'fx-step-row' }, val, h('span', { class: 'fx-step-unit' }, 'min'))),
      inc);
  }

  function modes() {
    return h('div', { class: 'fx-modes', role: 'group', 'aria-label': 'Etapa' }, ['focus', 'short', 'long'].map(m => h('button', {
      type: 'button', class: 'fx-mode-btn', 'data-mode': m, 'aria-pressed': String(P.mode === m),
      onclick: () => { K.pomoSetMode(m); K.focusPaint(true); },
    }, K.POMO_LABEL[m], h('small', {}, K.durText(K.POMO[m])))));
  }
  function finishBtn() {
    return h('button', { class: 'btn fx-finish', id: 'pomoFinish', type: 'button', hidden: true,
      title: 'Corta el enfoque ahora y guarda el tiempo trabajado',
      onclick: () => { K.pomoFinishEarly(); K.focusPaint(true); } }, 'Terminar y guardar');
  }
  function controls() {
    return h('div', { class: 'fx-ctl' },
      K.iconBtn('reset', 'Reiniciar', () => K.pomoReset(), 'fx-sm'),
      h('button', { class: 'fx-main', id: 'pomoToggle', type: 'button', onclick: K.pomoToggle }),
      K.iconBtn('skip', 'Saltar a la siguiente etapa', () => { K.pomoSkip(); K.focusPaint(true); }, 'fx-sm'));
  }

  /* Lado derecho: hoy, semana y sesiones */
  K.focusSide = () => {
    const el = K.$('#fxSide');
    if (!el) return;
    const s = K.focusStats();
    const max = Math.max(30, ...s.week);
    el.replaceChildren(
      h('div', { class: 'fx-tiles' },
        tile(mins(s.todayMin), 'Hoy'), tile(String(s.todayCount), s.todayCount === 1 ? 'Enfoque' : 'Enfoques'), tile(mins(s.weekMin), 'Esta semana')),
      h('section', { class: 'fx-card' },
        h('h3', {}, 'Semana'),
        h('div', { class: 'fx-bars', role: 'img', 'aria-label': 'Minutos de enfoque por día' }, s.week.map((m, i) => h('div', { class: 'fx-bar' + (i === s.todayIdx ? ' today' : ''), title: `${DAYS[i]}: ${mins(m)}` },
          h('span', { class: 'fx-bar-m' }, Math.round(m) > 0 ? String(Math.round(m)) : ''),
          h('span', { class: 'fx-bar-track' }, h('span', { class: 'fx-bar-fill', style: `height:${m ? Math.max(6, (m / max) * 100) : 3}%` })),
          h('span', { class: 'fx-bar-d' }, DAYS[i]))))),
      h('section', { class: 'fx-card' },
        h('h3', {}, 'Hoy'),
        s.today.length ? h('ul', { class: 'fx-list' }, s.today.slice(0, 8).map(x => h('li', {},
          h('span', { class: 'fx-l-time' }, clock(x.end)),
          h('span', { class: 'fx-l-name' + (x.target ? '' : ' none') }, x.target ? K.targetName(x.target) : 'Sin objetivo'),
          h('span', { class: 'fx-l-dur' }, mins(x.ms / 60000)),
          K.iconBtn('x', 'Quitar sesión', () => K.removeSession(x), 'fx-l-x'))))
          : h('p', { class: 'fx-empty' }, 'Todavía no completaste ningún enfoque hoy.')));
  };
  const tile = (v, l) => h('div', { class: 'fx-tile' }, h('b', {}, v), h('span', {}, l));

  /* Actualiza lo que cambia con el tiempo (se llama varias veces por segundo) */
  K.focusPaint = full => {
    const fx = K.$('.fx');
    if (!fx) return;
    fx.dataset.mode = P.mode;
    fx.classList.toggle('running', P.running);
    const t = K.$('#pomoTime'); if (t) t.textContent = K.pomoFmt(K.pomoRemaining());
    const mode = K.$('#pomoMode'); if (mode) mode.textContent = K.POMO_LABEL[P.mode];
    const ring = K.$('#pomoRing');
    if (ring) ring.style.strokeDashoffset = String(C * (1 - Math.max(0, Math.min(1, K.pomoRemaining() / K.POMO[P.mode]))));
    const btn = K.$('#pomoToggle');
    if (btn) {
      btn.innerHTML = icon(P.running ? 'pause' : 'play', 26);
      btn.title = P.running ? 'Pausar (Espacio)' : 'Iniciar (Espacio)';
      btn.setAttribute('aria-label', P.running ? 'Pausar' : 'Iniciar');
    }
    K.$$('.fx-mode-btn').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.mode === P.mode)));
    const fin = K.$('#pomoFinish');
    if (fin) {
      const can = K.pomoCanFinish();
      if (fin.hidden === can) fin.hidden = !can;
      if (can) {
        const label = `Terminar y guardar · ${K.durText(Math.floor(K.pomoElapsed() / 60000) * 60000)}`;
        if (fin.textContent !== label) fin.textContent = label;
      }
    }
    const every = K.POMO.every, done = P.cycle % every;
    K.$$('.pomo-dot').forEach((d, i) => d.classList.toggle('on', i < done));
    const sub = K.$('#pomoSub');
    if (sub) sub.textContent = P.mode === 'focus' ? `Enfoque ${done + 1} de ${every}` : (P.mode === 'long' ? 'Descansá un rato largo' : 'Respirá un momento');
    const sv = K.$('#fxStepVal');
    if (sv) { sv.disabled = P.running; if (document.activeElement !== sv) sv.value = String(Math.round(K.POMO[P.mode] / 60000)); }
    K.$$('.fx-step-btn').forEach(b => { b.disabled = P.running; });
    K.$$('.fx-mode-btn small').forEach(x => { x.textContent = K.durText(K.POMO[x.parentNode.dataset.mode]); });
    K.$$('.fx-presets button').forEach(b => {
      const p = b.dataset.p.split(',').map(Number);
      b.setAttribute('aria-pressed', String(p[0] * 60000 === K.POMO.focus && p[1] * 60000 === K.POMO.short && p[2] * 60000 === K.POMO.long));
      b.disabled = P.running;
    });
    if (full) { const tb = K.$('#fxTarget'); if (tb) tb.replaceChildren(targetBox()); }
  };


  K.renderFocus = root => {
    root.append(h('div', { class: 'fx', 'data-mode': P.mode },
      h('section', { class: 'fx-main-card' },
        modes(), ring(), stepper(), controls(), finishBtn(),
        h('div', { id: 'fxTarget' }, targetBox()),
        h('div', { class: 'fx-foot' },
          h('span', { class: 'fx-cycle' }, 'Ciclo ', h('span', { class: 'pomo-dots' }, [0, 1, 2, 3].map(() => h('i', { class: 'pomo-dot' })))),
          h('span', { class: 'fx-keys' }, h('kbd', {}, 'Espacio'), ' inicia o pausa')),
        settings()),
      h('div', { class: 'fx-side', id: 'fxSide' })));
    K.focusSide();
    K.focusPaint(false);
  };
})();
