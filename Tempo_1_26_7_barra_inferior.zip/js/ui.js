/* =========================================================
   ui.js — piezas de interfaz reutilizables:
   popover, menú, selector de tono y aviso (toast).
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;

  /* ---------- Popover anclado a un botón ---------- */
  let pop = null;
  K.hasPop = () => !!pop;
  K.closePop = () => { if (pop) { pop.remove(); pop = null; } };

  K.openPop = (anchor, content) => {
    K.closePop();
    pop = h('div', { class: 'popover', role: 'menu' }, content);
    pop._anchor = anchor;
    document.body.append(pop);
    const r = anchor.getBoundingClientRect();
    const pw = pop.offsetWidth, ph = pop.offsetHeight;
    let top = r.bottom + 6;
    if (top + ph > innerHeight - 8) top = Math.max(8, r.top - ph - 6);
    pop.style.left = Math.max(8, Math.min(r.left, innerWidth - pw - 8)) + 'px';
    pop.style.top = top + 'px';
    return pop;
  };
  K.togglePop = (anchor, make) => {
    if (pop && pop._anchor === anchor) { K.closePop(); return; }
    K.openPop(anchor, make());
  };
  document.addEventListener('pointerdown', e => {
    if (pop && !pop.contains(e.target) && !pop._anchor.contains(e.target)) K.closePop();
  });

  /* items: { label, icon?, checked?, indent?, keep?, run } o '-' */
  K.menu = items => h('div', {}, items.map(it => it === '-' ? h('div', { class: 'sep' }) :
    h('button', {
      class: 'menu-item' + (it.indent ? ' indent' : ''), type: 'button', role: 'menuitem',
      onclick: () => { if (!it.keep) K.closePop(); it.run(); },
    },
    h('span', { class: 'mi', svg: icon(it.icon || 'file', 16) }),
    h('span', { class: 'mlbl' }, it.label),
    it.checked ? h('span', { class: 'check', svg: icon('check', 16) }) : null)));

  /* ---------- Aviso con "Deshacer" ---------- */
  let toastTimer;
  K.toast = (msg, undo) => {
    const root = K.$('#toastRoot');
    if (!root) return;
    root.replaceChildren(h('div', { class: 'toast', role: 'status' }, h('span', {}, msg),
      undo ? h('button', { type: 'button', onclick: () => { undo(); root.replaceChildren(); } }, 'Deshacer') : null));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => root.replaceChildren(), 6000);
  };

  /* ---------- Foco contenido en un diálogo (U4) ----------
     Mientras el diálogo está abierto, el resto de la página queda inert: no recibe foco, clics ni lectura de
     pantalla. Tab y Shift+Tab dan vueltas dentro del diálogo y, al cerrarse, el foco vuelve a donde estaba.
     Devuelve la función que lo libera (también se libera sola cuando el diálogo sale del DOM). */
  const FOCUSABLE = 'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  K.trapFocus = dialog => {
    const prev = document.activeElement;
    const inerted = [...document.body.children].filter(el => !el.contains(dialog) && !el.inert && el.tagName !== 'SCRIPT');
    inerted.forEach(el => { el.inert = true; });
    dialog.setAttribute('aria-modal', 'true');
    let released = false;
    const onKey = e => {
      if (e.key !== 'Tab') return;
      const f = [...dialog.querySelectorAll(FOCUSABLE)].filter(el => el.getClientRects().length);
      if (!f.length) { e.preventDefault(); return; }
      const first = f[0], last = f[f.length - 1], cur = document.activeElement;
      if (e.shiftKey && (cur === first || !dialog.contains(cur))) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && (cur === last || !dialog.contains(cur))) { e.preventDefault(); first.focus(); }
    };
    const release = () => {
      if (released) return;
      released = true;
      document.removeEventListener('keydown', onKey, true);
      observer.disconnect();
      inerted.forEach(el => { el.inert = false; });
      if (prev && prev.isConnected && prev.focus) prev.focus({ preventScroll: true });
    };
    const observer = new MutationObserver(() => { if (!dialog.isConnected) release(); });
    observer.observe(document.body, { childList: true });
    document.addEventListener('keydown', onKey, true);
    return release;
  };
})();
