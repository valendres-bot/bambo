/* =========================================================
   palette.js — búsqueda global y acciones rápidas (atajo K).
   Encuentra notas (también archivadas), etiquetas, vistas y acciones.
   Sin distinguir mayúsculas ni acentos, y resalta las coincidencias.
   ========================================================= */
(function () {
  'use strict';
  const K = (window.K = window.K || {});
  const { h, icon } = K;

  K.openPalette = () => {
    if (K.$('.palette')) return;
    K.closePop();
    const st = K.state;
    const back = h('div', { class: 'backdrop pal-back' });
    const input = h('input', { class: 'pal-input', placeholder: 'Buscar notas, etiquetas o acciones', 'aria-label': 'Buscar', autocomplete: 'off' });
    const list = h('div', { class: 'pal-list', role: 'listbox' });
    let items = [], sel = 0;
    const close = () => back.remove();
    const choose = it => { close(); it.run(); };

    function collect(raw) {
      const q = raw.trim();
      const tk = K.tokens(q);
      const m = s => K.matchAll(s, tk);
      const out = [];
      const add = (group, arr) => arr.forEach(x => out.push({ group, ...x }));

      add('Acciones', [
        { label: 'Nueva nota', ic: 'plus', hint: 'N', run: () => K.newNote() },
        { label: 'Nueva etiqueta', ic: 'tag', run: () => K.startNewLabel() },
        { label: K.pomoIsRunning() ? 'Pausar el enfoque' : 'Iniciar el enfoque', ic: K.pomoIsRunning() ? 'pause' : 'play',
          run: () => { K.go({ name: 'focus' }); K.pomoToggle(); } },
        { label: 'Saltar a la siguiente etapa de Foco', ic: 'skip', run: () => K.pomoSkip() },
        ...(K.pomoCanFinish() ? [{ label: 'Terminar y guardar el enfoque', ic: 'check', run: () => K.pomoFinishEarly() }] : []),
      ].filter(a => m(a.label)));

      add('Ir a', [
        { label: 'Notas', ic: 'file', run: () => K.go({ name: 'all' }) },
        { label: 'Hoy', ic: 'checklist', hint: 'P', run: () => K.go({ name: 'today' }) },
        { label: 'Foco', ic: 'timer', run: () => K.go({ name: 'focus' }) },
        { label: 'Métricas', ic: 'chart', run: () => K.go({ name: 'metrics' }) },
        { label: 'Archivo', ic: 'archive', run: () => K.go({ name: 'archive' }) },
        { label: 'Papelera', ic: 'trash', run: () => K.go({ name: 'trash' }) },
        { label: 'Configuración', ic: 'gear', run: () => K.go({ name: 'settings' }) },
        ...K.activeLabels().map(l => ({
          label: l.name, ic: K.labelIcon(l), hint: 'Etiqueta',
          run: () => K.go({ name: 'label', id: l.id }),
        })),
      ].filter(x => m(x.label)));

      const notes = st.notes.filter(n => !n.trashed && K.matchNorm(K.searchNorm(n), tk))
        .sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 8);
      add(tk.length ? 'Notas' : 'Recientes', notes.map(n => ({
        label: n.title || 'Sin título', text: n.title ? null : (n.body || '').slice(0, 60), ic: 'file',
        hint: n.archived ? 'Archivada' : K.labelsOf(n).map(l => l.name).join(', '),
        run: () => K.openEditor(n),
      })));
      return out.map(it => ({ ...it, q }));
    }

    function draw() {
      items = collect(input.value);
      sel = 0;
      list.replaceChildren();
      if (!items.length) { list.append(h('div', { class: 'pal-none' }, 'Nada coincide con tu búsqueda.')); return; }
      let last = null;
      items.forEach((it, i) => {
        if (it.group !== last) { list.append(h('div', { class: 'pal-group' }, it.group)); last = it.group; }
        list.append(h('div', {
          class: 'pal-item', role: 'option', 'aria-selected': String(i === sel), 'data-i': String(i),
          onmousemove: () => { if (sel !== i) { sel = i; mark(); } },
          onclick: () => choose(it),
        },
        h('span', { class: 'lead' }, h('span', { svg: icon(it.ic, 17), style: 'display:grid' })),
        h('span', { class: 'lbl' }, K.hl(it.label, it.q), it.text ? h('span', { class: 'pal-sub' }, ' · ' + it.text) : null),
        it.hint ? h('span', { class: 'hint' }, it.hint) : null));
      });
    }
    function mark() {
      list.querySelectorAll('.pal-item').forEach(el => {
        const on = Number(el.dataset.i) === sel;
        el.setAttribute('aria-selected', String(on));
        if (on && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
      });
    }

    input.addEventListener('input', draw);
    input.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); if (items.length) { sel = (sel + 1) % items.length; mark(); } }
      else if (e.key === 'ArrowUp') { e.preventDefault(); if (items.length) { sel = (sel - 1 + items.length) % items.length; mark(); } }
      else if (e.key === 'Enter') { e.preventDefault(); if (items[sel]) choose(items[sel]); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
    });
    back.addEventListener('pointerdown', e => { if (e.target === back) close(); });
    const pal = h('div', { class: 'palette', role: 'dialog', 'aria-label': 'Buscar' }, input, list);
    back.append(pal);
    K.trapFocus(pal);
    document.body.append(back);
    draw();
    input.focus();
  };
})();
