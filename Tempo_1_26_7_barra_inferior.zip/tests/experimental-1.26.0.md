# Tempo 1.26.0 — experimental: días del mes, franjas horarias y rutina en el día

## Idea principal que se recoge
Hoy deja de ser solo una lista de la semana y pasa a ser el día que se está viviendo: elegís un día del mes,
ves qué tocaba, y lo organizás en franjas horarias. Las rutinas del calendario aparecen como bloques del día.

## Cambios
- **Días del mes en Hoy.** Una tira con los días del mes del día elegido. Se toca un día para verlo; las flechas
  cambian de día o de mes. En celular se desliza de costado para pasar de día en día, igual que en Calendario.
  Los puntitos marcan los días con pendientes, rutinas o franjas. *Ir a hoy* vuelve al día actual.
- **Vista del día.** De arriba abajo: vencidas (solo cuando el día elegido es hoy), las franjas del día ordenadas
  por hora, y los pendientes del día que no están en ninguna franja.
- **Franjas horarias (nuevas).** Dentro de un día se crea una franja con título, inicio, fin y color (intervalos de
  10 min). Una franja va dentro de un solo día: no cruza la medianoche. Cada franja tiene su campo para agregar
  pendientes (Enter agrega). Editar o eliminar una franja pide confirmación; eliminar deja sus pendientes en el
  día, sin franja, y tiene *Deshacer*.
- **Pendientes en franjas.** Desde el menú ⋯ de un pendiente, *Franja…* lo pasa a una franja del mismo día (o lo saca).
  Un pendiente en una franja tiene la fecha de esa franja.
- **Bloques de la rutina en el día.** Los bloques de la rutina semanal que caen en el día elegido aparecen como
  franjas, con sus pendientes de rutina, que se tildan ese día.
- **Captura.** Cuando el día elegido no es hoy, *Vence* ofrece *Día elegido*.
- **Datos.** Nueva colección `slots` (base de datos versión 5). La copia de respaldo incluye las franjas. Una
  importación sin la franja de un pendiente, o con una de otro día, deja el pendiente sin franja.

## Límites deliberados
- Las franjas no cruzan la medianoche (un bloque de rutina sí, como antes).
- Las franjas no aparecen en Calendario: la rutina sigue ahí, y el día la muestra.
- No hay arrastre de pendientes entre franjas; se usa el menú *Franja…*.
- Sin dependencias nuevas, sin red nueva.

## Verificación
- `node scripts/release.mjs --check`: OK (1.26.0).
- Pruebas de lógica (Vitest): 114 de 114 pasan (107 previas, con la lista de colecciones y la versión de base
  actualizadas, más 7 nuevas en `tests/slots.test.js`).
- Prueba de render con DOM simulado (sin navegador): Hoy, mañana y un día con rutina se dibujan con sus franjas y
  pendientes; crear una franja desde su formulario y agregar pendientes en ella funciona.
- Pendiente: recorrido en navegador real, en escritorio y celular. No se pudo probar aquí el deslizamiento táctil,
  la animación ni el diseño visual.

## Criterios de aceptación manual
1. Abrir Hoy: la tira muestra el mes actual con hoy marcado.
2. Tocar otro día: cambia la vista, la captura ofrece *Día elegido* y el encabezado dice el día.
3. En celular, deslizar de costado pasa al día siguiente o anterior.
4. *Franja* crea una franja en el día elegido; al agregarle un pendiente aparece dentro.
5. Un bloque de la rutina de ese día aparece como franja, con sus pendientes de rutina.
6. *Franja…* en el menú de un pendiente lo mueve dentro de la franja; eliminar la franja lo deja en el día.
7. Exportar y volver a importar conserva las franjas y su asignación.
