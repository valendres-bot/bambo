/* 1.25.1.3: el inicio es Hoy; Notas vive en #/notas; las rutas viejas siguen funcionando. */
import { describe, it, expect } from 'vitest';
import { loadApp } from './load-app.js';

function at(hash) {
  const location = { hash };
  const K = loadApp(undefined, { location });
  return { K, location };
}

describe('inicio: Hoy', () => {
  it('sin hash (o #/) abre Hoy', () => {
    for (const hash of ['', '#', '#/']) {
      const { K } = at(hash);
      expect(K.parseRoute()).toEqual({ name: 'today' });
    }
  });

  it('Notas vive en #/notas y se escribe así', () => {
    const { K } = at('#/notas');
    expect(K.parseRoute()).toEqual({ name: 'all' });
    expect(K.hashFor({ name: 'all' })).toBe('#/notas');
  });

  it('las rutas viejas siguen funcionando', () => {
    expect(at('#/none').K.parseRoute()).toEqual({ name: 'all' });
    expect(at('#/focus').K.parseRoute()).toEqual({ name: 'focus' });
  });

  it('una ruta desconocida cae en Hoy, no en Notas', () => {
    expect(at('#/no-existe').K.parseRoute()).toEqual({ name: 'today' });
  });

  it('Hoy se titula Hoy', () => {
    const { K } = at('');
    expect(K.routeInfo({ name: 'today' }).title).toBe('Hoy');
  });
});
