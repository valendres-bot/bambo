/* Franjas horarias de Hoy (1.26.4): ahora son bloques con repeat once. Importación, pendientes dentro de una franja, exportación. */
import { describe, it, expect } from 'vitest';
import { loadApp } from './load-app.js';

/* Franja en el modelo unificado */
const slot = (over = {}) => {
  const { date = '2026-10-20', ...rest } = over;
  return { id: 's-1', groupId: null, title: 'Estudiar', start: 540, end: 660, color: null, labels: [], notes: [],
    createdAt: 1, updatedAt: 1, rev: 0, ...rest, repeat: { type: 'once', date } };
};
/* Franja en la forma de un respaldo anterior (1.26.3) */
const legacySlot = (over = {}) => ({ id: 's-1', date: '2026-10-20', title: 'Estudiar', start: 540, end: 660,
  color: null, createdAt: 1, updatedAt: 1, ...over });
const task = (over = {}) => ({ id: 't-1', text: 'Leer capítulo 3', due: '2026-10-20', done: false, doneAt: null, blockId: null,
  labels: [], doneDays: {}, createdAt: 1, updatedAt: 1, ...over });

describe('franjas: importación', () => {
  it('una franja válida de un respaldo anterior entra como bloque once; una inválida se descarta', async () => {
    const K = loadApp();
    const r = await K.mergeData(K.normalizeImport({ version: 6, notes: [], slots: [
      legacySlot(),
      legacySlot({ id: 's-noche', start: 1320, end: 60 }),
      legacySlot({ id: 's-fecha', date: '2026-02-31' }),
    ] }));
    expect(r.invalid).toBe(2);
    expect(K.state.blocks.filter(K.isOnce).map(b => b.id)).toEqual(['s-1']);
    expect(K.state.blocks.find(b => b.id === 's-1').repeat).toEqual({ type: 'once', date: '2026-10-20' });
  });

  it('un pendiente con franja de otro día pierde la franja; con la del mismo día la conserva', async () => {
    const K = loadApp();
    await K.mergeData(K.normalizeImport({ version: 6, notes: [], slots: [legacySlot()], tasks: [
      task({ id: 't-same', blockId: 's-1' }),
      task({ id: 't-other', blockId: 's-1', due: '2026-10-21' }),
      task({ id: 't-ghost', blockId: 's-no-existe' }),
    ] }));
    const byId = Object.fromEntries(K.state.tasks.map(t => [t.id, t]));
    expect(byId['t-same'].blockId).toBe('s-1');
    expect(byId['t-other'].blockId).toBeNull();
    expect(byId['t-ghost'].blockId).toBeNull();
  });
});

describe('franjas: pendientes dentro de una franja', () => {
  it('K.addTasks guarda la franja en cada pendiente del lote', () => {
    const K = loadApp();
    K.state.blocks = [slot()];
    const made = K.addTasks([{ text: 'Uno', due: '2026-10-20' }, { text: 'Dos', due: '2026-10-20' }], { blockId: 's-1' });
    expect(made.map(t => t.blockId)).toEqual(['s-1', 's-1']);
  });

  it('K.setTaskSlot asigna y quita la franja', () => {
    const K = loadApp();
    K.state.blocks = [slot()];
    K.state.tasks = [task()];
    K.setTaskSlot(K.state.tasks[0], 's-1');
    expect(K.state.tasks[0].blockId).toBe('s-1');
    K.setTaskSlot(K.state.tasks[0], null);
    expect(K.state.tasks[0].blockId).toBeNull();
  });

  it('K.slotsOn devuelve solo las franjas del día, ordenadas por hora', () => {
    const K = loadApp();
    K.state.blocks = [slot({ id: 'tarde', start: 900, end: 960 }), slot({ id: 'manana', start: 540, end: 600 }),
      slot({ id: 'otro', date: '2026-10-21' })];
    expect(K.slotsOn('2026-10-20').map(s => s.id)).toEqual(['manana', 'tarde']);
  });

  it('borrar una franja con deshacer deja sus pendientes sin franja y el deshacer los devuelve', () => {
    const K = loadApp();
    K.state.blocks = [slot()];
    K.state.tasks = [task({ blockId: 's-1' })];
    K.removeSlot(K.state.blocks[0]);
    expect(K.state.blocks.filter(K.isOnce)).toEqual([]);
    expect(K.state.tasks[0].blockId).toBeNull();
    expect(K.state.tasks[0].due).toBe('2026-10-20');   // el pendiente sigue en su día
  });
});

describe('franjas: exportación', () => {
  it('la copia guarda la franja como bloque once y la importación la devuelve', async () => {
    const K = loadApp();
    K.state.blocks = [slot()];
    const data = JSON.parse(await K.buildExport());
    expect(data.blocks).toEqual([expect.objectContaining({ id: 's-1', repeat: { type: 'once', date: '2026-10-20' }, start: 540, end: 660 })]);
    const K2 = loadApp();
    await K2.mergeData(K2.normalizeImport(data));
    expect(K2.state.blocks.filter(K2.isOnce).map(s => s.id)).toEqual(['s-1']);
  });
});
