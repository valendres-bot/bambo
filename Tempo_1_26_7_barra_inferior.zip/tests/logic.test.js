/* Lógica pura de Tempo: parser de pendientes y fechas, texto de notas, importación, bloques y rutinas.
   Corre con `npm test` (Vitest). Usa la misma carga de scripts que la app (ver load-app.js). */
import { describe, it, expect, beforeAll, beforeEach, afterAll, vi } from 'vitest';
import { loadApp } from './load-app.js';

let K;

beforeAll(() => {
  // Fecha fija: miércoles 14 de octubre de 2026, 18:00. Los días de la semana dependen de esto.
  vi.useFakeTimers({ toFake: ['Date'] });
  vi.setSystemTime(new Date(2026, 9, 14, 18, 0, 0));
});
afterAll(() => { vi.useRealTimers(); });
beforeEach(() => {
  K = loadApp();                  // instancia nueva: el almacenamiento en memoria no se comparte entre pruebas
  K.state.blocks = [];
  K.state.tasks = [];
});

describe('pendientes: K.parseCapture', () => {
  it('una línea es un pendiente y se quitan viñetas y casillas', () => {
    const out = K.parseCapture('- Comprar cuadernos\n• Llamar al banco\n- [ ] Pagar la luz\n[x] Regar\n* Tarea');
    expect(out.map(t => t.text)).toEqual(['Comprar cuadernos', 'Llamar al banco', 'Pagar la luz', 'Regar', 'Tarea']);
    expect(out.every(t => t.due === null)).toBe(true);
  });

  it('una línea con el nombre de un día fija la fecha de las líneas que siguen', () => {
    const out = K.parseCapture('VIERNES\nLeer el capítulo 3\nComprar cuadernos\nsábado:\nRepasar');
    expect(out).toEqual([
      { text: 'Leer el capítulo 3', due: '2026-10-16' },
      { text: 'Comprar cuadernos', due: '2026-10-16' },
      { text: 'Repasar', due: '2026-10-17' },
    ]);
  });

  it('acepta días sin tilde y en minúscula', () => {
    expect(K.parseCapture('domingo\nHacer algo')[0].due).toBe('2026-10-18');
    expect(K.parseCapture('miércoles\nHoy')[0].due).toBe('2026-10-14');   // hoy, si hoy es ese día
  });

  it('una fecha @AAAA-MM-DD en la línea manda sobre el día y se saca del texto', () => {
    const out = K.parseCapture('VIERNES\nEntregar TP @2026-11-02 urgente');
    expect(out).toEqual([{ text: 'Entregar TP urgente', due: '2026-11-02' }]);
  });

  it('una fecha que no existe (2026-02-31) no cuenta y queda como texto', () => {
    const out = K.parseCapture('Cita @2026-02-31');
    expect(out[0].due).toBeNull();
    expect(out[0].text).toContain('@2026-02-31');
  });

  it('usa la fecha por defecto cuando la línea no trae otra', () => {
    expect(K.parseCapture('Algo', '2026-12-01')).toEqual([{ text: 'Algo', due: '2026-12-01' }]);
  });

  it('ignora líneas vacías y separadores', () => {
    expect(K.parseCapture('\n   \n-----\n=====\n~~~\nUno')).toEqual([{ text: 'Uno', due: null }]);
    expect(K.parseCapture('')).toEqual([]);
    expect(K.parseCapture(null)).toEqual([]);
  });

  it('acepta saltos de línea de Windows y recorta el texto a 200 caracteres', () => {
    const largo = 'a'.repeat(300);
    const out = K.parseCapture(`Uno\r\nDos\r${largo}`);
    expect(out.map(t => t.text.length)).toEqual([3, 3, 200]);
  });

  it('el tope por vez existe y es 100', () => {
    expect(K.TASK_MAX).toBe(100);
  });
});

describe('texto de notas: K.parseBody y K.parseLine', () => {
  it('reconoce subtítulos, viñetas, párrafos y casillas', () => {
    const lines = K.parseBody('## Parcial\n- repasar\ntexto suelto\n- [x] hecho ^t1');
    expect(lines.map(l => l.k)).toEqual(['h', 'b', 'p', 't']);
    expect(lines[0].text).toBe('Parcial');
    expect(lines[3].done).toBe(true);
  });

  it('normaliza saltos de línea de Windows', () => {
    expect(K.parseBody('a\r\nb\rc').map(l => l.text)).toEqual(['a', 'b', 'c']);
  });

  it('una casilla sin marcar no está hecha', () => {
    expect(K.parseLine('- [ ] pendiente').done).toBe(false);
  });

  it('escapa las marcas que cambiarían el formato al reabrir', () => {
    expect(K.esc('*negrita* [x] \\')).toBe('\\*negrita\\* \\[x\\] \\\\');
    expect(K.esc('==')).toBe('\\=\\=');
  });
});

describe('importación: K.normalizeImport, K.safeUrl, K.parseMarkdownNote', () => {
  it('rechaza lo que no es un archivo de Tempo', () => {
    expect(() => K.normalizeImport(null)).toThrow('no es un archivo de Tempo');
    expect(() => K.normalizeImport({ notes: 'no' })).toThrow();
    expect(() => K.normalizeImport([])).toThrow();
  });

  it('rechaza una colección presente con estructura inválida en vez de omitirla', () => {
    expect(() => K.normalizeImport({ version: 6, notes: [], tasks: 'perdidas' })).toThrow();
  });

  it('completa las colecciones que faltan con listas vacías', () => {
    const out = K.normalizeImport({ version: 6, notes: [{ id: 'a' }], tasks: [{ id: 't' }] });
    expect(out.notes).toEqual([{ id: 'a' }]);
    expect(out.labels).toEqual([]);
    expect(out.blocks).toEqual([]);
    expect(out.events).toEqual([]);
    expect(out.sessions).toEqual([]);
    expect(out.tasks).toEqual([{ id: 't' }]);
  });

  it('solo acepta enlaces http o https', () => {
    expect(K.safeUrl(' https://ejemplo.com/a ')).toBe('https://ejemplo.com/a');
    expect(K.safeUrl('http://ejemplo.com')).toBe('http://ejemplo.com');
    expect(K.safeUrl('javascript:alert(1)')).toBeNull();
    expect(K.safeUrl('data:text/html,hola')).toBeNull();
    expect(K.safeUrl(42)).toBeNull();
  });

  it('toma el título del primer # o, si no hay, del nombre del archivo', () => {
    expect(K.parseMarkdownNote('# Mi título\n\ntexto', 'x.md').title).toBe('Mi título');
    expect(K.parseMarkdownNote('texto', 'mi-nota_final.md').title).toBe('mi nota final');
  });

  it('lee la línea de etiquetas que escribe la exportación', () => {
    const r = K.parseMarkdownNote('# T\n_Etiquetas: Mate, Física_\n\nHola', 'x.md');
    expect(r.labels).toEqual(['Mate', 'Física']);
  });
});

// En los bloques, los días van de 0 (lunes) a 6 (domingo), como en la grilla de la app.
describe('bloques de la rutina: K.splitBlock', () => {
  const base = { title: 'Estudiar', color: 'azul', labels: ['m1'], notes: [], days: [0, 2] };

  it('un bloque que no cruza la medianoche queda como una parte', () => {
    const parts = K.splitBlock(base, 540, 600);
    expect(parts).toHaveLength(1);
    expect(parts[0]).toMatchObject({ start: 540, end: 600, days: [0, 2] });
  });

  it('un bloque que cruza la medianoche se parte en dos: el resto cae al día siguiente', () => {
    const parts = K.splitBlock({ ...base, days: [5] }, 1380, 60);   // sábado 23:00 a 01:00
    expect(parts).toHaveLength(2);
    expect(parts[0]).toMatchObject({ start: 1380, end: 1440, days: [5] });
    expect(parts[1]).toMatchObject({ start: 0, end: 60, days: [6] });   // domingo 00:00 a 01:00
  });

  it('los días de la segunda parte se corren un día, y el domingo vuelve a lunes', () => {
    const parts = K.splitBlock({ ...base, days: [0, 2] }, 1300, 30);
    expect(parts[1].days).toEqual([1, 3]);
    expect(K.splitBlock({ ...base, days: [6] }, 1380, 60)[1].days).toEqual([0]);
  });
});

describe('rutinas de pendientes: K.routineOccurrences', () => {
  it('un pendiente enlazado aparece solo los días del bloque dentro del rango', () => {
    K.state.blocks = [{ id: 'b1', title: 'Ordenar', repeat: { type: 'weekly', days: [0] }, start: 600, end: 660, labels: [], notes: [], color: 'azul' }];
    K.state.tasks = [{ id: 't1', text: 'Ordenar la casa', blockId: 'b1', done: false, doneDays: {}, createdAt: 1 },
      { id: 't2', text: 'Suelto', blockId: null, done: false, doneDays: {}, createdAt: 2 }];
    const occ = K.routineOccurrences('2026-10-12', '2026-10-19');   // lunes 12 a lunes 19 (bloque los lunes)
    expect(occ.map(o => [o.t.id, o.ds])).toEqual([['t1', '2026-10-12'], ['t1', '2026-10-19']]);
  });

  it('un pendiente sin bloque no genera ocurrencias de rutina', () => {
    K.state.tasks = [{ id: 't2', text: 'Suelto', blockId: null, done: false, doneDays: {}, createdAt: 2 }];
    expect(K.routineOccurrences('2026-10-12', '2026-10-18')).toEqual([]);
  });
});

describe('exportar: K.buildExport (por lotes)', () => {
  const note = i => ({ id: 'n' + i, title: 'Nota ' + i, body: 'Texto "con comillas" y\nsaltos', links: [], labels: [], createdAt: i, updatedAt: i });

  it('una copia vacía es un JSON válido con las ocho colecciones', async () => {
    K.state.notes = []; K.state.labels = []; K.state.events = []; K.state.sessions = [];
    const data = JSON.parse(await K.buildExport());
    expect(data).toEqual({ version: 6, notes: [], labels: [], blocks: [], events: [], sessions: [], tasks: [], goals: [], slots: [] });
  });

  it('con muchos registros (más de un lote) conserva todos, en orden y con su contenido', async () => {
    K.state.notes = Array.from({ length: 1200 }, (_, i) => note(i));
    const data = JSON.parse(await K.buildExport());
    expect(data.notes).toHaveLength(1200);
    expect(data.notes[0]).toEqual(note(0));
    expect(data.notes[1199]).toEqual(note(1199));
    expect(data.notes[600].body).toBe('Texto "con comillas" y\nsaltos');
  });

  it('refleja lo que había al empezar: lo que se agrega mientras tanto no entra', async () => {
    K.state.notes = [note(1)];
    const pending = K.buildExport();
    K.state.notes.push(note(2));
    const data = JSON.parse(await pending);
    expect(data.notes.map(n => n.id)).toEqual(['n1']);
  });

  it('la copia se puede volver a importar con normalizeImport', async () => {
    K.state.notes = [note(1), note(2)];
    const back = K.normalizeImport(JSON.parse(await K.buildExport()));
    expect(back.notes.map(n => n.id)).toEqual(['n1', 'n2']);
  });

  it('la instantánea no cambia si se modifica un registro durante la exportación', async () => {
    K.state.notes = [note(1)];
    const pending = K.buildExport();
    K.state.notes[0].body = 'modificada después de iniciar';
    const data = JSON.parse(await pending);
    expect(data.notes[0].body).toBe(note(1).body);
  });

  it('una copia con historial de una versión anterior se importa sin ese historial', async () => {
    const legacy = { format: 'tempo-full-backup', backupVersion: 1, version: 6, notes: [note(1)],
      versions: [{ id: 'v1', noteId: 'n1', at: 10, title: 'Anterior', body: 'Texto anterior' }] };
    const out = K.normalizeImport(legacy);
    expect(out.notes).toHaveLength(1);
    expect(out).not.toHaveProperty('versions');
    expect(JSON.parse(await K.buildExport())).not.toHaveProperty('versions');
  });

});


describe('integridad de importación y persistencia', () => {
  beforeEach(() => {
    K.state.notes = []; K.state.labels = []; K.state.blocks = []; K.state.events = [];
    K.state.sessions = []; K.state.versions = []; K.state.tasks = [];
  });

  it('preserva campos admitidos de las tareas y marcas temporales válidas', async () => {
    const task = {
      id: 'task-1', text: 'Preparar parcial', due: '2028-02-29', done: true,
      doneAt: 100, blockId: null, doneDays: { '2028-02-29': 200 },
      createdAt: 50, updatedAt: 150, customField: { source: 'legacy' },
    };
    const result = await K.mergeData(K.normalizeImport({ version: 6, notes: [], tasks: [task] }));
    expect(result.invalid).toBe(0);
    expect(K.state.tasks[0]).toMatchObject(task);
  });

  it('remapea las etiquetas de las tareas al identificador local sin perder otros campos', async () => {
    // La fuente de verdad es el almacenamiento: la etiqueta local se guarda ahí y luego se carga en la app
    await K.api.saveLabel({ id: 'local-mate', name: 'Mate', order: 0, kind: 'materia', links: [], createdAt: 1 });
    K.applyData(await K.api.load());
    const result = await K.mergeData(K.normalizeImport({
      version: 6, notes: [], labels: [{ id: 'remote-mate', name: 'Mate' }],
      tasks: [{ id: 'task-label', text: 'Estudiar', labels: ['remote-mate'], custom: 'keep' }],
    }));
    expect(result.invalid).toBe(0);
    expect(K.state.tasks[0].labels).toEqual(['local-mate']);
    expect(K.state.tasks[0].custom).toBe('keep');
  });

  it('rechaza fechas reales imposibles, identificadores vacíos y estructuras inválidas', async () => {
    const result = await K.mergeData(K.normalizeImport({
      version: 6, notes: [],
      tasks: [
        { id: 'bad-date', text: 'Tarea', due: '2026-02-31' },
        { id: '', text: 'Sin id' },
        { id: 'bad-days', text: 'Días', doneDays: { '2026-02-30': 1 } },
      ],
      events: [{ id: 'event-1', date: '2026-02-31', time: 600, title: 'Inválido' }],
    }));
    expect(result.invalid).toBe(4);
    expect(K.state.tasks).toEqual([]);
    expect(K.state.events).toEqual([]);
  });

  it('rechaza horas fuera de rango en eventos en vez de limitarlas silenciosamente', async () => {
    const result = await K.mergeData(K.normalizeImport({
      version: 6, notes: [], events: [
        { id: 'e1', date: '2026-10-15', time: 1440, title: 'Hora inválida' },
        { id: 'e2', date: '2026-10-15', time: 600, title: 'Hora válida' },
      ],
    }));
    expect(result.invalid).toBe(1);
    expect(K.state.events.map(e => [e.id, e.time])).toEqual([['e2', 600]]);
  });

  it('persiste una tarea en el almacenamiento local tras completar la escritura diferida', async () => {
    const task = { id: 'persist-1', text: 'Persistir', due: null, done: false, doneAt: null,
      blockId: null, doneDays: {}, createdAt: 1, updatedAt: 1 };
    await K.api.saveTask(task);
    await new Promise(resolve => setTimeout(resolve, 380));
    const raw = K.__testStorage.get('mi-keep:v4');
    expect(raw).toBeTruthy();
    expect(JSON.parse(raw).tasks.some(t => t.id === 'persist-1' && t.text === 'Persistir')).toBe(true);
  });
});
