/* Modelo unificado de bloque (1.26.4, en preparación): migración y selector de ocurrencias. */
import { describe, it, expect } from 'vitest';
import { loadApp } from './load-app.js';

const block = (over = {}) => ({ id: 'b-1', groupId: null, title: 'Rutina', days: [0, 2], start: 480, end: 540,
  color: null, labels: [], notes: [], createdAt: 1, updatedAt: 1, rev: 0, ...over });
const slot = (over = {}) => ({ id: 's-1', date: '2026-10-20', title: 'Estudiar', start: 600, end: 660,
  color: null, createdAt: 1, updatedAt: 1, rev: 0, ...over });
const task = (over = {}) => ({ id: 't-1', text: 'x', due: null, done: false, blockId: null,
  labels: [], doneDays: {}, createdAt: 1, updatedAt: 1, ...over });

describe('bloque unificado: migración', () => {
  it('una rutina pasa a repeat semanal y conserva id, días y horario', () => {
    const K = loadApp();
    const [b] = K.migrateToUnified([block()], [], []).blocks;
    expect(b.id).toBe('b-1');
    expect(b.repeat).toEqual({ type: 'weekly', days: [0, 2] });
    expect(b).not.toHaveProperty('days');
    expect(b.start).toBe(480);
    expect(b.end).toBe(540);
  });

  it('una franja pasa a repeat puntual con su fecha y conserva el id', () => {
    const K = loadApp();
    const [s] = K.migrateToUnified([], [slot()], []).blocks;
    expect(s.id).toBe('s-1');
    expect(s.repeat).toEqual({ type: 'once', date: '2026-10-20' });
    expect(s).not.toHaveProperty('date');
  });

  it('es idempotente: migrar dos veces da lo mismo', () => {
    const K = loadApp();
    const once = K.migrateToUnified([block()], [slot()], [{ ...task(), slotId: 's-1' }]);
    const twice = K.migrateToUnified(once.blocks, [], once.tasks);
    expect(twice.blocks).toEqual(once.blocks);
    expect(twice.tasks).toEqual(once.tasks);
  });

  it('un pendiente con slotId de la versión anterior pasa a blockId; si el bloque no existe queda sin bloque', () => {
    const K = loadApp();
    const r = K.migrateToUnified([block()], [slot()], [
      { ...task({ id: 't-a' }), slotId: 's-1' },
      { ...task({ id: 't-b' }), slotId: 'fantasma', blockId: 'b-1' },
      { ...task({ id: 't-c' }), blockId: 'borrado' },
    ]);
    const byId = Object.fromEntries(r.tasks.map(t => [t.id, t]));
    expect(byId['t-a'].blockId).toBe('s-1');
    expect(byId['t-a']).not.toHaveProperty('slotId');
    expect(byId['t-b'].blockId).toBe('b-1');
    expect(byId['t-c'].blockId).toBeNull();
  });

  it('no toca registros que ya tienen repeat', () => {
    const K = loadApp();
    const ya = { id: 'z', title: 'ya', start: 0, end: 10, repeat: { type: 'once', date: '2026-01-05' } };
    expect(K.migrateToUnified([ya], [], []).blocks[0]).toBe(ya);
  });
});

describe('bloque unificado: ocurrencias de un día', () => {
  it('una rutina aparece los días elegidos y una franja solo en su fecha', () => {
    const K = loadApp();
    const all = K.migrateToUnified([block()], [slot()], []).blocks;
    // 2026-10-19 es lunes (índice 0); 2026-10-20 es martes; 2026-10-21 miércoles (índice 2)
    expect(K.occurrencesOn(all, '2026-10-19').map(b => b.id)).toEqual(['b-1']);
    expect(K.occurrencesOn(all, '2026-10-20').map(b => b.id)).toEqual(['s-1']);
    expect(K.occurrencesOn(all, '2026-10-21').map(b => b.id)).toEqual(['b-1']);
    expect(K.occurrencesOn(all, '2026-10-22')).toEqual([]);
  });

  it('ordena por hora de inicio y excluye los borrados', () => {
    const K = loadApp();
    const blocks = [
      { id: 'tarde', title: '', start: 900, end: 960, repeat: { type: 'weekly', days: [0] } },
      { id: 'manana', title: '', start: 480, end: 540, repeat: { type: 'weekly', days: [0] } },
      { id: 'borrado', title: '', start: 100, end: 200, deleted: true, repeat: { type: 'weekly', days: [0] } },
    ];
    expect(K.occurrencesOn(blocks, '2026-10-19').map(b => b.id)).toEqual(['manana', 'tarde']);
  });

  it('una fecha inválida no devuelve nada', () => {
    const K = loadApp();
    expect(K.occurrencesOn([block()], '2026-02-31')).toEqual([]);
    expect(K.occurrencesOn([block()], 'hoy')).toEqual([]);
  });
});

describe('bloque unificado: migración persistente y separación rutina / franja', () => {
  it('migrateStored genera escrituras una sola vez: la segunda pasada no escribe nada', () => {
    const K = loadApp();
    const data = { blocks: [block()], slots: [slot()], tasks: [] };
    const first = K.migrateStored(data);
    expect(first.ops.map(o => [o.c, o.id]).sort()).toEqual([['blocks', 'b-1'], ['blocks', 's-1'], ['slots', 's-1']]);
    expect(first.ops.find(o => o.c === 'slots').rec).toMatchObject({ id: 's-1', deleted: true });
    const second = K.migrateStored(first.data);
    expect(second.ops).toEqual([]);
    expect(second.data).toBe(first.data);
  });

  it('una franja nunca cuenta como rutina: routineBlock y las opciones de rutina la ignoran', () => {
    const K = loadApp();
    K.state.blocks = [K.unifySlot(slot({ id: 'fr' })), K.unifyBlock(block({ id: 'rut' }))];
    K.state.tasks = [task({ id: 't-fr', blockId: 'fr' }), task({ id: 't-rut', blockId: 'rut' })];
    expect(K.routineBlock(K.state.tasks[0])).toBeNull();
    expect(K.routineBlock(K.state.tasks[1]).id).toBe('rut');
    expect(K.routineChoices().map(b => b.id)).toEqual(['rut']);
  });
});

describe('pendientes: un solo vínculo con bloque (1.26.7)', () => {
  it('migrateStored pasa slotId a blockId en el disco y no vuelve a escribir la segunda vez', () => {
    const K = loadApp();
    const data = { blocks: [block(), slot()], slots: [], tasks: [{ ...task({ id: 't-1' }), slotId: 's-1' }, task({ id: 't-2', blockId: 'b-1' })] };
    const first = K.migrateStored(data);
    const op = first.ops.find(o => o.c === 'tasks' && o.id === 't-1');
    expect(op.rec).toMatchObject({ id: 't-1', blockId: 's-1' });
    expect(op.rec).not.toHaveProperty('slotId');
    expect(first.ops.some(o => o.c === 'tasks' && o.id === 't-2')).toBe(false);
    expect(K.migrateStored(first.data).ops).toEqual([]);
  });
});
