/* Carga los scripts clásicos de Tempo en un contexto de Node (sin navegador), para testear la lógica.
   Los DOM son stubs mínimos. El almacenamiento es inyectable:
   · opts.indexedDB: fábrica de IndexedDB (p. ej. fake-indexeddb). Sin ella, la app usa localStorage.
   · opts.store: Map que hace de localStorage (se puede compartir entre sesiones para simular recargas).
   · opts.Blob: clase Blob (para capturar el contenido de las descargas).
   · opts.toast: función que recibe los avisos.
   · opts.location: objeto { hash } que usa el enrutado (router.js). */
import { readFileSync } from 'node:fs';
import { createContext, runInContext } from 'node:vm';
import { fileURLToPath } from 'node:url';
import { join, dirname } from 'node:path';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

/* Mismo orden que index.html (cada archivo usa lo que definen los anteriores). */
export const SCRIPTS = [
  'js/dom.js', 'js/storage.js', 'js/state.js', 'js/bloques.js', 'js/router.js', 'js/actions.js', 'js/data.js',
  'js/goals.js', 'js/richtext.js', 'js/tasks.js', 'js/today.js', 'js/schedule.js', 'js/focus.js', 'js/metrics.js',
];

function stubElement() {
  const noop = () => {};
  return {
    style: {}, dataset: {}, classList: { add: noop, remove: noop, toggle: noop, contains: () => false },
    addEventListener: noop, removeEventListener: noop, setAttribute: noop, append: noop, appendChild: noop,
    remove: noop, click: noop, querySelector: () => null, querySelectorAll: () => [],
  };
}

class ObjectURL extends URL {
  static createObjectURL() { return 'blob:tempo-test'; }
  static revokeObjectURL() {}
}

export function loadApp(files = SCRIPTS, opts = {}) {
  const store = opts.store || new Map();
  const localStorage = {
    getItem: k => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => { store.set(k, String(v)); },
    removeItem: k => { store.delete(k); },
    clear: () => store.clear(),
  };
  const document = {
    documentElement: stubElement(), body: stubElement(), visibilityState: 'visible',
    createElement: () => stubElement(), createTextNode: text => ({ nodeType: 3, text }), addEventListener: () => {},
    querySelector: () => null, querySelectorAll: () => [], getElementById: () => null,
  };
  const sandbox = {
    console, Date, Math, JSON, Promise, Map, Set, Number, String, Array, Object, Error, TextEncoder,
    URL: opts.URL || ObjectURL, Blob: opts.Blob || Blob,
    CustomEvent: class CustomEvent { constructor(type, init = {}) { this.type = type; this.detail = init.detail; } },
    dispatchEvent: () => true,
    setTimeout, clearTimeout, setInterval, clearInterval, crypto: globalThis.crypto, localStorage, document, navigator: {},
    matchMedia: () => ({ matches: false, addEventListener: () => {}, addListener: () => {} }),
    addEventListener: () => {}, removeEventListener: () => {},
    indexedDB: opts.indexedDB,
    location: opts.location || { hash: '' },   // para el enrutado: el test cambia location.hash
  };
  sandbox.window = sandbox;
  const ctx = createContext(sandbox);
  for (const f of files) {
    runInContext(readFileSync(join(ROOT, f), 'utf8'), ctx, { filename: f });
  }
  const K = sandbox.K;
  K.toast = opts.toast || (() => {});
  K.refreshAll = () => {};
  K.__testStorage = store;
  return K;
}
