/* Objetivos (1.24.0, 1.24.1): conversión de materias, proyectos, pendientes, recursos, Foco/Métricas y respaldo.
   Corre con `npm test`. Usa localStorage en memoria (sin IndexedDB) para que sea rápido y determinista. */
import { describe, it, expect } from 'vitest';
import { loadApp } from './load-app.js';

const KEY = 'mi-keep:v4';
const NOW = Date.now();
const lab = (id, over = {}) => ({ id, name: id, order: 0, color: null, kind: 'area', pinned: false, archived: false,
  links: [], createdAt: NOW, rev: 0, ...over });
const task = (id, over = {}) => ({ id, text: 'Tarea ' + id, due: null, done: false, doneAt: null, blockId: null, labels: [],
  doneDays: {}, goalId: null, projectId: null, createdAt: NOW, updatedAt: NOW, rev: 0, ...over });
const sess = (id, target, ms = 60000) => ({ id, start: NOW - ms, end: NOW, ms, target });
const empty = over => ({ notes: [], labels: [], blocks: [], events: [], sessions: [], versions: [], tasks: [], goals: [], ...over });
const seed = data => new Map([[KEY, JSON.stringify(data)]]);
/* La escritura a disco es diferida (~300 ms): antes de releer la app hay que esperar */
const settle = () => new Promise(resolve => setTimeout(resolve, 380));

/* Arranca la app sobre un almacenamiento (y opcionalmente captura los avisos con Deshacer) */
async function boot(store = new Map(), toast = () => {}) {
  const K = loadApp(undefined, { store, toast });
  K.applyData(await K.api.load());
  return K;
}

describe('materias → objetivos: conversión', () => {
  it('convertMaterias: la materia pasa a objetivo académico y la etiqueta queda como área', async () => {
    const K = await boot();
    const data = empty({
      labels: [lab('mate', { kind: 'materia', color: 'azul' }), lab('casa')],
      sessions: [sess('s1', { kind: 'label', id: 'mate', name: 'mate' })],
      tasks: [task('t1', { labels: ['mate'] })],
    });
    const conv = K.convertMaterias(data);
    expect(conv.next.goals).toHaveLength(1);
    expect(conv.next.goals[0]).toMatchObject({ id: 'goal-mate', name: 'mate', category: 'academica', archived: false, legacyLabelId: 'mate', color: 'azul' });
    expect(conv.next.labels.find(l => l.id === 'mate').kind).toBe('area');
    expect(conv.next.labels.find(l => l.id === 'casa').kind).toBe('area');
    expect(conv.next.sessions[0].target).toMatchObject({ kind: 'goal', id: 'goal-mate' });
    expect(conv.next.tasks[0].goalId).toBe('goal-mate');
  });

  it('la conversión es idempotente: una segunda pasada no cambia nada', async () => {
    const K = await boot();
    const conv = K.convertMaterias(empty({ labels: [lab('mate', { kind: 'materia' })] }));
    expect(K.convertMaterias(conv.next).ops).toHaveLength(0);
  });

  it('al cargar, las materias de una versión anterior se convierten y el cambio queda guardado una sola vez', async () => {
    const store = seed(empty({
      labels: [lab('mate', { kind: 'materia' })],
      sessions: [sess('s1', { kind: 'label', id: 'mate', name: 'mate' })],
    }));
    const K1 = await boot(store);
    expect(K1.state.goals.map(g => g.id)).toEqual(['goal-mate']);
    const saved = JSON.parse(store.get(KEY));
    expect(saved.labels[0].kind).toBe('area');
    expect(saved.goals).toHaveLength(1);
    const K2 = await boot(store);
    expect(K2.state.goals).toHaveLength(1);
    expect(K2.state.sessions[0].target).toMatchObject({ kind: 'goal', id: 'goal-mate' });
  });
});

describe('objetivos: proyectos, pendientes y recursos', () => {
  it('crea un objetivo con solo nombre y le agrega proyectos y pendientes', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Aprobar Matemática', category: 'academica' });
    expect(K.goalById(g.id)).toMatchObject({ name: 'Aprobar Matemática', archived: false, projects: [] });
    const p = K.addProject(g, 'Parcial 1', '2026-11-02');
    expect(K.goalById(g.id).projects[0]).toMatchObject({ name: 'Parcial 1', deadline: '2026-11-02' });
    K.addTasks([{ text: 'Repasar derivadas', due: null }], { goalId: g.id, projectId: p.id });
    expect(K.projectTasks(K.goalById(g.id), p.id).map(t => t.text)).toEqual(['Repasar derivadas']);
    expect(K.projectTasks(K.goalById(g.id), null)).toHaveLength(0);
    expect(K.goalProgress(K.goalById(g.id))).toEqual({ done: 0, total: 1 });
  });

  it('quitar un proyecto no borra sus pendientes ni recursos: pasan al bloque General', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Reforma' });
    const p = K.addProject(g, 'Cocina');
    K.addTasks([{ text: 'Cotizar mesada', due: null }], { goalId: g.id, projectId: p.id });
    K.addResourceLink(K.goalById(g.id), p.id, 'Presupuesto', 'https://ejemplo.com/p');
    K.removeProject(K.goalById(g.id), p.id);
    const cur = K.goalById(g.id);
    expect(cur.projects).toHaveLength(0);
    expect(K.projectTasks(cur, null).map(t => t.text)).toEqual(['Cotizar mesada']);
    expect(K.projectResources(cur, null)).toHaveLength(1);
  });

  it('borrar un objetivo deja sus pendientes sueltos, y el deshacer los devuelve a su lugar', async () => {
    const undos = [];
    const K = await boot(new Map(), (msg, undo) => { if (undo) undos.push(undo); });
    const g = K.createGoal({ name: 'Correr 10 km' });
    const p = K.addProject(g, 'Semana 1');
    K.addTasks([{ text: 'Salir a correr', due: null }], { goalId: g.id, projectId: p.id });
    const task1 = K.state.tasks[0];
    K.removeGoal(K.goalById(g.id));
    expect(K.goalById(g.id)).toBeNull();
    expect(task1.goalId).toBeNull();
    expect(task1.projectId).toBeNull();
    undos.at(-1)();
    expect(K.goalById(g.id).projects).toHaveLength(1);
    expect(task1.goalId).toBe(g.id);
    expect(task1.projectId).toBe(p.id);
  });

  it('un enlace solo se acepta con http(s); una nota no se agrega dos veces al mismo bloque', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Idiomas' });
    expect(K.addResourceLink(K.goalById(g.id), null, 'Mal', 'javascript:alert(1)')).toBe(false);
    expect(K.addResourceLink(K.goalById(g.id), null, 'Bien', 'https://ejemplo.com')).toBe(true);
    K.state.notes.push({ id: 'n1', title: 'Vocabulario', body: '', links: [], labels: [], pinned: false, archived: false, trashed: false,
      collapsed: [], doneAt: {}, order: 0, createdAt: NOW, updatedAt: NOW, rev: 0 });
    K.addResourceNote(K.goalById(g.id), null, 'n1');
    K.addResourceNote(K.goalById(g.id), null, 'n1');
    expect(K.goalById(g.id).resources.filter(r => r.kind === 'note')).toHaveLength(1);
    expect(K.goalById(g.id).resources.filter(r => r.kind === 'link')).toHaveLength(1);
  });

  it('un pendiente vinculado a un proyecto que ya no existe queda solo con el objetivo', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Ahorro' });
    const t = task('x', { goalId: g.id, projectId: 'no-existe' });
    K.state.tasks.push(t);
    K.setTaskGoal(t, g.id, 'no-existe');
    expect(K.taskById('x').projectId).toBeNull();
    expect(K.taskById('x').goalId).toBe(g.id);
  });
});

describe('Foco y Métricas atribuyen el tiempo a un objetivo', () => {
  it('goalOfTarget: objetivo, proyecto, pendiente con objetivo; etiqueta no cuenta como objetivo', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Inglés' });
    const p = K.addProject(g, 'Unidad 3');
    K.state.tasks.push(task('t9', { goalId: g.id }));
    expect(K.goalOfTarget({ kind: 'goal', id: g.id })).toBe(g.id);
    expect(K.goalOfTarget({ kind: 'project', id: p.id })).toBe(g.id);
    expect(K.goalOfTarget({ kind: 'task', id: 't9' })).toBe(g.id);
    expect(K.goalOfTarget({ kind: 'label', id: 'x' })).toBeNull();
  });

  it('metricsData suma el foco de la semana por objetivo', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Matemática' });
    K.state.sessions.push(sess('s1', { kind: 'goal', id: g.id, name: g.name }, 25 * 60000));
    K.state.tasks.push(task('t2', { goalId: g.id }));
    K.state.sessions.push(sess('s2', { kind: 'task', id: 't2', text: 'x' }, 5 * 60000));
    const m = K.metricsData();
    expect(m.goals).toEqual([expect.objectContaining({ name: 'Matemática', min: 30 })]);
  });
});

describe('respaldo: objetivos se exportan, se importan y las materias viejas se convierten', () => {
  it('la copia incluye objetivos con su proyecto y el pendiente vinculado; otra instalación los recupera', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Tesis' });
    const p = K.addProject(g, 'Capítulo 1');
    K.addTasks([{ text: 'Escribir introducción', due: null }], { goalId: g.id, projectId: p.id });
    const data = JSON.parse(await K.buildExport());
    expect(data.goals).toHaveLength(1);

    const K2 = await boot();
    const res = await K2.mergeData(K2.normalizeImport(data));
    expect(res.invalid).toBe(0);
    const g2 = K2.goalById(g.id);
    expect(g2.name).toBe('Tesis');
    expect(g2.projects[0].name).toBe('Capítulo 1');
    expect(K2.state.tasks[0]).toMatchObject({ goalId: g.id, projectId: p.id });
  });

  it('un respaldo viejo con una materia la importa como objetivo académico', async () => {
    const K = await boot();
    const res = await K.mergeData(K.normalizeImport({
      version: 6, notes: [],
      labels: [{ id: 'fis', name: 'Física', kind: 'materia' }],
      sessions: [{ id: 'sf', start: NOW - 60000, end: NOW, ms: 60000, target: { kind: 'label', id: 'fis', name: 'Física' } }],
    }));
    expect(res.invalid).toBe(0);
    const goal = K.state.goals[0];
    expect(goal).toMatchObject({ category: 'academica', name: 'Física' });
    expect(K.state.labels.find(l => l.name === 'Física').kind).toBe('area');
    expect(K.state.sessions.find(s => s.id === 'sf').target).toMatchObject({ kind: 'goal', id: goal.id });
  });

  it('un objetivo inválido en el respaldo (fecha imposible) se cuenta como inválido y no se importa', async () => {
    const K = await boot();
    const res = await K.mergeData(K.normalizeImport({
      version: 6, notes: [], goals: [{ id: 'g-bad', name: 'Mal', deadline: '2026-02-31' }],
    }));
    expect(res.invalid).toBe(1);
    expect(K.goalById('g-bad')).toBeNull();
  });
});

describe('1.24.1: archivar reemplaza al estado', () => {
  it('al leer, "completado" pasa a archivado y "activo" o "pausado" quedan activos; el estado desaparece', async () => {
    const K = await boot();
    const done = K.normalizeGoal({ id: 'a', name: 'Viejo', status: 'completado' });
    const pausa = K.normalizeGoal({ id: 'b', name: 'Pausa', status: 'pausado' });
    const act = K.normalizeGoal({ id: 'c', name: 'Activo', status: 'activo' });
    expect(done).toMatchObject({ archived: true });
    expect(pausa).toMatchObject({ archived: false });
    expect(act).toMatchObject({ archived: false });
    expect('status' in done).toBe(false);
  });

  it('archivar y desarchivar cambian el campo y lo guardan; un objetivo archivado no se sugiere en Foco', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Viaje a Japón' });
    K.updateGoal(g, { archived: true });
    expect(K.goalById(g.id).archived).toBe(true);
    await settle();
    const K2 = await boot(K.__testStorage);
    expect(K2.goalById(g.id).archived).toBe(true);
    K2.updateGoal(K2.goalById(g.id), { archived: false });
    expect(K2.goalById(g.id).archived).toBe(false);
  });
});

describe('1.24.1: orden de proyectos (subir y bajar)', () => {
  it('moveProject intercambia el orden con el vecino y no hace nada en los extremos', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Tesis' });
    const a = K.addProject(g, 'Capítulo 1');
    const b = K.addProject(g, 'Capítulo 2');
    const c = K.addProject(g, 'Capítulo 3');
    K.moveProject(K.goalById(g.id), c.id, -1);
    expect(K.goalProjects(K.goalById(g.id)).map(p => p.name)).toEqual(['Capítulo 1', 'Capítulo 3', 'Capítulo 2']);
    K.moveProject(K.goalById(g.id), a.id, -1);
    expect(K.goalProjects(K.goalById(g.id)).map(p => p.name)).toEqual(['Capítulo 1', 'Capítulo 3', 'Capítulo 2']);
    K.moveProject(K.goalById(g.id), b.id, 1);
    expect(K.goalProjects(K.goalById(g.id)).map(p => p.id)).toEqual([a.id, c.id, b.id]);
    expect(K.goalById(g.id).projects.map(p => p.order).sort()).toEqual([0, 1, 2]);
  });

  it('el orden sobrevive a recargar la app', async () => {
    const store = new Map();
    const K = await boot(store);
    const g = K.createGoal({ name: 'Curso' });
    const a = K.addProject(g, 'Módulo A');
    K.addProject(g, 'Módulo B');
    K.moveProject(K.goalById(g.id), a.id, 1);
    await settle();
    const K2 = await boot(store);
    expect(K2.goalProjects(K2.goalById(g.id)).map(p => p.name)).toEqual(['Módulo B', 'Módulo A']);
  });
});

describe('1.24.1: duplicar proyectos', () => {
  it('copia nombre, fecha y recursos; los pendientes vuelven sin tildar y sin fecha; las rutinas no se copian', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Idiomas' });
    const p = K.addProject(g, 'Semana 1', '2026-11-02');
    K.addResourceLink(K.goalById(g.id), p.id, 'Audios', 'https://ejemplo.com/audios');
    K.state.blocks.push({ id: 'blk', title: 'Estudio', repeat: { type: 'weekly', days: [0] }, labels: [], start: 540, end: 600 });
    K.state.tasks.push(task('t1', { goalId: g.id, projectId: p.id, text: 'Repasar', due: '2026-11-01', done: true, doneAt: NOW, labels: ['lx'] }));
    K.state.tasks.push(task('t2', { goalId: g.id, projectId: p.id, text: 'Rutina diaria', blockId: 'blk' }));

    const copy = K.duplicateProject(K.goalById(g.id), p.id);
    const cur = K.goalById(g.id);
    expect(copy).toMatchObject({ name: 'Semana 1 (copia)', deadline: '2026-11-02' });
    expect(K.goalProjects(cur).map(x => x.id)).toEqual([p.id, copy.id]);

    const links = cur.resources.filter(r => r.projectId === copy.id);
    expect(links).toHaveLength(1);
    expect(links[0]).toMatchObject({ kind: 'link', url: 'https://ejemplo.com/audios' });
    expect(links[0].id).not.toBe(cur.resources.find(r => r.projectId === p.id).id);

    const copied = K.projectTasks(cur, copy.id);
    expect(copied.map(t => t.text)).toEqual(['Repasar']);
    expect(copied[0]).toMatchObject({ done: false, due: null, labels: ['lx'], goalId: g.id });
    expect(K.taskById('t1').done).toBe(true);
  });

  it('el duplicado sobrevive a recargar la app', async () => {
    const store = new Map();
    const K = await boot(store);
    const g = K.createGoal({ name: 'Gimnasio' });
    const p = K.addProject(g, 'Piernas');
    K.duplicateProject(K.goalById(g.id), p.id);
    await settle();
    const K2 = await boot(store);
    expect(K2.goalById(g.id).projects.map(x => x.name)).toEqual(['Piernas', 'Piernas (copia)']);
  });
});

describe('1.24.2: pendientes en bloque dentro de Objetivos', () => {
  it('cada línea del texto es un pendiente (igual que en Pendientes), y las viñetas se quitan', async () => {
    const K = await boot();
    const g = K.createGoal({ name: 'Libro' });
    const p = K.addProject(g, 'Capítulo 1');
    const items = K.parseCapture('- Leer la introducción\n[ ] Citar a Smith\n\n  Revisar figuras  ');
    K.addTasks(items, { goalId: g.id, projectId: p.id });
    expect(K.projectTasks(K.goalById(g.id), p.id).map(t => t.text)).toEqual(['Leer la introducción', 'Citar a Smith', 'Revisar figuras']);
  });

  it('un objetivo guardado con notas de 1.24.1 las descarta al leerlo', async () => {
    const K = await boot();
    const g = K.normalizeGoal({ id: 'gx', name: 'Viejo', notes: [{ id: 'n', text: 'algo' }] });
    expect('notes' in g).toBe(false);
  });
});
