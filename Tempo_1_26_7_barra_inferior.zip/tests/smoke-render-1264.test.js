/* Humo de render (1.26.4): Hoy y Calendario dibujan rutinas y franjas del mismo modelo sin errores. */
import { describe, it, expect } from 'vitest';
import { loadApp } from './load-app.js';

describe('1.26.4: Hoy y Calendario leen el mismo modelo', () => {
  it('el día de una franja y de una rutina se dibuja sin errores y la franja no aparece como rutina', () => {
    const K = loadApp();
    const today = K.todayYmd();
    K.state.blocks = [
      K.unifyBlock({ id: 'rut', title: 'Clase', days: [new Date().getDay() === 0 ? 6 : (new Date().getDay() + 6) % 7], start: 480, end: 540, color: null, labels: [], notes: [] }),
      K.unifySlot({ id: 'fr', date: today, title: 'Estudiar', start: 600, end: 660, color: null, labels: [], notes: [] }),
    ];
    expect(K.slotsOn(today).map(s => s.id)).toEqual(['rut', 'fr']);   // Hoy muestra rutinas y franjas juntas, por hora
    expect(K.isWeekly(K.blockById('rut'))).toBe(true);
    expect(K.routineChoices().map(b => b.id)).toEqual(['rut']);
    expect(() => K.renderList && K.renderList()).not.toThrow();
  });
});
