/* Reglas de importación y de horas: funciones puras o con almacenamiento en memoria. */
import { describe, it, expect } from 'vitest';
import { loadApp } from './load-app.js';

describe('K.resolveRecord: qué hace una importación con un registro existente', () => {
  const rec = { id: 'x', text: 'Uno', rev: 3 };
  it('si no existe localmente, se agrega', () => {
    expect(loadApp().resolveRecord(undefined, rec, null, 100)).toBe('add');
  });
  it('si el contenido es igual (ignorando rev y updatedAt), no cambia nada', () => {
    const K = loadApp();
    expect(K.resolveRecord({ ...rec, rev: 9, updatedAt: 5 }, rec, 5, 100)).toBe('same');
  });
  it('el más reciente gana: reemplaza si el archivo es más nuevo', () => {
    const K = loadApp();
    expect(K.resolveRecord({ ...rec, text: 'Local' }, rec, 50, 100)).toBe('replace');
  });
  it('si el local es más nuevo, se conserva', () => {
    const K = loadApp();
    expect(K.resolveRecord({ ...rec, text: 'Local' }, rec, 200, 100)).toBe('kept');
  });
  it('sin fecha comparable (faltante, inválida o negativa) es conflicto: se conserva el local', () => {
    const K = loadApp();
    const local = { ...rec, text: 'Local' };
    expect(K.resolveRecord(local, rec, null, 100)).toBe('conflict');
    expect(K.resolveRecord(local, rec, 50, null)).toBe('conflict');
    expect(K.resolveRecord(local, rec, NaN, 100)).toBe('conflict');
    expect(K.resolveRecord(local, rec, 50, -1)).toBe('conflict');
  });
  it('mismo instante con contenido distinto también es conflicto', () => {
    const K = loadApp();
    expect(K.resolveRecord({ ...rec, text: 'Local' }, rec, 100, 100)).toBe('conflict');
  });
});

describe('horas en minutos enteros', () => {
  it('una hora fraccionaria no se acepta al importar bloques ni eventos', async () => {
    const K = loadApp();
    const r = await K.mergeData(K.normalizeImport({ version: 6, notes: [],
      blocks: [{ id: 'b-frac', title: 'x', days: [0], start: 540.5, end: 600, labels: [], notes: [] }],
      events: [{ id: 'e-frac', date: '2026-10-15', time: 600.5, title: 'x' }] }));
    expect(r.invalid).toBe(2);
    expect(K.state.blocks).toEqual([]);
    expect(K.state.events).toEqual([]);
  });

  it('el calendario .ics solo genera fechas y horas con seis dígitos', () => {
    const cap = [];
    class CapBlob { constructor(parts) { cap.push(parts.join('')); } }
    const K = loadApp(undefined, { Blob: CapBlob });
    K.state.blocks = [{ id: 'b1', title: 'Estudio', repeat: { type: 'weekly', days: [0, 2] }, start: 540, end: 600, labels: [], notes: [], color: null }];
    K.state.events = [{ id: 'e1', title: 'Parcial', date: '2026-10-15', time: 600, labels: [], notes: [] }];
    K.exportICS();
    const lines = cap[0].split(/\r\n/).filter(l => /^DT(START|END)/.test(l));
    expect(lines.length).toBeGreaterThan(0);
    lines.forEach(l => expect(l.split(':').pop()).toMatch(/^\d{8}T\d{6}$/));
  });
});
