/* 1.25.1: lógica de la interfaz de notas y pendientes (vista, lote, selección, hora, captura). */
import { describe, it, expect } from 'vitest';
import { loadApp } from './load-app.js';

const note = (id, over = {}) => ({
  id, title: 'T ' + id, body: '', links: [], labels: [], collapsed: [], doneAt: {},
  pinned: false, archived: false, trashed: false, trashedAt: null, order: 0, createdAt: 1, updatedAt: 1, rev: 0, ...over,
});
function quiet(opts = {}) {
  const K = loadApp(undefined, opts);
  K.refreshAll = () => {};
  K.refresh = () => {};
  K.toast = (msg, undo) => { K.lastToast = { msg, undo }; };
  return K;
}

describe('pendientes: hora con @H:MM', () => {
  it('la hora se saca del texto y se guarda aparte; una hora inválida queda en el texto', () => {
    const K = quiet();
    const out = K.parseCapture('Llamar al banco @9:30\nCita @25:00\nSin hora');
    expect(out).toEqual([
      { text: 'Llamar al banco', due: null, time: '09:30' },
      { text: 'Cita @25:00', due: null },
      { text: 'Sin hora', due: null },
    ]);
  });

  it('la hora llega al pendiente que se crea', () => {
    const K = quiet();
    K.addTasks([{ text: 'x', due: null, time: '10:00' }, { text: 'y', due: null }]);
    expect(K.state.tasks.map(t => t.time)).toEqual(['10:00', null]);
  });
});

describe('vista de notas: renglones o cuadros', () => {
  it('por defecto son renglones; la elección se guarda en este navegador', () => {
    const store = new Map();
    const K = quiet({ store });
    expect(K.noteView()).toBe('rows');
    K.setNoteView('cards');
    expect(K.noteView()).toBe('cards');
    expect(loadApp(undefined, { store }).noteView()).toBe('cards');
  });
});

describe('selección y acciones en lote', () => {
  it('la selección se borra al cambiar de vista, y se conserva dentro de la misma', () => {
    const K = quiet();
    K.state.route = { name: 'all' };
    K.resetSelIfRouteChanged();
    K.state.sel = ['a'];
    K.resetSelIfRouteChanged();
    expect(K.state.sel).toEqual(['a']);
    K.state.route = { name: 'trash' };
    K.resetSelIfRouteChanged();
    expect(K.state.sel).toEqual([]);
  });

  it('toggleSel suma y quita', () => {
    const K = quiet();
    K.state.sel = [];
    K.toggleSel('a'); K.toggleSel('b'); K.toggleSel('a');
    expect(K.state.sel).toEqual(['b']);
  });

  it('batchChange cambia todas las notas, limpia la selección y el aviso deshace el cambio', () => {
    const K = quiet();
    const a = note('a'), b = note('b');
    K.state.notes = [a, b];
    K.state.sel = ['a', 'b'];
    K.batchChange([a, b], n => { n.pinned = true; n.archived = false; }, 'Notas fijadas');
    expect(a.pinned && b.pinned).toBe(true);
    expect(K.state.sel).toEqual([]);
    expect(K.lastToast.msg).toBe('Notas fijadas');
    K.lastToast.undo();
    expect(a.pinned || b.pinned).toBe(false);
  });

  it('enviar varias a la papelera guarda la fecha en cada una', () => {
    const K = quiet();
    const a = note('a'), b = note('b');
    K.state.notes = [a, b];
    K.batchChange([a, b], n => { n.trashed = true; n.trashedAt = 5; }, 'ok');
    expect(a.trashed && b.trashed && a.trashedAt === 5).toBe(true);
  });
});

describe('captura: la nota nueva puede no heredar la etiqueta de la vista', () => {
  it('por defecto hereda; con la preferencia activada no', () => {
    const store = new Map();
    const K = quiet({ store });
    expect(K.capNoLabel()).toBe(false);
    K.setCapNoLabel(true);
    expect(loadApp(undefined, { store }).capNoLabel()).toBe(true);
  });
});
