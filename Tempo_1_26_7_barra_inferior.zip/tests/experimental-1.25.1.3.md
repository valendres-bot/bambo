# Tempo 1.25.1.3 — experimental: Hoy como inicio y captura sin fricción

## Idea principal que se recoge
Tempo convierte lo que querés lograr en lo que hacés hoy, y muestra cuánto tiempo le dedicaste.
El recorrido es: **qué hago hoy → lo empiezo con foco → veo cuánto le di**. Las notas son la memoria de respaldo.

## Cambios
- **Inicio = Hoy.** Antes se abría en Notas. Ahora `#/` y las rutas desconocidas abren Hoy. Notas vive en `#/notas`. Las rutas viejas (`#/none`, `#/events`) siguen funcionando.
- **Hoy con un siguiente paso.** La primera tarea de hoy aparece arriba con *Empezar enfoque* (arranca el temporizador con esa tarea) y *Hecha*. Si no hay nada urgente, lo dice y ofrece ir a Foco.
- **Resumen de una línea:** pendientes para hoy y minutos de foco del día; cada uno lleva a su pantalla.
- **Captura simple:** un solo campo, altura automática. Enter agrega en escritorio; Shift+Enter agrega otra línea; Ctrl/⌘+Enter agrega siempre. En celular, Enter hace línea nueva y se toca *Agregar*. *Vence* (Hoy, Mañana, Sin fecha, Elegir fecha) es un solo control. La rutina del lote pasa a *Más opciones*. La vista previa aparece solo con varias líneas.
- **Hechas plegadas** por defecto, y la acción de vaciarlas dice *Eliminar hechas*.
- **Barra lateral agrupada:** Hacer (Hoy, Foco) · Planear (Objetivos, Calendario) · Registro (Notas, Métricas). El contador de Hoy muestra lo que falta.
- **Foco:** al elegir en qué trabajar, los pendientes de hoy aparecen primero. El aviso de la extensión Bloqueador horario pasó a Duraciones.
- **Atajos:** `N` en Hoy lleva el cursor a la captura; `F` va a Foco; el botón (+) en Hoy lleva el cursor a la captura.
- **Visual:** un acento cálido (`--go`) solo para lo que empuja a actuar: el siguiente paso, el anillo de Foco y el contador. Las pausas conservan verde y azul.
- **Textos:** la pantalla de pendientes se llama Hoy en toda la interfaz. El concepto "pendientes" no cambia.
- **Arreglo:** en celular, la pista de atajo quedaba cortada ("para agregar" suelto). Ahora depende del dispositivo.

## Límites deliberados
- Sin cambios en el modelo de datos ni en el formato de respaldo.
- Sin dependencias nuevas, sin telemetría, sin solicitudes de red nuevas.
- No se tocaron Objetivos, Calendario ni Métricas a nivel de interacción.
- El (+) del celular fuera de Hoy y de Notas sigue oculto, como antes.

## Verificación
- `node scripts/release.mjs --check`: OK (1.25.1.3).
- Pruebas de lógica (Vitest): 107 de 107 pasan (102 de la base más 5 nuevas de enrutado en `tests/inicio-1253.test.js`).
- Capturas en navegador (Chromium) de las 8 pantallas, en escritorio 1440×900 y móvil 390×844, con y sin datos: sin errores de consola ni de red.
- Pendiente: recorrido manual en un teléfono real (teclado, Enter en celular) y en Safari, que no se pudo probar aquí.

## Criterios de aceptación manual
1. Abrir la app: aparece Hoy, con el siguiente paso si hay pendientes.
2. Escribir un pendiente y apretar Enter: se agrega sin pasos extra.
3. Shift+Enter, escribir dos líneas, Enter: se agregan las dos.
4. *Empezar enfoque* abre Foco con la tarea como objetivo y el temporizador en marcha.
5. En celular, Enter hace línea nueva y *Agregar* crea los pendientes.
6. `N` en Hoy enfoca la captura; `F` abre Foco.
7. La barra lateral muestra Hacer / Planear / Registro, y el contador de Hoy coincide con lo pendiente.
