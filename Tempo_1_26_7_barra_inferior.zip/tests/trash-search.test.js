/* 1.25.1: papelera a los 7 días, búsqueda de la vista sin etiquetas y paleta con etiquetas. */
import { describe, it, expect } from 'vitest';
import { loadApp } from './load-app.js';

const DAY = 24 * 60 * 60 * 1000;
const note = (id, over = {}) => ({
  id, title: 'T ' + id, body: '', links: [], labels: [], collapsed: [], doneAt: {},
  pinned: false, archived: false, trashed: false, trashedAt: null, order: 0, createdAt: 1, updatedAt: 1, rev: 0, ...over,
});
const quiet = K => { K.refresh = () => {}; K.toast = () => {}; return K; };

describe('papelera: se vacía sola a los 7 días', () => {
  it('enviar a la papelera guarda la fecha y restaurar la borra', () => {
    const K = quiet(loadApp());
    const n = note('a'); K.state.notes = [n];
    K.trashNote(n);
    expect(n.trashed).toBe(true);
    expect(Number.isFinite(n.trashedAt)).toBe(true);
    K.restoreNote(n);
    expect(n.trashedAt).toBeNull();
  });

  it('purga las vencidas (más de 7 días) y conserva las recientes y las que no están en la papelera', () => {
    const K = quiet(loadApp());
    const now = 100 * DAY;
    K.state.notes = [
      note('vieja', { trashed: true, trashedAt: now - 8 * DAY }),
      note('reciente', { trashed: true, trashedAt: now - 6 * DAY }),
      note('viva', { trashedAt: now - 30 * DAY }),
    ];
    expect(K.purgeTrash(now)).toBe(1);
    expect(K.state.notes.map(n => n.id)).toEqual(['reciente', 'viva']);
  });

  it('una nota de la papelera sin fecha (de antes de 1.25.1) arranca el plazo desde la primera revisión', () => {
    const K = quiet(loadApp());
    const now = 100 * DAY;
    const legacy = note('legacy', { trashed: true });
    K.state.notes = [legacy];
    expect(K.purgeTrash(now)).toBe(0);
    expect(legacy.trashedAt).toBe(now);
    expect(K.purgeTrash(now + 7 * DAY)).toBe(1);
    expect(K.state.notes).toEqual([]);
  });
});

describe('búsqueda: la vista no mira las etiquetas, la paleta sí', () => {
  it('el filtro de la vista busca título y cuerpo; la paleta también busca los nombres de las etiquetas', () => {
    const K = quiet(loadApp());
    K.state.labels = [{ id: 'l1', name: 'Física', color: null, kind: 'area', pinned: false, archived: false, deleted: false }];
    const n = note('x', { title: 'Apuntes', body: 'vectores y fuerzas', labels: ['l1'] });
    expect(K.matchNorm(K.viewNorm(n), K.tokens('vectores'))).toBe(true);
    expect(K.matchNorm(K.viewNorm(n), K.tokens('fisica'))).toBe(false);
    expect(K.matchNorm(K.searchNorm(n), K.tokens('fisica'))).toBe(true);
  });
});
