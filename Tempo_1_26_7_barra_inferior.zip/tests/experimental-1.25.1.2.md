# Tempo 1.25.1.2 — experimental UX pass

## Intención
Reducir carga cognitiva y fricción sin cambiar el modelo de datos, añadir dependencias ni introducir telemetría.

## Cambios
- Ajuste de jerarquía visual y navegación lateral: selección activa más legible, espaciado más consistente y menos peso en elementos secundarios.
- Barra superior y contenido con ritmo y anchura más cómodos.
- Captura de pendientes más clara, con mejor área de escritura, controles más cómodos y placeholder orientado a capturar ideas reales.
- Secciones de pendientes con separación visual y legibilidad más consistentes.
- Ajustes responsive para móvil, controles táctiles y respeto a `prefers-reduced-motion`.
- Hoja aislada `css/experimental.css` para revertir la capa experimental sin desarmar los estilos existentes.
- Versión experimental de cuatro componentes `1.25.1.2`; el verificador de release ahora admite versiones de tres o cuatro componentes.

## Límites deliberados
- Sin migraciones ni cambios en datos guardados.
- Sin dependencias nuevas.
- Sin telemetría ni solicitudes de red nuevas.
- No se rediseñaron aún editor, calendario, Foco, métricas y objetivos a nivel de interacción: necesitan revisión individual para evitar cambios superficiales que rompan flujos.

## Verificación
- `node scripts/release.mjs --check`: OK.
- Verificación sintáctica de JavaScript: pendiente de ejecutar al empaquetar.
- Suite automatizada: no ejecutada en este entorno porque las dependencias locales no estaban instaladas y `npm ci` no terminó dentro del límite de ejecución.
- Revisión visual real en escritorio y móvil: pendiente; no se debe considerar validada por los tests de lógica.

## Criterios de aceptación manual
1. Capturar uno o varios pendientes, con fecha y sin fecha.
2. Revisar que no se corte el área de captura a 320 px de ancho.
3. Verificar navegación, menú lateral y controles de notas en claro y oscuro.
4. Verificar foco visible por teclado y que las animaciones respeten la preferencia de movimiento reducido.
5. Confirmar que el service worker instala la nueva caché con `experimental.css`.

## Segunda pasada de rediseño (16/10/2026)
- Rediseño visual extendido a Hoy/captura, listas y editor de notas, Foco, objetivos, calendario, métricas y configuración.
- Se redujo el placeholder de captura a una sola instrucción para no anticipar ejemplos ni dirigir el uso.
- Se ajustaron estados de foco por teclado, objetivos táctiles y layouts de móvil.
- Sin cambios en el modelo de datos, dependencias de producción ni telemetría.
- `node --check` en todos los JS y scripts: OK.
- `node scripts/release.mjs --check`: OK.
- Suite de Vitest: no ejecutada; `npm ci` excedió el límite de tiempo y Vitest no quedó disponible.
- Inspección visual en navegador real: sigue pendiente; los cambios son experimentales y deben validarse en escritorio y móvil antes de considerarlos cerrados.

## Tercera pasada de interacción (16/10/2026)
- La captura ahora explica el atajo Ctrl/⌘ + Enter sin convertirlo en una instrucción dominante; el campo lo referencia mediante `aria-describedby`.
- La ayuda del atajo se oculta en pantallas angostas para no consumir espacio vertical ni mostrar una instrucción de teclado poco útil en móvil.
- La hoja experimental mantiene el estilo de la ayuda alineado con tokens existentes y respeta el tamaño de pantalla.
- `node --check` en todos los JS y scripts: OK.
- `node scripts/release.mjs --check`: OK.
- Suite de pruebas: no ejecutable en este entorno (`vitest: not found`); no se considera aprobada.

## Cuarta pasada de interacción (16/10/2026)
- Se agregó «Editar texto» al menú de cada pendiente. La edición ocurre en la propia fila, sin diálogo; Enter guarda, Escape cancela y al salir del campo se guardan los cambios.
- La edición conserva el registro y sus vínculos (fecha, rutina, objetivo y proyecto); solo modifica `text` y actualiza `updatedAt` mediante `K.persistTask`.
- El título de nota aclara que es opcional y el texto vacío del editor invita a escribir sin imponer una estructura.
- Se añadieron estilos de edición inline con un objetivo táctil mayor en móvil.
- `node --check` para todos los JS y scripts: OK.
- `node scripts/release.mjs --check`: OK.
- Suite automatizada no ejecutada: Vitest no está instalado en el entorno.
- Validación visual real pendiente.


## Quinta pasada de interacción (16/10/2026)
- En las filas de notas, «Etiquetas» pasa a ser una acción directa de un clic; fijar sigue directo y archivar/papelera quedan agrupados en ⋯ para mantener una jerarquía simple.
- El selector de etiquetas prioriza primero las etiquetas ya asignadas y después las fijadas, manteniendo el orden configurado para el resto. Así se reducen búsquedas repetidas sin agregar controles ni cambiar datos.
- El botón «Listo» del editor pasa a «Cerrar» y aclara con su etiqueta accesible que los cambios se guardan automáticamente.
- Sin migraciones, dependencias, telemetría ni cambios de modelo de datos.
- Validación de sintaxis y release pendiente de ejecutar tras el cambio; suite y revisión visual real también pendientes.

## Sexta pasada de estabilidad (16/10/2026)
- En celulares angostos, los controles del encabezado del editor quedan con un área táctil mínima de 40 px; el botón «Cerrar» conserva su texto completo. La lista de notas sigue despejada: no se muestran acciones por fila en móvil.
- Se eliminó un comentario duplicado en el editor sin cambiar comportamiento.
- Validación de sintaxis y consistencia del release ejecutadas después de estos retoques.
- La suite de Vitest y la inspección visual en navegador real siguen pendientes en este entorno; no se declara estabilidad validada hasta completar esas comprobaciones.
