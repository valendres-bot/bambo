import { describe, it, expect } from 'vitest';
import { loadApp } from './load-app.js';

describe('agenda movement API', () => {
  it('exposes a single move operation for one-off and weekly destinations', () => {
    const K = loadApp();
    expect(typeof K.moveTaskInAgenda).toBe('function');
  });
});
