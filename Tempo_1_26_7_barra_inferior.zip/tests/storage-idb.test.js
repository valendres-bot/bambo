/* Pruebas de integración del almacenamiento con IndexedDB.
   IMPORTANTE: IndexedDB aquí es fake-indexeddb (implementación en memoria de la especificación).
   Verifica transacciones, aperturas y lecturas fallidas, pero NO reemplaza probar en un navegador real. */
import { describe, it, expect } from 'vitest';
import { IDBFactory } from 'fake-indexeddb';
import { loadApp } from './load-app.js';

const NOW = Date.now(), DAY = 864e5;
const KEY = 'mi-keep:v4';
const COLLS = ['notes', 'labels', 'blocks', 'events', 'sessions', 'versions', 'tasks', 'goals', 'slots'];
const note = (id, over = {}) => ({ id, title: 'T ' + id, body: 'cuerpo ' + id, links: [], labels: [], collapsed: [], doneAt: {},
  pinned: false, archived: false, trashed: false, order: 0, createdAt: NOW - 5 * DAY, updatedAt: NOW - 5 * DAY, ...over });
const task = (id, over = {}) => ({ id, text: 'Tarea ' + id, due: null, done: false, doneAt: null, blockId: null, labels: [],
  doneDays: {}, createdAt: NOW - 5 * DAY, updatedAt: NOW - 5 * DAY, ...over });

/* Fábrica de IndexedDB con fallos inyectables:
   · failPutAt = k: la k-ésima escritura de la sesión lanza de forma síncrona (como un DataCloneError real).
   · failOpen: la apertura falla. · failReadOnce: la próxima lectura falla una sola vez. */
function faultyIdb(base = new IDBFactory()) {
  const ctrl = { base, failPutAt: 0, puts: 0, failOpen: false, failReadOnce: false };
  const wrapStore = s => new Proxy(s, {
    get(o, p) {
      if (p === 'put') return (val, key) => {
        ctrl.puts++;
        if (ctrl.failPutAt && ctrl.puts === ctrl.failPutAt) throw new Error('escritura simulada');
        return o.put(val, key);
      };
      const v = o[p]; return typeof v === 'function' ? v.bind(o) : v;
    },
    set(o, p, v) { o[p] = v; return true; },
  });
  const wrapTx = t => new Proxy(t, {
    get(o, p) {
      if (p === 'objectStore') return name => wrapStore(o.objectStore(name));
      const v = o[p]; return typeof v === 'function' ? v.bind(o) : v;
    },
    set(o, p, v) { o[p] = v; return true; },
  });
  ctrl.open = (name, version) => {
    if (ctrl.failOpen) {
      const req = {};
      setTimeout(() => { req.error = new Error('apertura simulada'); if (req.onerror) req.onerror(); }, 0);
      return req;
    }
    const req = base.open(name, version);
    let handler = null;
    Object.defineProperty(req, 'onsuccess', {
      configurable: true,
      get: () => handler,
      set: fn => {
        handler = e => {
          const db = req.result;
          const origTx = db.transaction.bind(db);
          db.transaction = (names, mode) => {
            if (ctrl.failReadOnce && mode === 'readonly') { ctrl.failReadOnce = false; throw new Error('lectura simulada'); }
            const t = origTx(names, mode);
            return mode === 'readwrite' ? wrapTx(t) : t;
          };
          fn(e);
        };
      },
    });
    return req;
  };
  return ctrl;
}

/* Sesión de la app: una instancia nueva sobre el mismo "disco" (IndexedDB) y el mismo localStorage */
function session({ idb, store = new Map(), msgs = [] } = {}) {
  const K = loadApp(undefined, { indexedDB: idb, store, toast: m => msgs.push(m) });
  return { K, store, msgs };
}
async function boot(opts) {
  const s = session(opts);
  s.K.applyData(await s.K.api.load());
  return s;
}

/* Lo que hay en el disco, sin normalizar: para comparar byte a byte antes y después de un fallo */
function dump(base) {
  return new Promise((resolve, reject) => {
    const r = base.open('tempo', 5);
    r.onerror = () => reject(r.error);
    r.onsuccess = () => {
      const db = r.result;
      const t = db.transaction([...COLLS, 'kv'], 'readonly');
      const out = {};
      COLLS.forEach(c => {
        const q = t.objectStore(c).getAll();
        q.onsuccess = () => { out[c] = q.result.slice().sort((a, b) => String(a.id).localeCompare(String(b.id))); };
      });
      t.oncomplete = () => { db.close(); resolve(out); };
      t.onerror = () => reject(t.error);
    };
  });
}

/* Escribe registros crudos (sin metadatos de la app) para preparar datos antiguos o incompletos */
function rawPut(base, recs) {
  return new Promise((resolve, reject) => {
    const r = base.open('tempo', 5);
    r.onupgradeneeded = () => {
      COLLS.forEach(c => { if (!r.result.objectStoreNames.contains(c)) r.result.createObjectStore(c, { keyPath: 'id' }); });
      if (!r.result.objectStoreNames.contains('kv')) r.result.createObjectStore('kv');
    };
    r.onerror = () => reject(r.error);
    r.onsuccess = () => {
      const db = r.result;
      const t = db.transaction(COLLS, 'readwrite');
      recs.forEach(({ c, rec }) => t.objectStore(c).put(rec));
      t.oncomplete = () => { db.close(); resolve(); };
      t.onerror = () => reject(t.error);
    };
  });
}

const importDoc = () => ({
  version: 6,
  labels: [{ id: 'imp-l', name: 'Mate' }],
  notes: [note('imp-1', { labels: ['imp-l'] }), note('imp-2'), note('imp-3')],
  tasks: [task('imp-t1'), task('imp-t2')],
});

describe('importación atómica en IndexedDB', () => {
  /* Hay 6 escrituras en la importación (1 etiqueta, 3 notas, 2 pendientes): se prueba un fallo en cada posición */
  for (let k = 1; k <= 6; k++) {
    it(`un fallo en la escritura ${k} deja el disco y la pantalla como estaban`, async () => {
      const ctrl = faultyIdb();
      const s = await boot({ idb: ctrl });
      await s.K.api.saveNote(note('seed'));
      await s.K.storageFlush();
      const diskBefore = await dump(ctrl.base);
      const stateBefore = JSON.stringify(s.K.state.notes);

      ctrl.failPutAt = k; ctrl.puts = 0;
      await expect(s.K.mergeData(s.K.normalizeImport(importDoc()))).rejects.toThrow();

      expect(await dump(ctrl.base)).toEqual(diskBefore);
      expect(JSON.stringify(s.K.state.notes)).toBe(stateBefore);
    });
  }

  it('la importación completa se guarda, sobrevive a la recarga y se exporta igual', async () => {
    const base = new IDBFactory();
    const s = await boot({ idb: base });
    const res = await s.K.mergeData(s.K.normalizeImport(importDoc()));
    expect(res.added).toBe(5);   // 3 notas + 2 pendientes (las etiquetas no cuentan como elementos)
    await s.K.storageFlush();

    const again = await boot({ idb: base });
    expect(again.K.state.notes.map(n => n.id).sort()).toEqual(['imp-1', 'imp-2', 'imp-3']);
    expect(again.K.state.tasks.map(t => t.id).sort()).toEqual(['imp-t1', 'imp-t2']);
    const back = JSON.parse(await again.K.buildExport());
    expect(back.notes.map(n => n.id).sort()).toEqual(['imp-1', 'imp-2', 'imp-3']);
  });

  it('ciclo completo: importar, recargar, exportar, restaurar en otra instalación y comparar', async () => {
    const a = new IDBFactory();
    const s1 = await boot({ idb: a });
    await s1.K.mergeData(s1.K.normalizeImport(importDoc()));
    await s1.K.storageFlush();
    const backup = JSON.parse(await (await boot({ idb: a })).K.buildExport());

    const b = new IDBFactory();
    const s2 = await boot({ idb: b });
    await s2.K.mergeData(s2.K.normalizeImport(backup));
    await s2.K.storageFlush();
    const restored = await boot({ idb: b });
    const pick = list => list.map(n => [n.id, n.title, n.body, n.labels]).sort();
    expect(pick(restored.K.state.notes)).toEqual(pick(s1.K.state.notes));
    expect(restored.K.state.tasks.map(t => t.id).sort()).toEqual(['imp-t1', 'imp-t2']);
  });

  it('una importación recoge primero los cambios que aún no se habían escrito, sin perderlos', async () => {
    const base = new IDBFactory();
    const s = await boot({ idb: base });
    await s.K.api.saveNote(note('pendiente'));          // aún no escrito: está en memoria
    await s.K.mergeData(s.K.normalizeImport(importDoc()));
    await s.K.storageFlush();
    const ids = (await dump(base)).notes.map(n => n.id).sort();
    expect(ids).toEqual(['imp-1', 'imp-2', 'imp-3', 'pendiente']);
  });

  it('un fallo al importar un archivo Markdown no cambia nada y lo informa', async () => {
    const base = new IDBFactory();
    const ctrl = faultyIdb(base);
    const msgs = [];
    const s = await boot({ idb: ctrl, msgs });
    await s.K.api.saveNote(note('md-seed'));
    await s.K.storageFlush();
    const diskBefore = await dump(base);

    ctrl.failPutAt = 1; ctrl.puts = 0;
    const file = { name: 'nueva.md', lastModified: NOW, text: async () => '# Nueva\n\nTexto' };
    await s.K.importMarkdown([file]);

    expect(await dump(base)).toEqual(diskBefore);
    expect(msgs.at(-1)).toMatch(/no se cambió nada/i);
    expect(msgs.some(m => /Se (importaron|agregaron)|nota nueva/i.test(m))).toBe(false);
  });

  it('retryRefresh reconstruye la caché desde IndexedDB, no desde la copia en memoria', async () => {
    const base = new IDBFactory();
    const s = await boot({ idb: base });
    // Simula que el almacenamiento persistente contiene un registro que la caché no conoce,
    // como ocurriría si una transacción se confirma pero falla la aplicación a memoria.
    await rawPut(base, [{ c: 'notes', rec: note('persisted-after-commit') }]);
    s.K.refreshPending = true;
    expect(await s.K.retryRefresh()).toBe(true);
    expect(s.K.state.notes.map(n => n.id)).toContain('persisted-after-commit');
  });

});

describe('fallo de escritura en el almacenamiento', () => {
  it('un error al escribir un lote no deja escrituras anteriores a medias en el disco', async () => {
    const ctrl = faultyIdb();
    const s = await boot({ idb: ctrl });
    await s.K.api.saveTask(task('a'));
    await s.K.api.saveTask(task('b'));
    await s.K.api.saveTask(task('c'));
    ctrl.failPutAt = 2; ctrl.puts = 0;
    await s.K.storageFlush();                       // el lote falla: no debe quedar la escritura de "a" sola
    expect((await dump(ctrl.base)).tasks).toEqual([]);
  });
});

describe('IndexedDB presente pero no disponible: sin cambios silenciosos de almacén', () => {
  it('si la base no abre, la carga falla y no se escribe en localStorage', async () => {
    const base = new IDBFactory();
    const ctrl = faultyIdb(base);
    const seed = await boot({ idb: ctrl });
    await seed.K.api.saveNote(note('real'));
    await seed.K.storageFlush();

    ctrl.failOpen = true;
    const s = session({ idb: ctrl, store: seed.store });
    await expect(s.K.api.load()).rejects.toThrow();
    expect(seed.store.has(KEY)).toBe(false);
  });

  it('cuando la base vuelve a abrir, el reintento trae los datos reales', async () => {
    const base = new IDBFactory();
    const ctrl = faultyIdb(base);
    const seed = await boot({ idb: ctrl });
    await seed.K.api.saveNote(note('real'));
    await seed.K.storageFlush();

    ctrl.failOpen = true;
    const s = session({ idb: ctrl, store: seed.store });
    await expect(s.K.api.load()).rejects.toThrow();
    ctrl.failOpen = false;
    const d = await s.K.api.load();
    expect(d.notes.map(n => n.id)).toEqual(['real']);
  });

  it('un fallo transitorio de lectura no deja la app inutilizable: el siguiente intento funciona', async () => {
    const base = new IDBFactory();
    const ctrl = faultyIdb(base);
    const seed = await boot({ idb: ctrl });
    await seed.K.api.saveNote(note('x'));
    await seed.K.storageFlush();

    const s = session({ idb: ctrl });
    ctrl.failReadOnce = true;
    await expect(s.K.api.load()).rejects.toThrow();
    const d = await s.K.api.load();
    expect(d.notes.map(n => n.id)).toEqual(['x']);
  });
});

describe('navegador sin IndexedDB', () => {
  it('usa localStorage y lo informa al usuario', async () => {
    const s = await boot({ idb: undefined });
    await s.K.api.saveTask(task('solo-ls'));
    await s.K.storageFlush();
    expect(s.store.has(KEY)).toBe(true);
    expect(s.msgs.some(m => /localStorage/.test(m))).toBe(true);
  });
});

describe('datos dejados en localStorage por una sesión sin IndexedDB', () => {
  it('se recuperan al volver a abrir la app con IndexedDB y se quita la copia', async () => {
    const base = new IDBFactory();
    const seed = await boot({ idb: base });
    await seed.K.api.saveNote(note('real'));
    await seed.K.storageFlush();

    const store = new Map([[KEY, JSON.stringify({ notes: [], labels: [], blocks: [], events: [], sessions: [], versions: [], tasks: [task('t-ls')] })]]);
    const s = session({ idb: base, store });
    const d = await s.K.api.load();
    expect(d.tasks.map(t => t.id)).toEqual(['t-ls']);
    expect(d.notes.map(n => n.id)).toEqual(['real']);
    expect(store.has(KEY)).toBe(false);
  });

  it('un conflicto que no se puede resolver conserva la copia y avisa', async () => {
    const base = new IDBFactory();
    await rawPut(base, [{ c: 'tasks', rec: { id: 't-c', text: 'Disco', done: false, rev: 1 } }]);
    const store = new Map([[KEY, JSON.stringify({ notes: [], labels: [], blocks: [], events: [], sessions: [], versions: [],
      tasks: [{ id: 't-c', text: 'Copia local', done: false, rev: 1 }] })]]);
    const msgs = [];
    const s = session({ idb: base, store, msgs });
    const d = await s.K.api.load();
    expect(d.tasks[0].text).toBe('Disco');
    expect(store.has(KEY)).toBe(true);                 // no se borra lo que no se pudo fusionar
    expect(msgs.some(m => /conflicto/i.test(m))).toBe(true);
  });
});

describe('reglas de conflicto en importación', () => {
  it('gana el registro más reciente; con fechas no comparables se conserva el local y se cuenta el conflicto', async () => {
    const base = new IDBFactory();
    const s = await boot({ idb: base });
    await s.K.api.saveTask(task('t1', { text: 'Local', updatedAt: NOW - 3 * DAY }));
    await s.K.api.saveTask(task('t2', { text: 'Local 2', updatedAt: NOW - 2 * DAY }));
    await s.K.api.saveTask(task('t3', { text: 'Igual', updatedAt: NOW - 2 * DAY }));
    await s.K.api.saveTask(task('t4', { text: 'Sin fecha local', updatedAt: NOW - DAY }));
    await s.K.storageFlush();
    await boot({ idb: base }).then(x => { s.K.applyData(x.K.state); });   // estado al día

    const res = await s.K.mergeData(s.K.normalizeImport({ version: 6, notes: [], tasks: [
      task('t1', { text: 'Remoto más nuevo', updatedAt: NOW - DAY }),
      task('t2', { text: 'Remoto más viejo', updatedAt: NOW - 9 * DAY }),
      task('t3', { text: 'Igual', updatedAt: NOW - 2 * DAY }),
      task('t4', { text: 'Remoto sin fecha', updatedAt: undefined }),
    ] }));

    const byId = Object.fromEntries(s.K.state.tasks.map(t => [t.id, t.text]));
    expect(byId).toEqual({ t1: 'Remoto más nuevo', t2: 'Local 2', t3: 'Igual', t4: 'Sin fecha local' });
    expect(res.updated).toBe(1);
    expect(res.kept).toBe(1);
    expect(res.same).toBe(1);
    expect(res.conflicts).toHaveLength(1);
  });

});


/* Lectura posterior a una escritura confirmada: la importación ya está en el disco, pero la pantalla
   no puede leerla. refreshFromStore lee con K.api.reload (vuelve al disco); K.api.load sirve desde la
   caché, así que la falla se simula en reload. */
function failLoadOnce(s) {
  const realReload = s.K.api.reload;
  const state = { failures: 1 };
  s.K.api.reload = async () => {
    if (state.failures > 0) { state.failures--; throw new Error('lectura posterior simulada'); }
    return realReload();
  };
  return state;
}

describe('lectura posterior a una escritura confirmada', () => {
  it('mergeData no lanza si la escritura se confirmó: devuelve el resumen y marca la pantalla pendiente', async () => {
    const ctrl = faultyIdb();
    const s = await boot({ idb: ctrl });
    failLoadOnce(s);
    const res = await s.K.mergeData(s.K.normalizeImport(importDoc()));   // no debe lanzar
    expect(res.added).toBe(5);
    expect(res.refreshed).toBe(false);
    expect(s.K.refreshPending).toBe(true);
    expect(s.K.state.notes).toEqual([]);                                  // la pantalla todavía no lo ve
    const disk = await dump(ctrl.base);
    expect(disk.notes.map(n => n.id).sort()).toEqual(['imp-1', 'imp-2', 'imp-3']);
    expect(disk.tasks.map(t => t.id).sort()).toEqual(['imp-t1', 'imp-t2']);
  });

  it('reintentar la lectura pone la pantalla al día sin repetir la importación ni duplicar', async () => {
    const ctrl = faultyIdb();
    const s = await boot({ idb: ctrl });
    failLoadOnce(s);
    await s.K.mergeData(s.K.normalizeImport(importDoc()));
    const diskAfterWrite = await dump(ctrl.base);
    ctrl.puts = 0;

    expect(await s.K.retryRefresh()).toBe(true);
    expect(s.K.refreshPending).toBe(false);
    expect(s.K.state.notes.map(n => n.id).sort()).toEqual(['imp-1', 'imp-2', 'imp-3']);
    expect(s.K.state.tasks.map(t => t.id).sort()).toEqual(['imp-t1', 'imp-t2']);
    expect(ctrl.puts).toBe(0);                                            // no hubo ninguna escritura nueva
    expect(await dump(ctrl.base)).toEqual(diskAfterWrite);
  });

  it('importData no dice "no se cambió nada" si la escritura ya se confirmó, y avisa de recargar', async () => {
    const ctrl = faultyIdb();
    const msgs = [];
    const s = await boot({ idb: ctrl, msgs });
    failLoadOnce(s);
    await s.K.importData({ text: async () => JSON.stringify(importDoc()) });
    const last = msgs.at(-1);
    expect(last).toMatch(/Se agregaron 5/);
    expect(last).toMatch(/recargá la página/);
    expect(last).not.toMatch(/no se cambió nada/i);
  });

  it('un error de escritura real sigue diciendo que no se cambió nada', async () => {
    const ctrl = faultyIdb();
    const msgs = [];
    const s = await boot({ idb: ctrl, msgs });
    ctrl.failPutAt = 1; ctrl.puts = 0;
    await s.K.importData({ text: async () => JSON.stringify(importDoc()) });
    expect(msgs.at(-1)).toMatch(/no se cambió nada/i);
    expect(s.K.refreshPending).toBeFalsy();
  });

  it('importar de nuevo el mismo archivo tras el fallo de lectura no duplica nada', async () => {
    const ctrl = faultyIdb();
    const msgs = [];
    const s = await boot({ idb: ctrl, msgs });
    failLoadOnce(s);
    await s.K.importData({ text: async () => JSON.stringify(importDoc()) });
    await s.K.importData({ text: async () => JSON.stringify(importDoc()) });   // reintento del usuario
    const disk = await dump(ctrl.base);
    expect(disk.notes).toHaveLength(3);
    expect(disk.tasks).toHaveLength(2);
    expect(disk.labels).toHaveLength(1);
    expect(s.K.state.notes).toHaveLength(3);
  });

  it('importMarkdown con lectura posterior fallida: avisa de recargar, no duplica al reimportar', async () => {
    const ctrl = faultyIdb();
    const msgs = [];
    const s = await boot({ idb: ctrl, msgs });
    failLoadOnce(s);
    const file = { name: 'nueva.md', lastModified: NOW, text: async () => '# Nueva\n\nTexto' };
    await s.K.importMarkdown([file]);                                     // no debe lanzar
    expect(msgs.at(-1)).toMatch(/recargá la página/);
    expect(msgs.at(-1)).not.toMatch(/no se cambió nada/i);
    expect((await dump(ctrl.base)).notes).toHaveLength(1);
    expect(s.K.refreshPending).toBe(true);

    expect(await s.K.retryRefresh()).toBe(true);
    expect(s.K.state.notes.map(n => n.title)).toEqual(['Nueva']);
    await s.K.importMarkdown([file]);                                     // repetido: ya estaba
    expect((await dump(ctrl.base)).notes).toHaveLength(1);
    expect(s.K.state.notes).toHaveLength(1);
  });

  it('el contrato de error confirmado: si la transacción avisa que ya se escribió, mergeData no lanza', async () => {
    const s = await boot({ idb: undefined });
    const real = s.K.api.transact;
    s.K.api.transact = async () => {
      const err = new Error('fallo tras confirmar'); err.committed = true;
      err.result = { added: 2, updated: 0, same: 0, kept: 0, conflicts: [], invalid: 0, skipped: 0 };
      throw err;
    };
    const res = await s.K.mergeData(s.K.normalizeImport({ version: 6, notes: [] }));
    expect(res.added).toBe(2);
    expect(res.refreshed).toBe(true);
    s.K.api.transact = real;
  });
});

describe('1.26.4: migración de rutinas y franjas en la base', () => {
  it('una base de la versión anterior queda con todo en blocks; la franja vieja queda como tombstone y no se duplica al recargar', async () => {
    const idb = new IDBFactory();
    await boot({ idb });                                   // crea el esquema vacío
    await new Promise((res, rej) => {
      const r = idb.open('tempo');
      r.onsuccess = () => {
        const db = r.result;
        const tx = db.transaction(['blocks', 'slots'], 'readwrite');
        tx.objectStore('blocks').put({ id: 'rut', groupId: null, title: 'Clase', days: [0, 2], start: 480, end: 540,
          color: null, labels: [], notes: [], createdAt: NOW, updatedAt: NOW, rev: 1 });
        tx.objectStore('slots').put({ id: 'fr', date: '2026-10-20', title: 'Estudiar', start: 600, end: 660,
          color: null, createdAt: NOW, updatedAt: NOW, rev: 1 });
        tx.oncomplete = () => { db.close(); res(); };
        tx.onerror = () => rej(tx.error);
      };
      r.onerror = () => rej(r.error);
    });

    const s1 = await boot({ idb });
    const byId = Object.fromEntries(s1.K.state.blocks.map(b => [b.id, b]));
    expect(Object.keys(byId).sort()).toEqual(['fr', 'rut']);
    expect(byId.rut.repeat).toEqual({ type: 'weekly', days: [0, 2] });
    expect(byId.rut).not.toHaveProperty('days');
    expect(byId.fr.repeat).toEqual({ type: 'once', date: '2026-10-20' });
    expect(s1.K.state.slots).toEqual([]);

    // Segunda carga: nada cambia y no aparecen duplicados
    const s2 = await boot({ idb });
    expect(s2.K.state.blocks.map(b => b.id).sort()).toEqual(['fr', 'rut']);
    expect(s2.K.state.slots).toEqual([]);
  });
});
