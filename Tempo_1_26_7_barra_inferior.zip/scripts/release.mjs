#!/usr/bin/env node
/* =========================================================
   Tempo · script de release (P2.1)

   Uso:
     node scripts/release.mjs 1.22.3      cambia la versión en todos los lugares y verifica
     node scripts/release.mjs --check     solo verifica que todo esté alineado (no escribe)

   Dónde vive la versión:
     · js/state.js            K.VERSION (lo que ve la persona en Configuración)
     · sw.js                  CACHE (nombre de la caché: sin cambiarlo, el navegador no baja archivos nuevos)
     · manifest.webmanifest   "version"
     · readme.md              "Versión **x.y.z**"
     · package.json           "version" (solo herramientas de prueba; la app no usa npm)

   Además verifica que la lista ASSETS de sw.js tenga todos los archivos de la app
   (si falta uno, la versión nueva no se puede instalar sin conexión) y que el index.html
   no apunte a archivos que no existen.

   Sin dependencias: solo Node (sin build, como el resto del proyecto).
   ========================================================= */
import { readFileSync, writeFileSync, readdirSync, existsSync } from 'node:fs';
import { join, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(fileURLToPath(new URL('.', import.meta.url)), '..');
const read = f => readFileSync(join(ROOT, f), 'utf8');

/* Cada lugar: archivo, expresión que captura la versión y cómo escribirla. */
const TARGETS = [
  { file: 'js/state.js', re: /K\.VERSION = '([^']+)'/g, make: v => `K.VERSION = '${v}'` },
  { file: 'sw.js', re: /const CACHE = 'tempo-shell-([^']+)'/g, make: v => `const CACHE = 'tempo-shell-${v}'` },
  { file: 'manifest.webmanifest', re: /"version": "([^"]+)"/g, make: v => `"version": "${v}"` },
  { file: 'readme.md', re: /Versión \*\*([^*]+)\*\*/g, make: v => `Versión **${v}**` },
  { file: 'package.json', re: /"version": "([^"]+)"/g, make: v => `"version": "${v}"` },
  { file: 'package-lock.json', re: /"name": "tempo",\n {2}"version": "([^"]+)"/g,
    make: v => `"name": "tempo",\n  "version": "${v}"` },
  { file: 'package-lock.json', re: /"": \{\n {6}"name": "tempo",\n {6}"version": "([^"]+)"/g,
    make: v => `"": {\n      "name": "tempo",\n      "version": "${v}"` },
];

/* Archivos que no forman parte de la app instalable */
/* Archivos del proyecto que no son la app: no van a la caché del navegador.
   Las pruebas, el lint y el paquete de npm son herramientas de desarrollo. */
const NOT_CACHED = new Set(['sw.js', 'readme.md', 'MEJORAS_AGENDA.md', 'package.json', 'package-lock.json', 'eslint.config.js']);
const IGNORED_DIRS = new Set(['scripts', 'tests', 'node_modules', '.git', '.github']);

const SEMVER = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\.(0|[1-9]\d*))?$/;
const cmp = (a, b) => {
  const x = a.split('.').map(Number), y = b.split('.').map(Number);
  while (x.length < 4) x.push(0); while (y.length < 4) y.push(0);
  for (let i = 0; i < 4; i++) if (x[i] !== y[i]) return x[i] - y[i];
  return 0;
};

function currentVersions() {
  return TARGETS.map(t => {
    const m = [...read(t.file).matchAll(t.re)];
    if (m.length !== 1) throw new Error(`${t.file}: se esperaba 1 lugar con la versión y hay ${m.length}`);
    return { ...t, version: m[0][1] };
  });
}

function bump(version) {
  for (const t of TARGETS) {
    const path = join(ROOT, t.file);
    const src = readFileSync(path, 'utf8');
    const count = [...src.matchAll(t.re)].length;
    if (count !== 1) throw new Error(`${t.file}: no se pudo reemplazar la versión (coincidencias: ${count})`);
    writeFileSync(path, src.replace(t.re, t.make(version)), 'utf8');
    console.log(`  ✓ ${t.file} → ${version}`);
  }
}

/* Archivos de la app en disco, con ruta relativa estilo './css/base.css' */
function appFiles() {
  const out = [];
  (function walk(dir) {
    for (const e of readdirSync(join(ROOT, dir), { withFileTypes: true })) {
      if (e.name.startsWith('.') || IGNORED_DIRS.has(e.name)) continue;
      const rel = dir ? join(dir, e.name) : e.name;
      if (e.isDirectory()) walk(rel);
      else out.push('./' + rel.split(sep).join('/'));
    }
  })('');
  return out.filter(f => !NOT_CACHED.has(f.slice(2)));
}

function assetsList() {
  const src = read('sw.js');
  const start = src.indexOf('const ASSETS');
  if (start < 0) throw new Error('sw.js: no encuentro const ASSETS');
  const block = src.slice(start, src.indexOf('];', start));
  return [...block.matchAll(/'(\.\/[^']*)'/g)].map(m => m[1]);
}

function checkAssets() {
  const listed = new Set(assetsList());
  const disk = appFiles();
  const problems = [];
  for (const f of disk) if (!listed.has(f)) problems.push(`falta en ASSETS: ${f}`);
  for (const f of listed) if (f !== './' && !existsSync(join(ROOT, f))) problems.push(`en ASSETS pero no existe: ${f}`);
  return problems;
}

function checkHtmlRefs() {
  const html = read('index.html');
  const refs = [...html.matchAll(/(?:src|href)="([^"#?:]+)"/g)].map(m => m[1]);
  return refs.filter(r => !existsSync(join(ROOT, r))).map(r => `index.html apunta a un archivo que no existe: ${r}`);
}

/* Símbolos K.* leídos pero nunca asignados: un error silencioso que solo aparece al usar esa función */
function checkKSymbols() {
  const defs = new Set(), uses = new Set();
  for (const f of readdirSync(join(ROOT, 'js')).filter(f => f.endsWith('.js'))) {
    const src = read('js/' + f);
    for (const m of src.matchAll(/\bK\.([A-Za-z_]\w*)\s*=(?!=)/g)) defs.add(m[1]);
    for (const m of src.matchAll(/\bK\.([A-Za-z_]\w*)\b(?!\s*=(?!=))/g)) uses.add(m[1]);
    /* Desestructuraciones: const { h, fit: f } = K  (el valor se toma al cargar el archivo) */
    for (const m of src.matchAll(/const\s*\{([^}]*)\}\s*=\s*K\b(?!\.)/g))
      for (const part of m[1].split(',')) { const name = part.split(':')[0].trim(); if (name) uses.add(name); }
  }
  return [...uses].filter(k => !defs.has(k)).map(k => `K.${k} se usa pero nunca se define`);
}

function check() {
  const vs = currentVersions();
  const unique = new Set(vs.map(v => v.version));
  const problems = [];
  if (unique.size !== 1) problems.push('las versiones no coinciden: ' + vs.map(v => `${v.file}=${v.version}`).join(', '));
  for (const v of vs) if (!SEMVER.test(v.version)) problems.push(`versión inválida en ${v.file}: ${v.version}`);
  problems.push(...checkAssets(), ...checkHtmlRefs(), ...checkKSymbols());
  return { version: vs[0].version, problems };
}

(function main() {
  const arg = process.argv[2];
  if (!arg) { console.error('Uso: node scripts/release.mjs <x.y.z>  |  node scripts/release.mjs --check'); process.exit(2); }

  if (arg === '--check') {
    const { version, problems } = check();
    if (problems.length) { console.error('✗ Problemas:\n  - ' + problems.join('\n  - ')); process.exit(1); }
    console.log(`✓ Todo alineado en ${version}: versiones, ASSETS y referencias del HTML.`);
    return;
  }

  if (!SEMVER.test(arg)) { console.error(`✗ "${arg}" no es una versión x.y.z o x.y.z.w`); process.exit(2); }
  const current = currentVersions()[0].version;
  if (cmp(arg, current) <= 0) { console.error(`✗ ${arg} no es mayor que la versión actual (${current}). Las versiones solo suben.`); process.exit(2); }

  console.log(`Subiendo ${current} → ${arg}`);
  bump(arg);
  const { problems } = check();
  if (problems.length) { console.error('✗ Después del cambio quedaron problemas:\n  - ' + problems.join('\n  - ')); process.exit(1); }
  console.log(`✓ Versión ${arg} lista. Revisá con la app antes de publicar.`);
})();
