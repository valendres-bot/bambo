/* =========================================================
   sw.js — hace que Tempo funcione sin conexión (solo si se sirve por http/https).
   · install: precarga los archivos esenciales (la app completa queda lista offline).
   · fetch: stale-while-revalidate. Responde al instante con la copia guardada y, en
     segundo plano, pide la versión nueva para la próxima vez. Sin copia, espera la red
     y, si no hay red, muestra la portada.
   · No cachea nada de otros orígenes (p. ej. Google Fonts): se pide siempre a la red.
   ========================================================= */
const CACHE = 'tempo-shell-1.26.7';   // cambiar en cada versión: así el navegador descarga los archivos nuevos

const ASSETS = [
  './', './index.html', './manifest.webmanifest', './icon.svg',
  './icon-192.png', './icon-512.png', './icon-maskable-512.png', './apple-touch-icon.png',
  './css/fonts.css', './css/tokens.css', './css/base.css', './css/layout.css', './css/components.css',
  './css/schedule.css', './css/notes.css', './css/focus.css', './css/today.css', './css/goals.css', './css/settings.css', './css/responsive.css', './css/experimental.css',
  './fonts/instrument-sans-latin-wght-normal.woff2', './fonts/bricolage-grotesque-latin-wght-normal.woff2',
  './js/dom.js', './js/storage.js', './js/state.js', './js/bloques.js', './js/ui.js', './js/router.js', './js/actions.js', './js/data.js',
  './js/drag.js', './js/sidebar.js', './js/topbar.js', './js/list.js', './js/richtext.js', './js/richedit.js',
  './js/richinput.js', './js/cards.js', './js/editor.js', './js/palette.js', './js/tasks.js',
  './js/today.js', './js/goals.js', './js/goalsui.js', './js/metrics.js', './js/views.js', './js/focus.js', './js/focusui.js', './js/schedule.js',
  './js/settings.js', './js/gestures.js', './js/app.js',
];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll(ASSETS);          // si falta alguno, la instalación falla y sigue la versión anterior
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', e => e.waitUntil((async () => {
  for (const k of await caches.keys()) if (k !== CACHE) await caches.delete(k);   // caché de versiones anteriores
  await self.clients.claim();
})()));

/* Clic en la notificación del Foco: vuelve a la app (o la abre) */
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    const c = list.find(x => 'focus' in x);
    return c ? c.focus() : self.clients.openWindow('./index.html#/focus');
  }));
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  const cacheP = caches.open(CACHE);
  /* Pide a la red y, si llega bien, actualiza la copia guardada */
  const net = cacheP.then(cache => fetch(req).then(res => {
    if (res.ok && res.type === 'basic') cache.put(req, res.clone());
    return res;
  }));
  e.waitUntil(net.catch(() => {}));      // que el navegador no duerma el worker mientras se actualiza
  e.respondWith((async () => {
    const cached = await (await cacheP).match(req, { ignoreSearch: true });
    if (cached) return cached;            // respuesta inmediata; la red actualiza para la próxima
    try {
      return await net;
    } catch {
      return (await (await cacheP).match('./index.html')) || Response.error();
    }
  })());
});
