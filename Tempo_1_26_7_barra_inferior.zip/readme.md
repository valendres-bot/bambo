# Tempo

**Notas, pendientes, rutina, foco y métricas en una sola aplicación web.** Pensada para el desarrollo personal y universitario: organizá tus objetivos, planificá tu semana y medí cuánto tiempo le dedicás a cada objetivo.

Versión **1.26.7** · Aplicación web estática (HTML, CSS y JavaScript) · Sin dependencias, sin build, sin cuentas · Instalable como PWA

---

## Índice

1. [Características](#características)
2. [Inicio rápido](#inicio-rápido)
3. [Atajos de teclado](#atajos-de-teclado)
4. [Formato de las notas](#formato-de-las-notas)
5. [Estructura del proyecto](#estructura-del-proyecto)
6. [Arquitectura](#arquitectura)
7. [Datos y privacidad](#datos-y-privacidad)
8. [Integración con otras herramientas](#integración-con-otras-herramientas)
9. [Conectar un backend](#conectar-un-backend)
10. [Compatibilidad](#compatibilidad)
11. [Mantenimiento y versionado](#mantenimiento-y-versionado)
12. [Limitaciones conocidas](#limitaciones-conocidas)

---

## Características

### Notas
- **Editor visual** sin comandos que memorizar: texto, subtítulos, viñetas, **negrita**, *cursiva* y ==resaltado==, con barra de formato, barra flotante al seleccionar, clic derecho y atajos.
- **Etiquetas** para agrupar notas, con color, fijado, archivado y orden propio. Viven en *Notas* (ahí se crean, renombran y ordenan con ⋯). Son un recurso aislado: no se vinculan a calendario, pendientes, Foco ni Métricas. Fijadas, aparecen en la barra lateral.
- **Enlaces**: a direcciones web (se abren en pestaña nueva) y entre notas o etiquetas con `[[Nombre]]`. Las etiquetas pueden tener *cards* de enlaces (por ejemplo, a carpetas de Drive).
- **Fijar, archivar y papelera**, con opción de *Deshacer*. Lo que va a la papelera se elimina solo a los 7 días de enviado (o antes, a mano con *Vaciar papelera*).
- **Búsqueda global** (paleta de comandos, que también encuentra etiquetas) que ignora mayúsculas y acentos. El filtro de la vista actual busca en títulos y textos de las notas.
- **Arrastrar y soltar**: reordenar notas fijadas y mover notas a una etiqueta, al archivo o a la papelera.
- **Importar y exportar Markdown**: una nota por archivo, o todas las notas de una etiqueta en un solo `.md`.
- **Renglones o cuadros**: el botón de la barra superior cambia la vista de la lista; la elección se recuerda en este navegador.
- **Selección en lote**: Ctrl/⌘ + clic (o clic con algo ya seleccionado) elige notas. La barra que aparece permite etiquetar, fijar, archivar o enviar a la papelera todas juntas, con *Deshacer*.
- **Captura**: en *Configuración → Preferencias* se puede hacer que una nota nueva no herede la etiqueta de la vista donde se crea.

### Hoy (inicio)
- Es la primera pantalla al abrir Tempo: lo que hay que hacer hoy y el foco del día.
- **Siguiente paso**: la primera tarea de hoy, con *Empezar enfoque* (abre el temporizador con esa tarea y arranca) y *Hecha*.
- Captura de una línea: Enter agrega; Shift+Enter para varias líneas (en celular, Enter hace línea nueva y se toca *Agregar*). *Vence* y *Más opciones* (rutina) quedan a mano.
- **Días del mes**: una tira con los días del mes elegido. Se toca un día para verlo, y en celular se desliza de costado para pasar de día en día (como en Calendario). Los puntitos marcan los días con algo.
- **Franjas horarias**: dentro de un día se crean franjas (*Franja*, con inicio, fin y color). Cada franja tiene sus pendientes; se agregan escribiéndolos en su campo o desde el menú ⋯ de un pendiente (*Franja…*). Una franja va dentro de un solo día y sus pendientes quedan con esa fecha. Editarla o borrarla no borra sus pendientes.
- **Bloques de la rutina en el día**: los bloques de la rutina semanal que caen en el día elegido aparecen como franjas, con sus pendientes de rutina (se tildan ese día).

### Pendientes
- Los pendientes son **registros propios**, separados de las notas. Las notas son solo texto: sus líneas `- [ ]` no generan pendientes ni se tildan.
- **Entrada en bloque**: se escribe (o pega) un texto y cada línea es un pendiente. Antes de agregar se ve una vista previa. Una línea con el nombre de un día (`VIERNES`, `sábado`) fija la fecha de las líneas que siguen. Viñetas y `- [ ]` se quitan, y `@AAAA-MM-DD` fija una fecha. Ctrl/⌘+Enter agrega; Enter hace una línea nueva. Se agregan hasta 100 por vez.
- **Hora** opcional con `@9:30` en la captura. Dentro de cada día, los pendientes sin hora van primero y después se ordenan por hora. Editar la hora después todavía no es posible: se vuelve a escribir el pendiente.
- **Fecha límite** opcional (Hoy, Mañana, Sin fecha o una fecha a elección). Se agrupan en *Vencidas*, una card por día hasta el domingo, *Sin fecha* y *Hechas*.
- Cada pendiente guarda cuándo se tildó, para contar las hechas de la semana en Métricas.
- **Rutinas**: con el botón *Rutina* de cada pendiente se lo enlaza a un bloque de la rutina semanal (por ejemplo, *Ordenar la casa*, lunes, miércoles y viernes). Aparece en Pendientes los días de ese bloque, desde hoy hasta el domingo, y se tilda por día. Si el bloque se borra, el pendiente vuelve a ser suelto.
- **Menú ⋯** de cada pendiente: enfocar en esa tarea, cambiar su objetivo o rutina, y eliminarla.
- **Objetivo** (botón de cada pendiente): lo vincula a un objetivo o a uno de sus proyectos. Sigue siendo el mismo pendiente, visto desde Objetivos o desde acá.

### Objetivos
- Un **objetivo** es el resultado que querés alcanzar: *Aprobar Matemática*, *Correr 10 km*, *Terminar una reforma*. Crearlo basta con un nombre.
- Ámbito (académico, profesional, personal u otro), descripción y fechas de inicio y límite, todo opcional.
- **Archivar**: un objetivo terminado o en pausa se archiva. Queda en la sección *Archivados*, sin aparecer en las sugerencias de Foco, y se puede desarchivar en cualquier momento. (Antes existía un estado activo, pausado o completado; ahora solo hay archivado o no.)
- Cada objetivo se organiza en **proyectos** desplegables (cuatrimestres, etapas, entregables, lo que sirva) y un bloque **General** para lo que no es de ningún proyecto. Cada bloque tiene sus pendientes, sus recursos y su fecha límite opcional.
- **Proyectos**: se renombran con doble clic en el nombre o con el lápiz, se suben y bajan con las flechas, y *Duplicar* copia el proyecto con sus recursos y pendientes (los pendientes vuelven sin tildar y sin fecha).
- **Pendientes en bloque**: en el campo de cada bloque se pueden escribir o pegar varias líneas; cada línea es un pendiente, igual que en Pendientes. Ctrl/⌘+Enter agrega.
- **Recursos**: notas y enlaces que agregás a mano. No se vinculan solos ni cambian tus etiquetas.
- **Enfocar** desde el objetivo o desde un proyecto: el tiempo queda registrado en ese objetivo (Métricas lo muestra).
- Quitar un proyecto no borra nada (sus pendientes y recursos pasan a General). Borrar un objetivo deja sus pendientes sueltos, con *Deshacer*.

### Calendario
- **Rutina semanal** en grilla 24/7 (lunes a domingo): bloques con horario, color propio, varios días. Los bloques que cruzan la medianoche se manejan como uno solo. En celular se ve un día por vez y se cambia deslizando.
- **Próximos eventos**: fecha y hora opcional; los pasados quedan plegados.
- **Exportar a `.ics`** (Google Calendar, Outlook, Apple Calendar): los bloques salen como eventos semanales recurrentes.

### Foco
- **Temporizador Pomodoro** (25 · 5 · 15 por defecto; combinaciones 50 · 10 · 20 y 15 · 3 · 10; duración editable por etapa).
- **Objetivo** de cada enfoque: un objetivo o proyecto, una nota, evento, bloque de la rutina, tarea o texto libre.
- Cada enfoque completo queda registrado como **sesión**. *Terminar y guardar* registra lo trabajado si cortás antes de tiempo.
- El temporizador **sigue corriendo al cambiar de pantalla o recargar**, y acredita el enfoque aunque haya terminado con la app cerrada.
- Con varias pestañas abiertas, **una sola es dueña del reloj** (Web Locks), así no se duplican sesiones.
- Aviso al terminar con sonido, vibración y notificación; opción de mantener la pantalla encendida (Wake Lock).

### Métricas
- Foco de la semana, racha de días con foco, tendencia de 8 semanas, tiempo por objetivo, lo más trabajado, pendientes hechas esta semana (incluidas las rutinas que tildaste), rutinas esta semana (cuántas veces tocaban hasta hoy y cuántas se hicieron, con el color del bloque) y notas nuevas de la semana.

### Configuración
- Cuatro grupos. **Preferencias:** tema automático, claro u oscuro. **Foco:** duración de las etapas, avisos al terminar y pantalla encendida. **Datos:** copia de seguridad (`.json` y Markdown), lo guardado, papelera y borrado. **Acerca de:** versión, uso en este dispositivo y privacidad.
- Aviso de copia de seguridad si pasaron 14 días sin exportar.

### Aplicación web progresiva
- Instalable y con modo sin conexión mediante Service Worker.
- Interfaz responsiva: en pantallas menores a 860 px la barra lateral es un panel deslizable, con botón flotante para crear notas y gestos táctiles.

---

## Inicio rápido

No requiere instalación ni dependencias.

**Opción 1 — Abrir directamente.** Abrí `index.html` en el navegador. Todo funciona, salvo el modo sin conexión (los navegadores no admiten Service Workers desde `file://`).

**Opción 2 — Servir por HTTP** (recomendado; habilita la instalación como PWA y el modo sin conexión):

```bash
# Desde la carpeta del proyecto
python3 -m http.server 8000
# o bien
npx serve .
```

Luego abrí `http://localhost:8000`.

---

## Atajos de teclado

**Globales** (fuera de campos de texto)

| Atajo | Acción |
|---|---|
| `K` | Búsqueda global y acciones rápidas |
| `/` | Filtrar la vista actual |
| `N` | Nota nueva (en Notas y dentro de una etiqueta). En Hoy: escribir un pendiente |
| `P` | Ir a Hoy |
| `F` | Ir a Foco |
| `Ctrl` + `\` | Mostrar u ocultar la barra lateral |
| `Esc` | Cerrar lo que esté abierto |

**Editor de notas**

| Atajo | Acción |
|---|---|
| `Ctrl` + `B` / `I` | Negrita / cursiva |
| `Ctrl` + `Shift` + `H` | Resaltar |
| `Ctrl` + `K` | Enlazar a una dirección, nota o etiqueta |
| `Ctrl` + `Z` / `Ctrl` + `Y` | Deshacer / rehacer |
| `Ctrl` + `Enter` o `Esc` | Guardar y cerrar |
| `##` + espacio, `-` + espacio | Subtítulo, viñeta |

**Foco**

| Atajo | Acción |
|---|---|
| `Espacio` | Iniciar o pausar el temporizador |

---

## Formato de las notas

El contenido de cada nota se guarda como texto plano con marcas, parecido a Markdown:

```text
## Subtítulo
- viñeta
- [ ] algo   (solo texto: los pendientes van en la pantalla Pendientes)
**negrita**   *cursiva*   ==resaltado==
[texto](https://ejemplo.com)       enlace en una palabra
[[Nombre de otra nota o etiqueta]]
```

---

## Estructura del proyecto

```text
tempo/
├── index.html                 Punto de entrada. Carga estilos y scripts (el orden importa)
├── manifest.webmanifest       Metadatos de la PWA
├── sw.js                      Service Worker: modo sin conexión y notificaciones
├── icon.svg                   Ícono de la aplicación
├── fonts/                     Tipografías propias (Bricolage Grotesque, Instrument Sans)
├── css/
│   ├── tokens.css             Colores y tipografía; temas claro y oscuro
│   ├── fonts.css              @font-face de las fuentes locales
│   ├── base.css               Reset, tipografía y controles básicos
│   ├── layout.css             Estructura: barra lateral, barra superior, página
│   ├── components.css         Renglones, menús, paleta, avisos, botón flotante
│   ├── notes.css              Pantalla de la nota y editor
│   ├── schedule.css           Calendario, grilla semanal y formularios
│   ├── focus.css              Foco y Métricas
│   ├── today.css              Pendientes
│   ├── settings.css           Configuración
│   └── responsive.css         Celular y tablet, reducción de movimiento
└── js/
    ├── dom.js                 Helpers de DOM, íconos, fechas y búsqueda
    ├── storage.js             Capa de datos (K.api): IndexedDB (una tabla por colección, solo se escribe lo que cambia) con escritura diferida
    ├── state.js               Estado global, modelos y lectura del texto de las notas
    ├── ui.js                  Popovers, menús y avisos (toast)
    ├── router.js              Rutas por hash (#/, #/label/ID, #/focus, …)
    ├── actions.js             Operaciones sobre notas y etiquetas
    ├── data.js                Exportar/importar (.json, .md, .ics) y primer arranque
    ├── drag.js                Arrastrar y soltar (mouse y táctil)
    ├── sidebar.js · topbar.js · list.js · views.js     Navegación y listas
    ├── richtext.js            Conversión entre el texto guardado y los bloques del editor
    ├── richedit.js            Núcleo del editor: bloques, selección, formato, deshacer
    ├── richinput.js           Teclado, pegado, copiado y clics del editor
    ├── cards.js               Cards de enlaces y selector de enlaces
    ├── editor.js              Ventana de edición de una nota
    ├── palette.js             Búsqueda global y acciones rápidas
    ├── tasks.js · today.js    Pendientes: registros, entrada en bloque y pantalla
    ├── goals.js               Objetivos: modelo, proyectos, recursos y conversión de materias
    ├── goalsui.js             Pantallas de Objetivos (lista y detalle)
    ├── metrics.js             Métricas
    ├── focus.js · focusui.js  Temporizador (motor) y pantalla de Foco
    ├── schedule.js            Rutina semanal, eventos y exportación al calendario
    ├── settings.js            Configuración
    ├── gestures.js            Gestos táctiles
    └── app.js                 Arranque, atajos globales y eventos
```

---

## Arquitectura

- **Scripts clásicos sin build.** Cada archivo es una función autoejecutable que cuelga de un único objeto global, `K`. Por eso `index.html` puede abrirse directo, sin servidor ni compilación.
- **El orden de carga importa.** Cada script usa lo que definen los anteriores; el orden está en `index.html`. Capas, de abajo hacia arriba: `dom` → `storage` → `state` → `ui` → `router` → `actions` → `data` → módulos de pantalla → `app`.
- **Estado en memoria, persistencia diferida.** La copia de trabajo vive en memoria y se escribe agrupada, 300 ms después del último cambio. Al cerrar o esconder la pestaña se escribe lo pendiente.
- **Renderizado manual.** Las pantallas se construyen con `K.h(tag, props, ...hijos)`. Los íconos son SVG fijos y no se acepta HTML externo.
- **Modelo de datos** (`notes`, `labels`, `blocks`, `events`, `sessions`, `versions`, `tasks`, `goals`): cada registro tiene `id`, `rev` y `updatedAt`. Los proyectos, los recursos y los pendientes de un objetivo viven dentro de su registro.
- **Base de datos** IndexedDB versión 4 (se agregó `goals`). Al cargar, las materias de versiones anteriores se convierten en objetivos académicos (`K.convertMaterias`): el id del objetivo es `goal-<id de la etiqueta>`, así repetir la conversión no duplica nada, y el tiempo de foco de la materia pasa al objetivo. Un borrado deja un *tombstone* durante 90 días, pensado para una futura sincronización.

---

## Datos y privacidad

- Todo se guarda **en este navegador** (IndexedDB; `localStorage` solo como respaldo si el navegador no la ofrece). No hay cuentas, servidores ni telemetría, y el código no realiza ninguna petición de red.
- Las fuentes están incluidas en el proyecto: no se consulta a Google Fonts.
- Los contadores de uso (días con la app abierta, aperturas, enfoques) son locales y nunca salen del dispositivo.
- Si los datos guardados están dañados, se conserva una copia aparte antes de seguir (descargable desde *Configuración → Datos*).
- Con varias pestañas abiertas, los cambios se fusionan registro por registro y las demás pestañas se actualizan solas.

**Copia de seguridad:** *Configuración → Datos → Copia de seguridad → Exportar* genera un `.json` con notas, etiquetas, bloques, eventos, sesiones, pendientes y objetivos. Al importarlo se suma a lo existente sin borrar nada; si una nota está en ambos lados, queda la más reciente.

---

## Integración con otras herramientas

Mientras hay un enfoque en curso, Tempo publica su estado para que otras herramientas (por ejemplo, una extensión que bloquee sitios durante el foco) puedan reaccionar:

- Atributo en `<html>`: `data-focus="on"` o `data-focus="off"`.
- Evento en `window`: `tempo:focus`, con `detail = { active, mode, endAt, target }`.

```js
window.addEventListener('tempo:focus', e => {
  const { active, endAt, target } = e.detail;
  // active: true solo durante un enfoque en curso (no en pausas)
  // endAt:  marca de tiempo (ms) en que termina; 0 si no está activo
  // target: nombre del objetivo, o null
});
```

Solo se emite cuando el estado cambia.

---

## Conectar un backend

`js/storage.js` es el único archivo que hay que reemplazar para usar una base de datos. Expone el objeto `K.api`; basta con implementar las mismas funciones (asíncronas):

`load`, `saveNote`, `deleteNote`, `saveLabel`, `deleteLabel`, `saveBlock`, `deleteBlock`, `saveEvent`, `deleteEvent`, `saveSession`, `deleteSession`, `saveVersion`, `deleteVersion`, `deleteVersions`, `saveTask`, `deleteTask`, `saveGoal`, `deleteGoal`, `clearAll`.

`load()` devuelve `{ notes, labels, blocks, events, sessions, versions }` sin tombstones. Los campos `rev` y `updatedAt` de cada registro permiten resolver conflictos entre dispositivos. En el encabezado de `storage.js` hay un ejemplo con `fetch`.

---

## Compatibilidad

Navegadores recientes: Chrome, Edge, Firefox y Safari. Se usan expresiones regulares con *lookbehind*, por lo que Safari debe ser **16.4 o superior**.

Estas funciones se activan si el navegador las soporta y la app sigue funcionando sin ellas: Service Worker (solo con `http(s)`), Web Locks, Wake Lock, notificaciones y vibración.

---

## Mantenimiento y versionado

Al publicar una versión nueva, `node scripts/release.mjs x.y.z` actualiza **todos** los lugares donde vive la versión (`js/state.js`, `sw.js`, `manifest.webmanifest`, `package.json` y este archivo) y verifica que la lista `ASSETS` de `sw.js` tenga todos los archivos de la app. `node scripts/release.mjs --check` solo verifica.

Pruebas y lint (solo para desarrollo; la app no necesita npm para funcionar):

```bash
npm ci          # instala Vitest y ESLint
npm run lint    # ESLint sobre js/, sw.js, tests/ y scripts/
npm test        # pruebas de lógica pura: parser de pendientes, texto de notas, importación, bloques, rutinas y exportación
npm run ci      # lint + pruebas + verificación de versión, como en GitHub Actions (.github/workflows/ci.yml)
```

Las pruebas de navegador (flujos, capturas y rendimiento) están en `tempo-pruebas` y se corren aparte contra Chromium.

Algunos nombres internos conservan el prefijo histórico `mi-keep` (clave de almacenamiento `mi-keep:v4`, eventos `mikeep:*`). Cambiarlos requiere una migración de datos, por lo que se mantienen.

---

## Limitaciones conocidas

- Los datos viven en un solo navegador: no hay sincronización entre dispositivos (usá la copia de seguridad o conectá un backend).
- IndexedDB no tiene el tope de ~5 MB de `localStorage`; el límite lo pone el disco y el navegador. Si no hay espacio, la app lo avisa y conserva los cambios en pantalla. Al cerrar la pestaña se pide escribir lo pendiente, pero en el celular el sistema puede cerrar la app antes de terminar: por eso conviene exportar una copia de vez en cuando.
- La exportación `.json` incluye notas, etiquetas, bloques, eventos, sesiones, pendientes y objetivos. El historial de versiones se quitó en 1.25.0; las versiones guardadas antes quedan en la base hasta la limpieza de datos de 1.27.0.
- Los objetivos tienen fecha de inicio y fecha límite (también en cada proyecto), pero no hitos intermedios.
- Un respaldo de una versión anterior con materias las importa como objetivos académicos. Las copias de la versión 1.24.0 en adelante incluyen objetivos; una versión anterior las ignora al importar.
- Con `file://` no hay modo sin conexión ni instalación como PWA.
