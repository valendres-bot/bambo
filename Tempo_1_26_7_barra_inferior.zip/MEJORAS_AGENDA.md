# Agenda unificada — decisiones de implementación

## Cambios incluidos en 1.26.2 (primera iteración)
- Se pueden agregar pendientes directamente desde una tarjeta de rutina en Hoy; quedan enlazados al bloque y se completan por ocurrencia diaria.
- Los pendientes con `@HH:MM` aparecen como elementos horarios en la columna del día.
- Los eventos de Calendario del día también aparecen en Hoy, ordenados por hora (los de todo el día primero).
- Se agregó arrastrar y soltar entre “Sin franja”, franjas de una fecha y bloques semanales.
- Al sacar una tarea de una rutina semanal, se convierte en pendiente puntual de la fecha visible; no modifica la repetición de la rutina.
- El botón para crear una franja en Hoy ahora usa el nombre “Bloque del día”.

## Estado en 1.26.4
- Hecho: un solo modelo de bloque. `blocks` guarda rutinas (`repeat: weekly`) y franjas (`repeat: once`).
  La colección `slots` queda vacía; sus registros pasan a `blocks` con el mismo id y en el disco quedan como tombstones.
  La migración corre al cargar (`K.migrateStored`), es idempotente y conserva ids. Hoy, Calendario, Foco y la importación/exportación usan el mismo modelo.
- Hoy y Calendario usan `K.occurrencesOn` para encontrar lo que cae en un día.
- Decisión distinta al plan: los pendientes siguen con `slotId` (apunta a un bloque `once`) y `blockId` (rutina semanal).
  Así una franja nunca se confunde con una rutina. Unificar el vínculo en un solo campo queda pendiente.
- Decisión: la base de IndexedDB sigue en versión 5, porque no se agregó ninguna tabla. La migración es de datos, no de esquema.
- Pendiente: Calendario muestra solo rutinas semanales; las franjas de un día aparecen en Hoy.
- Pendiente: recorrido en navegador real, escritorio y celular (la prueba de render usa DOM simulado).

## Migración pendiente: un único modelo de bloque (resuelta en 1.26.4, ver arriba)
Actualmente `blocks` (rutina semanal) y `slots` (franja de una fecha) son colecciones distintas. Para unificarlas sin perder datos, el modelo objetivo debería ser:

- `repeat: { type: 'weekly', days: [0..6] }` o `repeat: { type: 'once', date: 'YYYY-MM-DD' }`.
- Campos comunes: `id`, `title`, `start`, `end`, `color`, `createdAt`, `updatedAt`.
- Migración de cada `block` existente a `weekly`; migración de cada `slot` a `once`.
- Los vínculos de pendientes deben migrar de `blockId`/`slotId` a un `blockId` común. Si un pendiente ya estaba asociado a una franja, esa relación debe prevalecer sobre cualquier vínculo anterior.
- Calendario y Hoy deben consumir el mismo selector de ocurrencias, no replicar reglas distintas.
- La migración debe ser idempotente y conservar IDs para no romper pendientes enlazados ni las copias de seguridad.

## Criterios de aceptación para completar la agenda
1. Crear un bloque permite elegir “Solo este día” o “Semanal” con días elegidos.
2. El mismo bloque aparece en Hoy y Calendario, y editarlo en cualquiera de las dos vistas actualiza ambas.
3. Una sola línea cronológica en Hoy ordena eventos, bloques y pendientes con hora; los elementos sin hora quedan en una zona separada al final.
4. Se puede arrastrar un pendiente desde “Sin bloque” a cualquier bloque compatible y sacarlo de él soltándolo en “Sin bloque”.
5. Desde cada bloque se pueden agregar pendientes asociados al bloque.
6. La migración conserva todos los registros y relaciones de una base de datos existente.
